import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

// Note: process.env.GEMINI_API_KEY is shimmed by the AI Studio platform in the frontend.
const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    // In this case, we won't throw immediately, but the calls will fail or we can handle it.
    console.warn("AI Service: GEMINI_API_KEY not configured.");
  }
  return new GoogleGenAI({ apiKey: apiKey || "" });
};

export async function parseTransactionMessage(text: string, categories: string[]): Promise<Partial<Transaction> | null> {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Extraia os dados da transação: "${text}"`,
      config: {
        systemInstruction: `Você é um extrator de dados financeiros. Categorias permitidas: [${categories.join(", ")}]. Se não encaixar, use 'Geral'.`,
        responseMimeType: "application/json"
      }
    });

    if (!response.text) return null;
    return JSON.parse(response.text.trim());
  } catch (error: any) {
    console.error("AI Parse Error:", error);
    return null;
  }
}

export async function generateFinancialInsight(data: any): Promise<string> {
  try {
    const ai = getAI();
    const prompt = `
      Analise estes dados e dê um conselho curto em 2 ou 3 frases:
      Receita: R$ ${data.income}
      Despesas: R$ ${data.expenses}
      Saldo: R$ ${data.totalBalance}
      Meta: R$ ${data.savingsGoal}
      Top Gastos: ${data.sortedCategories}
      Estourados: ${data.overBudget || "Nenhum"}
      Pendentes: ${data.pendingBills}
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: "Você é um consultor financeiro motivador e direto. Dê um diagnóstico em 2 ou 3 frases no máximo, em Português do Brasil."
      }
    });

    if (!response.text) {
      if (data.income === 0 && data.expenses === 0) {
        return "Registre suas primeiras transações para que eu possa gerar um diagnóstico financeiro inteligente para você.";
      }
      return "Não foi possível carregar o diagnóstico agora.";
    }

    return response.text.trim();
  } catch (error: any) {
    console.error("AI Insight Error:", error);
    if (error.message?.includes("key") || error.message?.includes("403") || error.message?.includes("400")) {
      return "Guru Financeiro: Ative os diagnósticos configurando sua GEMINI_API_KEY no menu 'Segredos'.";
    }
    return "Diagnóstico indisponível no momento. Tente novamente em breve.";
  }
}

export async function transcribeAudio(base64Audio: string): Promise<string | null> {
  try {
    const ai = getAI();
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "audio/ogg",
              data: base64Audio
            }
          },
          { text: "Transcreva este áudio de transação financeira. Responda apenas o texto transcrito em Português do Brasil." }
        ]
      }
    });
    
    return response.text?.trim() || null;
  } catch (error) {
    console.error("Erro na transcrição de áudio:", error);
    return null;
  }
}
