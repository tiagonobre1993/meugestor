import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ReceiptText, 
  Wallet, 
  PieChart, 
  Layout,
  Plus, 
  Bell, 
  Search, 
  ChevronRight,
  ChevronDown,
  TrendingUp,
  TrendingDown,
  Calendar,
  MoreVertical,
  X,
  Settings,
  ArrowUpRight,
  ArrowDownRight,
  Trash2,
  LogOut,
  Shield,
  AlertCircle,
  Wand2,
  FileText,
  Clock,
  Target,
  CheckCircle2,
  Activity,
  Zap,
  Pencil,
  Hash,
  Check,
  MessageCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { format, parseISO, subMonths, subWeeks, subYears, addMonths, startOfMonth, endOfMonth, isWithinInterval, isTomorrow, eachDayOfInterval, isSameDay, isPast, isToday, differenceInDays, differenceInCalendarDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { INITIAL_TRANSACTIONS, INITIAL_BUDGETS, INITIAL_BILLS, CATEGORIES } from './constants';
import { Transaction, Budget, Bill, Category, UserProfile, Saving } from './types';
import { WhatsAppSimulator } from './components/WhatsAppSimulator';
import { parseTransactionMessage, generateFinancialInsight } from './services/aiService';
import { SavingsTab } from './components/SavingsTab';
import { 
  Smartphone, 
  MessageSquare,
  Mic,
  IterationCcw,
  Sparkles
} from 'lucide-react';
import { twMerge } from 'tailwind-merge';
import { clsx, type ClassValue } from 'clsx';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { 
  collection, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  doc, 
  query, 
  where, 
  orderBy,
  setDoc,
  getDoc,
  getDocs,
  getDocFromServer
} from 'firebase/firestore';
import { AuthScreen } from './components/Auth';
import { ErrorBoundary } from './components/ErrorBoundary';
import { motion, AnimatePresence } from 'motion/react';

const AdminPanel = React.lazy(() => import('./components/AdminPanel').then(m => ({ default: m.AdminPanel })));
const ReportModal = React.lazy(() => import('./components/ReportModal').then(m => ({ default: m.ReportModal })));

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default function App() {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);
  const [savingsGoal, setSavingsGoal] = useState<number>(8000);
  const [revenueGoal, setRevenueGoal] = useState<number>(0);
  const [bills, setBills] = useState<Bill[]>([]);
  const [savings, setSavings] = useState<any[]>([]);
  const [categories, setCategories] = useState<Category[]>(CATEGORIES);

  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'budgets' | 'savings'>('dashboard');
  const [transactionsFilter, setTransactionsFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isBillModalOpen, setIsBillModalOpen] = useState(false);
  const [editingBill, setEditingBill] = useState<Bill | null>(null);
  const [isSavingsGoalModalOpen, setIsSavingsGoalModalOpen] = useState(false);
  const [editingCategoryGoal, setEditingCategoryGoal] = useState<string | null>(null);
  const [modalInitialType, setModalInitialType] = useState<'income' | 'expense'>('expense');
  const [modalMode, setModalMode] = useState<'full' | 'income-only' | 'expense-only'>('full');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isRevenueGoalModalOpen, setIsRevenueGoalModalOpen] = useState(false);
  const [isAdminPanelOpen, setIsAdminPanelOpen] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isAILoading, setIsAILoading] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    type: 'danger' | 'warning' | 'info';
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
    type: 'danger'
  });

  const [sessionExpired, setSessionExpired] = useState(false);

  // AI Refinement Loop
  useEffect(() => {
    if (!user || transactions.length === 0) return;

    const refineTransactions = async () => {
      // Processamos apenas UM por vez para não estourar a quota (429)
      const pendingAI = transactions.filter(t => (t as any).needsAI).slice(0, 1);
      if (pendingAI.length === 0) return;

      setIsAILoading(true);
      for (const t of pendingAI) {
        try {
          let textToParse = t.originalMessage || t.description;
          
          const refined = await parseTransactionMessage(textToParse, categories);
          if (refined) {
            const transactionRef = doc(db, 'users', user.uid, 'transactions', t.id);
            await updateDoc(transactionRef, {
              ...refined,
              description: refined.description || textToParse,
              needsAI: false // Mark as refined
            });
          }
        } catch (error: any) {
          console.error("AI Refinement failed for", t.id, error);
          // Se for erro de quota, paramos o loop por um tempo maior
          if (error?.message?.includes("429") || error?.status === 429) {
            console.warn("Quota exceeded in refinement loop. Slowing down.");
            break;
          }
        }
        // Delay de 2 segundos entre processamentos para respeitar limites de RPM
        await new Promise(r => setTimeout(r, 2000));
      }
      setIsAILoading(false);
    };

    // Aumentei para 10 segundos o intervalo de verificação
    const timer = setTimeout(refineTransactions, 10000);
    return () => clearTimeout(timer);
  }, [transactions, user, categories]);

  // Inactivity detection
  useEffect(() => {
    if (!user) return;

    let timeoutId: any;
    const INACTIVITY_LIMIT = 15 * 60 * 1000; // 15 minutes

    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        signOut(auth);
        setSessionExpired(true);
      }, INACTIVITY_LIMIT);
    };

    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart'];
    events.forEach(event => window.addEventListener(event, resetTimer));
    
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach(event => window.removeEventListener(event, resetTimer));
    };
  }, [user]);

  useEffect(() => {
    // Test Firestore Connection
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. The client is offline.");
        }
      }
    };
    testConnection();

    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) {
        setLoading(false);
        // Clear data on logout
        setTransactions([]);
        setBudgets([]);
        setBills([]);
        setCategories(CATEGORIES);
      }
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;

    // Sync User Profile
    const userRef = doc(db, 'users', user.uid);
    const unsubProfile = onSnapshot(userRef, (docSnap) => {
      if (docSnap.exists()) {
        const data = docSnap.data();
        setUserProfile(data);
        if (data.savingsGoal) setSavingsGoal(data.savingsGoal);
        if (data.revenueGoal) setRevenueGoal(data.revenueGoal);
        
        // Real-time Blocking Check
        if (data.status === 'blocked' && user?.email?.toLowerCase() !== 'tiagonobre13@gmail.com') {
          // Show message then logout
          setTimeout(() => {
            signOut(auth);
          }, 3000);
        }
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
      setLoading(false);
    });

    // Sync Transactions
    const transRef = collection(db, 'users', user.uid, 'transactions');
    const qTrans = query(transRef, orderBy('date', 'desc'));
    const unsubTrans = onSnapshot(qTrans, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Transaction)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/transactions`);
    });

    // Sync Budgets
    const budgetsRef = collection(db, 'users', user.uid, 'budgets');
    const unsubBudgets = onSnapshot(budgetsRef, (snapshot) => {
      setBudgets(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/budgets`);
    });

    // Sync Bills
    const billsRef = collection(db, 'users', user.uid, 'bills');
    const unsubBills = onSnapshot(billsRef, (snapshot) => {
      setBills(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Bill)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/bills`);
    });

    // Sync Savings
    const savingsRef = collection(db, 'users', user.uid, 'savings');
    const qSavings = query(savingsRef, orderBy('monthYear', 'desc'));
    const unsubSavings = onSnapshot(qSavings, (snapshot) => {
      setSavings(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/savings`);
    });

    // Sync Categories
    const catsRef = collection(db, 'users', user.uid, 'categories');
    const unsubCats = onSnapshot(catsRef, (snapshot) => {
      if (snapshot.empty) {
        setCategories(CATEGORIES);
      } else {
        setCategories(snapshot.docs.map(doc => doc.data().name));
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `users/${user.uid}/categories`);
    });

    return () => {
      unsubProfile();
      unsubTrans();
      unsubBudgets();
      unsubBills();
      unsubSavings();
      unsubCats();
    };
  }, [user]);

  const now = new Date();
  const startOfCurrentMonth = startOfMonth(now);
  const startOfPrevMonth = startOfMonth(subMonths(now, 1));
  const endOfPrevMonth = endOfMonth(subMonths(now, 1));

  const currentMonthTransactions = transactions.filter(t => parseISO(t.date) >= startOfCurrentMonth);
  const prevMonthTransactions = transactions.filter(t => {
    const d = parseISO(t.date);
    return d >= startOfPrevMonth && d <= endOfPrevMonth;
  });
  const beforeCurrentMonthTransactions = transactions.filter(t => parseISO(t.date) < startOfCurrentMonth);

  const monthlyIncome = currentMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const monthlySpending = currentMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const prevMonthIncome = prevMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const prevMonthSpending = prevMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  const prevMonthResult = prevMonthIncome - prevMonthSpending;
  const currentMonthResult = monthlyIncome - monthlySpending;

  const balanceBeforeCurrentMonth = beforeCurrentMonthTransactions.reduce((acc, t) => 
    t.type === 'income' ? acc + t.amount : acc - t.amount, 0);

  const totalBalance = balanceBeforeCurrentMonth + monthlyIncome - monthlySpending;

  const walletBalance = transactions.reduce((acc, t) => {
    if (t.status === 'pending') return acc;
    return t.type === 'income' ? acc + t.amount : acc - t.amount;
  }, 0);

  const prevTotalBalance = balanceBeforeCurrentMonth;
  const balanceVariation = prevTotalBalance !== 0 
    ? ((totalBalance - prevTotalBalance) / Math.abs(prevTotalBalance)) * 100 
    : (totalBalance !== 0 ? 100 : 0);

  const economyAccumulated = currentMonthResult > 0 ? currentMonthResult : 0;
  const deficitMonth = currentMonthResult < 0 ? Math.abs(currentMonthResult) : 0;

  const addTransaction = async (t: Omit<Transaction, 'id'>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'users', user.uid, 'transactions'), t);
      
      if (t.type === 'income') {
        const existingBudget = budgets.find(b => b.category === t.category);
        if (existingBudget) {
          const budgetRef = doc(db, 'users', user.uid, 'budgets', (existingBudget as any).id);
          await updateDoc(budgetRef, { spent: existingBudget.spent + t.amount });
        } else {
          await addDoc(collection(db, 'users', user.uid, 'budgets'), {
            category: t.category,
            limit: 0,
            spent: t.amount
          });
        }
      }
      setIsModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/transactions`);
    }
  };

  const updateTransaction = async (id: string, updatedData: Partial<Transaction>) => {
    if (!user) return;
    try {
      const transRef = doc(db, 'users', user.uid, 'transactions', id);
      await updateDoc(transRef, updatedData);
      setEditingTransaction(null);
      setIsModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/transactions/${id}`);
    }
  };

  const deleteTransaction = async (id: string) => {
    if (!user) return;
    setConfirmConfig({
      isOpen: true,
      title: 'Excluir Transação',
      message: 'Tem certeza que deseja excluir esta transação? Esta ação não pode ser desfeita.',
      type: 'danger',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'users', user.uid, 'transactions', id));
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        } catch (error) {
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
          handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/transactions/${id}`);
        }
      }
    });
  };

  const deleteMultipleTransactions = async (ids: string[]) => {
    if (!user || ids.length === 0) return;
    setConfirmConfig({
      isOpen: true,
      title: 'Excluir Transações',
      message: `Tem certeza que deseja excluir as ${ids.length} transações selecionadas? Esta ação não pode ser desfeita.`,
      type: 'danger',
      onConfirm: async () => {
        try {
          const promises = ids.map(id => deleteDoc(doc(db, 'users', user.uid, 'transactions', id)));
          await Promise.all(promises);
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        } catch (error) {
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
          handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/transactions/multiple`);
        }
      }
    });
  };

  const addBill = async (b: Omit<Bill, 'id'>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'users', user.uid, 'bills'), b);
      setIsBillModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/bills`);
    }
  };

  const updateBill = async (id: string, b: Partial<Bill>) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid, 'bills', id), b);
      setIsBillModalOpen(false);
      setEditingBill(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/bills/${id}`);
    }
  };

  const deleteBill = async (id: string) => {
    if (!user) return;
    setConfirmConfig({
      isOpen: true,
      title: 'Excluir Conta',
      message: 'Tem certeza que deseja excluir esta conta? Esta ação não pode ser desfeita.',
      type: 'danger',
      onConfirm: async () => {
        try {
          await deleteDoc(doc(db, 'users', user.uid, 'bills', id));
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
        } catch (error) {
          setConfirmConfig(prev => ({ ...prev, isOpen: false }));
          handleFirestoreError(error, OperationType.DELETE, `users/${user.uid}/bills/${id}`);
        }
      }
    });
  };

  const payBill = async (bill: Bill) => {
    if (!user) return;
    try {
      // 1. Update bill status or next month if recurring
      const billRef = doc(db, 'users', user.uid, 'bills', bill.id);
      if (bill.recurring) {
        const nextMonthDate = addMonths(parseISO(bill.dueDate), 1).toISOString();
        await updateDoc(billRef, { 
          status: 'pending', 
          dueDate: nextMonthDate 
        });
      } else {
        await updateDoc(billRef, { status: 'paid' });
      }

      // 2. Add as transaction
      await addDoc(collection(db, 'users', user.uid, 'transactions'), {
        description: `Pagamento: ${bill.name}`,
        amount: bill.amount,
        date: new Date().toISOString(),
        category: bill.category || 'Geral',
        type: 'expense'
      });
      
      // 3. Update budget if applicable
      const existingBudget = budgets.find(b => b.category === (bill.category || 'Geral'));
      if (existingBudget) {
        const budgetRef = doc(db, 'users', user.uid, 'budgets', (existingBudget as any).id);
        await updateDoc(budgetRef, { spent: existingBudget.spent + bill.amount });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/bills/${bill.id}`);
    }
  };

  const handleLogout = () => {
    signOut(auth);
  };

  const updateSavingsGoal = async (goal: number) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), { savingsGoal: goal });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const updateBudgets = async (newBudgets: Budget[]) => {
    if (!user) return;
    try {
      // This is a bit complex because we need to match existing docs
      for (const b of newBudgets) {
        const existing = budgets.find(eb => eb.category === b.category);
        if (existing) {
          await updateDoc(doc(db, 'users', user.uid, 'budgets', (existing as any).id), { limit: b.limit });
        } else {
          await addDoc(collection(db, 'users', user.uid, 'budgets'), b);
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}/budgets`);
    }
  };

  const updateRevenueGoal = async (goal: number) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), { revenueGoal: goal });
      setRevenueGoal(goal);
      setIsRevenueGoalModalOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const updateUserProfile = async (data: any) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), data);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  const addCategory = async (name: string) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'users', user.uid, 'categories'), { name });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}/categories`);
    }
  };

  const fixIncomeCategories = async () => {
    if (!user) return;
    const incomeToFix = transactions.filter(t => t.type === 'income' && t.category === 'Alimentação');
    if (incomeToFix.length === 0) {
      alert("Nenhuma receita com categoria 'Alimentação' encontrada.");
      return;
    }

    let fixedCount = 0;
    for (const t of incomeToFix) {
      try {
        await updateDoc(doc(db, 'users', user.uid, 'transactions', t.id), { category: 'Salário' });
        fixedCount++;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}/transactions/${t.id}`);
      }
    }
    alert(`${fixedCount} receitas foram corrigidas para a categoria 'Salário'.`);
  };

  const removeCategory = async (name: string) => {
    if (!user) return;
    try {
      const catSnap = await getDocs(query(collection(db, 'users', user.uid, 'categories'), where('name', '==', name)));
      catSnap.forEach(async (d) => await deleteDoc(doc(db, 'users', user.uid, 'categories', d.id)));
      
      const budgetSnap = await getDocs(query(collection(db, 'users', user.uid, 'budgets'), where('category', '==', name)));
      budgetSnap.forEach(async (d) => await deleteDoc(doc(db, 'users', user.uid, 'budgets', d.id)));
    } catch (error) {
      console.error("Error removing category:", error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center"
        >
          <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shadow-2xl shadow-indigo-200 mb-8 animate-bounce">
            <Wallet size={36} />
          </div>
          <h1 className="text-3xl font-black text-slate-800 tracking-tighter mb-3">Meu Gestor</h1>
          <div className="flex items-center gap-3 text-slate-400 font-bold text-sm uppercase tracking-widest">
            <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <span>Sincronizando dados...</span>
          </div>
        </motion.div>
      </div>
    );
  }

  if (sessionExpired) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 max-w-sm w-full text-center">
          <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Clock size={32} />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">Sessão Expirada</h2>
          <p className="text-sm text-slate-500 mb-6 font-sans">
            Você foi desconectado por inatividade para manter seus dados seguros.
          </p>
          <button 
            onClick={() => { setSessionExpired(false); window.location.reload(); }}
            className="w-full py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all font-sans shadow-lg shadow-indigo-100"
          >
            Fazer Login Novamente
          </button>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <ErrorBoundary>
        <AuthScreen onAuthSuccess={setUser} />
      </ErrorBoundary>
    );
  }

  if (userProfile && userProfile.status === 'pending' && user?.email?.toLowerCase() !== 'tiagonobre13@gmail.com') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md p-8 text-center animate-in fade-in zoom-in duration-300">
          <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Clock size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Aguardando Aprovação</h2>
          <p className="text-slate-500 mb-8">
            Olá, <strong>{userProfile.name || user.email}</strong>! Sua conta foi criada com sucesso, mas ainda precisa ser aprovada por um administrador para que você possa acessar o sistema.
          </p>
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 mb-8">
            <p className="text-xs text-amber-800 leading-relaxed">
              Você receberá acesso assim que o administrador validar sua solicitação. Por favor, tente novamente mais tarde.
            </p>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full py-4 bg-slate-100 text-slate-700 font-bold rounded-2xl hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
          >
            <LogOut size={20} />
            Sair da Conta
          </button>
        </div>
      </div>
    );
  }

  if (userProfile && userProfile.status === 'blocked' && user?.email?.toLowerCase() !== 'tiagonobre13@gmail.com') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md p-8 text-center animate-in fade-in zoom-in duration-300">
          <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <AlertCircle size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Acesso Bloqueado</h2>
          <p className="text-slate-500 mb-8">
            Sua conta foi bloqueada pelo administrador. Você não tem mais permissão para acessar o sistema.
          </p>
          <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100 mb-8">
            <p className="text-xs text-rose-800 leading-relaxed font-bold">
              Seu acesso foi bloqueado pelo administrador. Efetuando logout automático...
            </p>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full py-4 bg-slate-100 text-slate-700 font-bold rounded-2xl hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
          >
            <LogOut size={20} />
            Sair Agora
          </button>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-xl border-b border-slate-200/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-20 items-center">
            <div className="flex items-center gap-3">
              <motion.div 
                whileHover={{ rotate: -10, scale: 1.1 }}
                className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-xl shadow-indigo-200 border border-indigo-500/20"
              >
                <Wallet size={20} />
              </motion.div>
              <div className="flex flex-col">
                <span className="text-lg font-black tracking-tight text-slate-800 leading-none">Meu Gestor</span>
                <span className="text-[10px] font-bold text-indigo-500 uppercase tracking-widest mt-1">Sua Gestão</span>
              </div>
            </div>
            
            <nav className="hidden lg:flex items-center bg-slate-100/50 p-1.5 rounded-2xl border border-slate-200/40">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
                { id: 'transactions', label: 'Transações', icon: ReceiptText },
                { id: 'budgets', label: 'Metas', icon: Target },
                { id: 'savings', label: 'Economias', icon: Sparkles },
              ].map((tab) => (
                <button 
                  key={tab.id}
                  onClick={() => {
                    if (tab.id === 'transactions') setTransactionsFilter('all');
                    setActiveTab(tab.id as any);
                  }}
                  className={cn(
                    "relative px-4 py-2 text-[11px] font-black uppercase tracking-widest transition-all flex items-center gap-2 rounded-xl",
                    activeTab === tab.id ? "text-indigo-600" : "text-slate-500 hover:text-slate-800"
                  )}
                >
                  {activeTab === tab.id && (
                    <motion.div 
                      layoutId="activeTabPill"
                      className="absolute inset-0 bg-white shadow-sm rounded-xl border border-slate-200/60"
                      transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                  <tab.icon size={14} className="relative z-10" />
                  <span className="relative z-10">{tab.label}</span>
                </button>
              ))}
            </nav>
            
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-1 bg-slate-50/50 p-1 rounded-xl border border-slate-200/40">
                {userProfile?.role === 'admin' && (
                  <motion.button 
                    whileHover={{ scale: 1.1, backgroundColor: '#fff' }}
                    onClick={() => setIsAdminPanelOpen(true)}
                    className="p-2 text-rose-500 rounded-lg transition-colors"
                    title="Painel Admin"
                  >
                    <Shield size={18} />
                  </motion.button>
                )}
                <motion.button 
                  whileHover={{ scale: 1.1, backgroundColor: '#fff' }}
                  onClick={() => setIsReportOpen(true)}
                  className="p-2 text-slate-500 rounded-lg transition-colors"
                  title="Relatório Financeiro"
                >
                  <FileText size={18} />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.1, backgroundColor: '#fff' }}
                  onClick={() => setIsSettingsOpen(true)}
                  className="p-2 text-slate-400 rounded-lg transition-colors"
                  title="Configurações"
                >
                  <Settings size={18} />
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.1, backgroundColor: '#fff' }}
                  onClick={handleLogout}
                  className="p-2 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                  title="Sair"
                >
                  <LogOut size={18} />
                </motion.button>
              </div>

              <motion.button 
                whileHover={{ scale: 1.02, y: -2 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  setEditingTransaction(null);
                  setModalMode('expense-only');
                  setIsModalOpen(true);
                }}
                className="bg-indigo-600 text-white px-5 py-3 rounded-2xl font-black text-[11px] uppercase tracking-[0.1em] flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 border border-indigo-500/20"
              >
                <div className="bg-white/20 p-1.5 rounded-lg text-white">
                  <Plus size={16} />
                </div>
                <span>Nova Despesa</span>
              </motion.button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <DashboardView 
            transactions={transactions} 
            budgets={budgets} 
            bills={bills}
            totalBalance={totalBalance}
            walletBalance={walletBalance}
            monthlySpending={monthlySpending}
            monthlyIncome={monthlyIncome}
            balanceVariation={balanceVariation}
            currentMonthResult={currentMonthResult}
            economyAccumulated={economyAccumulated}
            deficitMonth={deficitMonth}
            savingsGoal={savingsGoal}
            onAddTransaction={() => {
              setEditingTransaction(null);
              setModalInitialType('expense');
              setModalMode('expense-only');
              setIsModalOpen(true);
            }}
            onAddBill={() => {
              setEditingBill(null);
              setIsBillModalOpen(true);
            }}
            onPayBill={payBill}
            onEditBill={(bill: Bill) => {
              setEditingBill(bill);
              setIsBillModalOpen(true);
            }}
            onDeleteBill={deleteBill}
          />
        )}
        {activeTab === 'transactions' && (
          <TransactionsView 
            transactions={transactions} 
            categories={categories}
            initialType={transactionsFilter}
            onEdit={(t: Transaction) => {
              setEditingTransaction(t);
              setModalMode('full');
              setIsModalOpen(true);
            }}
            onDelete={deleteTransaction}
            onDeleteMultiple={deleteMultipleTransactions}
          />
        )}
        {activeTab === 'budgets' && (
          <BudgetsView 
            budgets={budgets} 
            transactions={transactions} 
            revenueGoal={revenueGoal}
            userProfile={userProfile}
            onAddTransaction={() => {
              setEditingTransaction(null);
              setModalInitialType('income');
              setModalMode('income-only');
              setIsModalOpen(true);
            }}
            onOpenSettings={() => setIsSettingsOpen(true)}
            onOpenRevenueGoalModal={() => setIsRevenueGoalModalOpen(true)}
            onOpenSavingsGoalModal={() => setIsSavingsGoalModalOpen(true)}
            onEditCategoryGoal={(category: string) => setEditingCategoryGoal(category)}
            onRemoveCategory={(category: string) => {
              setConfirmConfig({
                isOpen: true,
                title: 'Excluir Meta e Categoria',
                message: `Tem certeza que deseja excluir a meta e a categoria "${category}"? Ela não aparecerá mais nos lançamentos.`,
                type: 'danger',
                onConfirm: () => {
                  removeCategory(category);
                  setConfirmConfig(prev => ({ ...prev, isOpen: false }));
                }
              });
            }}
            onOpenReport={() => setIsReportOpen(true)}
            onViewTransactions={(type: 'all' | 'income' | 'expense') => {
              setTransactionsFilter(type);
              setActiveTab('transactions');
            }}
            onFixCategories={() => {
              setConfirmConfig({
                isOpen: true,
                title: 'Corrigir Categorias',
                message: "Deseja corrigir todas as receitas que estão marcadas como 'Alimentação' para a categoria 'Salário'?",
                type: 'warning',
                onConfirm: async () => {
                  await fixIncomeCategories();
                  setConfirmConfig(prev => ({ ...prev, isOpen: false }));
                }
              });
            }}
          />
        )}
        {activeTab === 'savings' && (
          <SavingsTab 
            savings={savings} 
            userProfile={userProfile} 
            userId={user.uid} 
          />
        )}
      </main>

      {/* WhatsApp Floating FAB */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsSimulatorOpen(true)}
        className="fixed bottom-6 right-6 w-16 h-16 bg-[#25D366] text-white rounded-full shadow-[0_8px_24px_rgba(37,211,102,0.4)] flex items-center justify-center z-40 group border-4 border-white/20 overflow-hidden"
        title="Gerencie pelo WhatsApp"
      >
        <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
        <MessageCircle size={32} fill="white" />
        <div className="absolute right-full mr-4 bg-white text-slate-800 px-4 py-2 rounded-xl text-xs font-bold shadow-2xl opacity-0 group-hover:opacity-100 transition-all translate-x-2 group-hover:translate-x-0 whitespace-nowrap pointer-events-none border border-slate-100">
          WhatsApp Meu Gestor
        </div>
        {isAILoading && (
          <span className="absolute -top-1 -right-1 flex h-5 w-5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-5 w-5 bg-white/20 border-2 border-white"></span>
          </span>
        )}
      </motion.button>

      <AnimatePresence>
        {isSimulatorOpen && userProfile && (
          <WhatsAppSimulator 
            onClose={() => setIsSimulatorOpen(false)} 
            phone={userProfile.whatsappPhone || ''} 
          />
        )}
      </AnimatePresence>

      {isSavingsGoalModalOpen && (
        <SavingsGoalModal 
          onClose={() => setIsSavingsGoalModalOpen(false)}
          currentGoal={savingsGoal}
          onSubmit={updateSavingsGoal}
        />
      )}

      {editingCategoryGoal && (
        <CategoryGoalModal 
          onClose={() => setEditingCategoryGoal(null)}
          category={editingCategoryGoal}
          currentLimit={budgets.find(b => b.category === editingCategoryGoal)?.limit || 0}
          onSubmit={(limit: number) => {
            const existing = budgets.find(b => b.category === editingCategoryGoal);
            if (existing) {
              updateBudgets([{ ...existing, limit }]);
            }
          }}
        />
      )}

      {isModalOpen && (
        modalMode === 'income-only' ? (
          <IncomeModal 
            onClose={() => {
              setIsModalOpen(false);
              setEditingTransaction(null);
            }} 
            onSubmit={(data: any) => {
              if (editingTransaction) {
                updateTransaction(editingTransaction.id, data);
              } else {
                addTransaction(data);
              }
            }}
            categories={categories}
            onAddCategory={addCategory}
            initialData={editingTransaction}
          />
        ) : (
          <TransactionModal 
            onClose={() => {
              setIsModalOpen(false);
              setEditingTransaction(null);
            }} 
            onSubmit={(data: any) => {
              if (editingTransaction) {
                updateTransaction(editingTransaction.id, data);
              } else {
                addTransaction(data);
              }
            }}
            categories={categories}
            onAddCategory={addCategory}
            initialType={modalInitialType}
            mode={modalMode}
            initialData={editingTransaction}
          />
        )
      )}

      {isBillModalOpen && (
        <BillModal 
          onClose={() => {
            setIsBillModalOpen(false);
            setEditingBill(null);
          }} 
          onSubmit={(data: any) => {
            if (editingBill) {
              updateBill(editingBill.id, data);
            } else {
              addBill(data);
            }
          }}
          categories={categories}
          initialData={editingBill}
        />
      )}

      {isSettingsOpen && (
        <SettingsModal
          onClose={() => setIsSettingsOpen(false)}
          savingsGoal={savingsGoal}
          setSavingsGoal={updateSavingsGoal}
          budgets={budgets}
          setBudgets={updateBudgets}
          categories={categories}
          onAddCategory={addCategory}
          onRemoveCategory={removeCategory}
          userProfile={userProfile}
          onUpdateProfile={updateUserProfile}
        />
      )}

      {isRevenueGoalModalOpen && (
        <RevenueGoalModal 
          onClose={() => setIsRevenueGoalModalOpen(false)}
          currentGoal={revenueGoal || budgets.reduce((acc: number, b: any) => acc + b.limit, 0)}
          onSubmit={updateRevenueGoal}
        />
      )}

      <React.Suspense fallback={
        <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-[200] flex items-center justify-center">
          <div className="bg-white p-8 rounded-3xl shadow-2xl flex items-center gap-4 animate-in fade-in zoom-in duration-300">
            <div className="w-8 h-8 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="font-black text-slate-800 uppercase tracking-widest text-xs">Carregando módulo...</span>
          </div>
        </div>
      }>
        {isAdminPanelOpen && (
          <AdminPanel onClose={() => setIsAdminPanelOpen(false)} />
        )}

        {isReportOpen && (
          <ReportModal 
            isOpen={isReportOpen} 
            onClose={() => setIsReportOpen(false)} 
            transactions={transactions}
            budgets={budgets}
            categories={categories}
          />
        )}
      </React.Suspense>

      {confirmConfig.isOpen && (
        <ConfirmationModal 
          title={confirmConfig.title}
          message={confirmConfig.message}
          type={confirmConfig.type}
          onConfirm={confirmConfig.onConfirm}
          onCancel={() => setConfirmConfig(prev => ({ ...prev, isOpen: false }))}
        />
      )}

      <footer className="py-8 border-t border-slate-200 text-center text-slate-500 text-sm">
        <p>© 2026 Meu Gestor. Todos os direitos reservados.</p>
        <p className="mt-1 opacity-60">Logado como: {user.email}</p>
      </footer>
    </div>
    </ErrorBoundary>
  );
}

function SmartInsight({ transactions, budgets, bills, savingsGoal, totalBalance }: any) {
  const [insight, setInsight] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [lastGenerated, setLastGenerated] = useState<number>(0);

  const generateInsight = async (force = false) => {
    if (loading) return;
    
    // Cache de 30 minutos para evitar excesso de requisições e erro 429
    const CACHE_TIME = 30 * 60 * 1000;
    const now = Date.now();
    
    if (!force && insight && (now - lastGenerated < CACHE_TIME)) {
      return;
    }

    setLoading(true);
    try {
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      
      const monthlyTransactions = transactions.filter((t: any) => {
        const d = parseISO(t.date);
        return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      });

      const income = monthlyTransactions.filter((t: any) => t.type === 'income').reduce((acc: number, t: any) => acc + t.amount, 0);
      const expenses = monthlyTransactions.filter((t: any) => t.type === 'expense').reduce((acc: number, t: any) => acc + t.amount, 0);
      
      const topCategories = monthlyTransactions
        .filter((t: any) => t.type === 'expense')
        .reduce((acc: any, t: any) => {
          acc[t.category] = (acc[t.category] || 0) + t.amount;
          return acc;
        }, {});
      
      const sortedCategories = Object.entries(topCategories)
        .sort(([, a]: any, [, b]: any) => b - a)
        .slice(0, 3)
        .map(([name, value]) => `${name}: R$ ${value}`)
        .join(", ");

      const overBudget = budgets.filter((b: any) => b.spent > b.limit && b.limit > 0).map((b: any) => b.category).join(", ");
      const pendingBills = bills.filter((b: any) => b.status === 'pending').length;

      const aiResponse = await generateFinancialInsight({
        income,
        expenses,
        totalBalance,
        savingsGoal,
        sortedCategories,
        overBudget,
        pendingBills
      });

      if (aiResponse.includes("requer uma chave de API") || aiResponse.includes("não consegui gerar")) {
        console.warn("AI Insight warning:", aiResponse);
      }

      setInsight(aiResponse);
      setLastGenerated(now);
    } catch (error) {
      console.error("Erro no componente de insight:", error);
      setInsight("Não foi possível carregar o diagnóstico agora. Verifique sua conexão.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (transactions.length > 0) {
      generateInsight();
    }
  }, [transactions.length, budgets.length, bills.length]);

  return (
    <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6 relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <button 
          onClick={() => generateInsight(true)}
          disabled={loading}
          className="p-2 hover:bg-indigo-100 rounded-full text-indigo-600 transition-colors"
          title="Atualizar Insight"
        >
          <IterationCcw size={16} className={cn(loading && "animate-spin")} />
        </button>
      </div>
      <h3 className="text-lg font-bold text-indigo-900 mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp size={20} />
          Insight Inteligente
        </div>
        {loading && <div className="w-4 h-4 border-2 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin"></div>}
      </h3>
      <p className="text-indigo-800 opacity-80 text-sm leading-relaxed mb-4">
        {transactions.length === 0 
          ? "Registre suas primeiras transações para que eu possa gerar um diagnóstico financeiro inteligente para você."
          : (insight || "Analisando seus dados financeiros para gerar um diagnóstico...")}
      </p>
      {lastGenerated > 0 && !loading && (
        <span className="text-[10px] text-indigo-400 font-medium">
          Atualizado às {new Date(lastGenerated).toLocaleTimeString()}
        </span>
      )}
    </div>
  );
}

function MonthlyExpenseLineChart({ transactions }: { transactions: Transaction[] }) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showDayOfWeek, setShowDayOfWeek] = useState(true);
  const [viewMode, setViewMode] = useState<'daily' | 'grouped'>('daily');

  const handlePrevMonth = () => setSelectedDate(subMonths(selectedDate, 1));
  const handleNextMonth = () => setSelectedDate(addMonths(selectedDate, 1));

  const monthStart = startOfMonth(selectedDate);
  const monthEnd = endOfMonth(selectedDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const chartData = daysInMonth.map(day => {
    const dailyExpenses = transactions
      .filter(t => t.type === 'expense' && isSameDay(parseISO(t.date), day))
      .reduce((sum, t) => sum + t.amount, 0);
    
    return {
      day: format(day, 'dd'),
      dayOfWeek: format(day, 'EEE', { locale: ptBR }).substring(0, 3).toUpperCase(),
      dayOfWeekFull: format(day, 'EEEE', { locale: ptBR }),
      fullDate: format(day, "dd/MM/yyyy"),
      amount: dailyExpenses,
      isWeekend: [0, 6].includes(day.getDay()),
      dateObj: day
    };
  });

  const totalMonthExpense = chartData.reduce((sum, d) => sum + d.amount, 0);
  const averageExpense = totalMonthExpense / daysInMonth.length;

  const groupedData = ['Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado', 'Domingo'].map(d => {
    const total = chartData
      .filter(cd => cd.dayOfWeekFull.toLowerCase() === d.toLowerCase())
      .reduce((sum, cd) => sum + cd.amount, 0);
    return { 
      name: d.substring(0, 3).toUpperCase(), 
      full: d, 
      amount: total 
    };
  });

  const getInsight = () => {
    if (totalMonthExpense === 0) return "Nenhum gasto registrado este mês.";
    
    const dayTotals: any = {};
    chartData.forEach(d => {
      dayTotals[d.dayOfWeekFull] = (dayTotals[d.dayOfWeekFull] || 0) + d.amount;
    });
    const sortedDays = Object.entries(dayTotals).sort((a: any, b: any) => b[1] - a[1]);
    const topDay = sortedDays[0][0];
    
    const firstHalf = chartData.slice(0, 15).reduce((sum, d) => sum + d.amount, 0);
    const secondHalf = chartData.slice(15).reduce((sum, d) => sum + d.amount, 0);
    const trend = firstHalf > secondHalf ? "no início do mês" : "no final do mês";
    
    return `Você gasta mais às ${topDay.toLowerCase()}s e seus maiores gastos ocorrem ${trend}.`;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      const amount = payload[0].value as number;
      const diffPercent = averageExpense > 0 ? ((amount - averageExpense) / averageExpense) * 100 : 0;
      
      return (
        <div className="bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200 min-w-[200px]">
          <div className="flex justify-between items-start mb-2">
            <div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                {viewMode === 'daily' ? data.fullDate : data.full}
              </p>
              <p className="text-xs font-bold text-slate-600 capitalize">
                {viewMode === 'daily' ? data.dayOfWeekFull : 'Total Acumulado'}
              </p>
            </div>
            {data.isWeekend && viewMode === 'daily' && (
              <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-[8px] font-black rounded-full uppercase">Fim de Semana</span>
            )}
          </div>
          
          <div className="mt-3 pt-3 border-t border-slate-50">
            <p className="text-2xl font-black text-indigo-600">{formatCurrency(amount)}</p>
            {viewMode === 'daily' && amount > 0 && (
              <p className={cn(
                "text-[10px] font-bold mt-1",
                amount > averageExpense ? "text-rose-500" : "text-emerald-500"
              )}>
                {amount > averageExpense ? (
                  <span className="flex items-center gap-1"><TrendingUp size={10} /> {diffPercent.toFixed(0)}% acima da média</span>
                ) : (
                  <span className="flex items-center gap-1"><TrendingDown size={10} /> {Math.abs(diffPercent).toFixed(0)}% abaixo da média</span>
                )}
              </p>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  const CustomAxisTick = ({ x, y, payload }: any) => {
    const data = chartData.find(d => d.day === payload.value);
    if (!data) return null;

    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={0} dy={16} textAnchor="middle" fill="#94a3b8" fontSize={10} fontWeight="700">
          {payload.value}
        </text>
        {showDayOfWeek && (
          <text x={0} y={0} dy={28} textAnchor="middle" fill="#cbd5e1" fontSize={7} fontWeight="800" className="hidden md:block">
            {data.dayOfWeek}
          </text>
        )}
      </g>
    );
  };

  const CustomDot = (props: any) => {
    const { cx, cy, payload } = props;
    if (payload.amount === 0) {
      return <circle cx={cx} cy={cy} r={2} fill="#e2e8f0" />;
    }
    if (payload.amount > averageExpense * 1.5) {
      return (
        <g>
          <circle cx={cx} cy={cy} r={8} fill="#6366f1" fillOpacity={0.2} />
          <circle cx={cx} cy={cy} r={4} fill="#6366f1" stroke="#fff" strokeWidth={2} />
        </g>
      );
    }
    return <circle cx={cx} cy={cy} r={4} fill="#6366f1" stroke="#fff" strokeWidth={2} />;
  };

  return (
    <div className="card p-8 bg-white shadow-xl shadow-slate-200/50 border-slate-100">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-10">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shadow-sm">
            <Activity size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800 tracking-tight">Evolução de Gastos</h3>
            <p className="text-sm text-slate-500 font-medium">Análise detalhada do seu comportamento financeiro</p>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-4 w-full lg:w-auto">
          {/* View Toggles */}
          <div className="flex bg-slate-100 p-1 rounded-xl">
            <button 
              onClick={() => setViewMode('daily')}
              className={cn(
                "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                viewMode === 'daily' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Por Dia
            </button>
            <button 
              onClick={() => setViewMode('grouped')}
              className={cn(
                "px-4 py-1.5 rounded-lg text-xs font-bold transition-all",
                viewMode === 'grouped' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
              )}
            >
              Agrupado
            </button>
          </div>

          {/* Month Navigation */}
          <div className="flex items-center gap-3 bg-slate-50 p-1.5 rounded-xl border border-slate-100">
            <button 
              onClick={handlePrevMonth}
              className="p-2 hover:bg-white hover:shadow-sm rounded-lg transition-all text-slate-600"
            >
              <ChevronRight className="rotate-180" size={18} />
            </button>
            <div className="px-4 py-1 text-sm font-bold text-slate-700 min-w-[140px] text-center capitalize">
              {format(selectedDate, 'MMMM yyyy', { locale: ptBR })}
            </div>
            <button 
              onClick={handleNextMonth}
              className="p-2 hover:bg-white hover:shadow-sm rounded-lg transition-all text-slate-600"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-10">
        <div className="xl:col-span-3">
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart 
                data={(viewMode === 'daily' ? chartData : groupedData) as any[]}
                margin={{ top: 10, right: 30, left: 0, bottom: 20 }}
              >
                <defs>
                  <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey={viewMode === 'daily' ? "day" : "name"} 
                  axisLine={false} 
                  tickLine={false} 
                  tick={viewMode === 'daily' ? <CustomAxisTick /> : { fill: '#94a3b8', fontSize: 10, fontWeight: '700' }}
                  interval={0}
                  padding={{ left: 20, right: 20 }}
                />
                <YAxis hide domain={['auto', 'auto']} />
                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#f1f5f9', strokeWidth: 2 }} />
                <Line 
                  type="monotone" 
                  dataKey="amount" 
                  stroke="#6366f1" 
                  strokeWidth={4} 
                  dot={viewMode === 'daily' ? <CustomDot /> : { r: 6, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 8, strokeWidth: 0, fill: '#6366f1' }}
                  animationDuration={1500}
                  animationEasing="ease-in-out"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Controls & Insight */}
          <div className="mt-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-6">
              {viewMode === 'daily' && (
                <label className="flex items-center gap-2 cursor-pointer group">
                  <div 
                    onClick={() => setShowDayOfWeek(!showDayOfWeek)}
                    className={cn(
                      "w-8 h-4 rounded-full transition-all relative",
                      showDayOfWeek ? "bg-indigo-500" : "bg-slate-200"
                    )}
                  >
                    <div className={cn(
                      "absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all shadow-sm",
                      showDayOfWeek ? "left-4.5" : "left-0.5"
                    )} />
                  </div>
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-slate-600 transition-colors">
                    Dias da Semana
                  </span>
                </label>
              )}
            </div>

            <div className="flex items-center gap-3 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100/50 w-full sm:w-auto">
              <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                <Wand2 size={16} />
              </div>
              <p className="text-xs font-bold text-indigo-700 leading-relaxed">
                {getInsight()}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:border-indigo-100 transition-all group">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total no Período</p>
            <h4 className="text-3xl font-black text-slate-800 group-hover:text-indigo-600 transition-colors">
              {formatCurrency(totalMonthExpense)}
            </h4>
          </div>

          <div className="p-6 bg-slate-50 rounded-3xl border border-slate-100 hover:border-emerald-100 transition-all group">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Média Diária</p>
            <h4 className="text-3xl font-black text-slate-800 group-hover:text-emerald-600 transition-colors">
              {formatCurrency(averageExpense)}
            </h4>
            <div className="mt-4 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">Baseado em {daysInMonth.length} dias</span>
            </div>
          </div>

          <div className="mt-auto p-4 bg-amber-50 rounded-2xl border border-amber-100">
            <div className="flex items-center gap-2 text-amber-700 mb-1">
              <AlertCircle size={14} />
              <span className="text-[10px] font-black uppercase tracking-widest">Dica</span>
            </div>
            <p className="text-[10px] text-amber-600 font-medium leading-relaxed">
              Passe o mouse sobre os pontos para ver detalhes e comparações com sua média.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function BillCard({ 
  bill, 
  onPay, 
  onEdit, 
  onDelete 
}: any) {
  const dueDate = parseISO(bill.dueDate);
  const today = new Date();
  
  const isOverdue = isPast(dueDate) && !isToday(dueDate) && bill.status !== 'paid';
  const isDueToday = isToday(dueDate) && bill.status !== 'paid';
  const daysUntil = differenceInCalendarDays(dueDate, today);
  const isNearDue = daysUntil >= 0 && daysUntil <= 3 && bill.status !== 'paid';

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), 'dd/MM/yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const getStatusColor = () => {
    if (bill.status === 'paid') return 'text-emerald-600 bg-emerald-50 border-emerald-100';
    if (isOverdue) return 'text-rose-600 bg-rose-50 border-rose-100';
    return 'text-amber-600 bg-amber-50 border-amber-100';
  };

  const getUrgencyText = () => {
    if (bill.status === 'paid') return null;
    if (isOverdue) return `Atrasado há ${Math.abs(daysUntil)} dias`;
    if (isDueToday) return 'Vence hoje';
    if (daysUntil === 1) return 'Vence amanhã';
    if (daysUntil === 2) return 'Vence em 2 dias';
    if (daysUntil === 3) return 'Vence em 3 dias';
    return null;
  };

  const progress = bill.totalInstallments && bill.totalInstallments > 1 ? (bill.currentInstallment || 1) / bill.totalInstallments * 100 : 0;

  return (
    <motion.div 
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className={cn(
        "group p-4 rounded-2xl border transition-all hover:shadow-lg hover:-translate-y-1",
        bill.status === 'paid' ? "bg-emerald-50/30 border-emerald-100" : 
        isOverdue ? "bg-rose-50/30 border-rose-100 shadow-rose-100/50" : 
        "bg-white border-slate-100"
      )}
    >
      <div className="flex flex-col sm:flex-row justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center transition-colors shrink-0",
            bill.status === 'paid' ? "bg-emerald-100 text-emerald-600" : 
            isOverdue ? "bg-rose-100 text-rose-600" : 
            "bg-slate-100 text-slate-600"
          )}>
            <Calendar size={20} />
          </div>
          
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <h4 className="font-bold text-slate-800 text-base">{bill.name}</h4>
              {isNearDue && !isOverdue && <AlertCircle size={14} className="text-amber-500 animate-pulse" />}
            </div>
            <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[12px] text-slate-500">
              <span className="flex items-center gap-1">
                <Calendar size={12} />
                {formatDate(bill.dueDate)}
              </span>
              {bill.totalInstallments && bill.totalInstallments > 1 && (
                <span className="flex items-center gap-1 font-medium text-indigo-600">
                  <Hash size={12} />
                  Parcela {bill.currentInstallment}/{bill.totalInstallments}
                </span>
              )}
            </div>
            {getUrgencyText() && (
              <p className={cn(
                "text-[9px] font-black uppercase tracking-wider",
                isOverdue ? "text-rose-600" : "text-amber-600"
              )}>
                {getUrgencyText()}
              </p>
            )}
          </div>
        </div>

        <div className="flex flex-col items-end justify-between text-right">
          <div className="space-y-0.5">
            <p className="text-xl font-black text-slate-800">{formatCurrency(bill.amount)}</p>
            <div className={cn(
              "inline-flex px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-widest border",
              getStatusColor()
            )}>
              {bill.status === 'paid' ? 'Pago' : isOverdue ? 'Atrasado' : 'Pendente'}
            </div>
          </div>
        </div>
      </div>

      {/* Progress Bar for Installments */}
      {bill.totalInstallments && bill.totalInstallments > 1 && (
        <div className="mt-4 space-y-1">
          <div className="flex justify-between text-[9px] font-bold text-slate-400 uppercase">
            <span>Progresso</span>
            <span>{Math.round(progress)}%</span>
          </div>
          <div className="h-1 w-full bg-slate-100 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className={cn(
                "h-full rounded-full",
                bill.status === 'paid' ? "bg-emerald-500" : "bg-indigo-500"
              )}
            />
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between opacity-0 group-hover:opacity-100 transition-opacity duration-200">
        <div className="flex gap-1">
          <button 
            onClick={() => onEdit(bill)}
            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
            title="Editar"
          >
            <Pencil size={16} />
          </button>
          <button 
            onClick={() => onDelete(bill.id)}
            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
            title="Excluir"
          >
            <Trash2 size={16} />
          </button>
        </div>

        {bill.status !== 'paid' && (
          <button 
            onClick={() => onPay(bill)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 text-white text-[12px] font-bold rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-100 active:scale-[0.98] transition-all"
          >
            <Check size={16} />
            Marcar como Pago
          </button>
        )}
      </div>
    </motion.div>
  );
}

function DashboardView({ 
  transactions, 
  budgets, 
  bills, 
  totalBalance, 
  walletBalance,
  monthlySpending, 
  monthlyIncome,
  balanceVariation,
  currentMonthResult,
  economyAccumulated,
  deficitMonth,
  savingsGoal, 
  onAddTransaction, 
  onAddBill, 
  onPayBill,
  onEditBill,
  onDeleteBill,
  onViewTransactions
}: any) {
  const pendingBills = (bills || []).filter((b: any) => {
    const dueDate = parseISO(b.dueDate);
    const isCurrentMonth = dueDate.getMonth() === new Date().getMonth() && dueDate.getFullYear() === new Date().getFullYear();
    return b.status === 'pending' && isCurrentMonth;
  });

  const categoryData = transactions
    .filter((t: any) => t.type === 'expense')
    .reduce((acc: any[], t: any) => {
      const existing = acc.find(item => item.name === t.category);
      if (existing) {
        existing.value += t.amount;
      } else {
        acc.push({ name: t.category, value: t.amount });
      }
      return acc;
    }, [])
    .sort((a: any, b: any) => b.value - a.value);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), 'dd/MM/yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const COLORS = [
    '#6366f1', // Indigo
    '#f59e0b', // Amber
    '#10b981', // Emerald
    '#ef4444', // Red
    '#8b5cf6', // Violet
    '#ec4899', // Pink
    '#06b6d4', // Cyan
    '#f97316', // Orange
  ];

  const totalCategoryValue = categoryData.reduce((acc: number, curr: any) => acc + curr.value, 0);

  return (
    <div className="space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Wallet Balance Card */}
        <motion.div 
          whileHover={{ y: -5, scale: 1.02 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-indigo-500/10 transition-all cursor-default group"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-indigo-500 text-white rounded-2xl shadow-lg shadow-indigo-200 group-hover:scale-110 transition-transform">
              <Wallet size={24} />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Patrimônio</span>
          </div>
          <p className="text-slate-500 text-sm font-medium mb-1">Saldo em Carteira</p>
          <h2 className={cn(
            "text-3xl font-black tracking-tight",
            walletBalance >= 0 ? "text-slate-900" : "text-rose-600"
          )}>{formatCurrency(walletBalance)}</h2>
          <div className="text-[10px] text-indigo-600 font-bold mt-2 flex items-center gap-1">
            <div className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-pulse"></div>
            Total Disponível Real
          </div>
        </motion.div>

        {/* Income Card */}
        <motion.div 
          whileHover={{ y: -5, scale: 1.02 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-emerald-500/10 transition-all cursor-default group"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-500 text-white rounded-2xl shadow-lg shadow-emerald-200 group-hover:scale-110 transition-transform">
              <TrendingUp size={24} />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Fluxo</span>
          </div>
          <p className="text-slate-500 text-sm font-medium mb-1">Entradas do Mês</p>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{formatCurrency(monthlyIncome)}</h2>
          <p className="text-[10px] text-emerald-600 font-bold mt-2">
            {monthlyIncome > 0 ? "Faturamento ativo" : "Aguardando entradas"}
          </p>
        </motion.div>

        {/* Expenses Card */}
        <motion.div 
          whileHover={{ y: -5, scale: 1.02 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-rose-500/10 transition-all cursor-default group"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-200 group-hover:scale-110 transition-transform">
              <TrendingDown size={24} />
            </div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Saídas</span>
          </div>
          <p className="text-slate-500 text-sm font-medium mb-1">Gastos Mensais</p>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{formatCurrency(monthlySpending)}</h2>
          <div className="flex items-center text-[10px] text-rose-500 font-bold mt-2">
            <span className="mr-1">Fluxo de saída monitorado</span>
          </div>
        </motion.div>

        {/* Savings Goal Card */}
        <motion.div 
          whileHover={{ y: -5, scale: 1.02 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.3 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-amber-500/10 transition-all cursor-default group"
        >
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-500 text-white rounded-2xl shadow-lg shadow-amber-200 group-hover:scale-110 transition-transform">
              <PieChart size={24} />
            </div>
            <div className="text-right">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">Meta Mensal</span>
              <span className="text-xs font-black text-amber-600">
                {Math.min(Math.round((economyAccumulated / savingsGoal) * 100), 100)}%
              </span>
            </div>
          </div>
          <p className="text-slate-500 text-sm font-medium mb-1">Objetivo Mensal</p>
          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">{formatCurrency(savingsGoal)}</h2>
          <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
            <div 
              className={cn(
                "h-full rounded-full transition-all duration-1000 ease-out shadow-[0_0_8px_rgba(245,158,11,0.5)]",
                (economyAccumulated / savingsGoal) >= 1 ? "bg-emerald-500" : "bg-amber-500"
              )}
              style={{ width: `${Math.min((economyAccumulated / savingsGoal) * 100, 100)}%` }}
            ></div>
          </div>
          <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-tighter">
            {economyAccumulated >= savingsGoal ? "🎯 Meta atingida!" : `Faltam ${formatCurrency(Math.max(0, savingsGoal - economyAccumulated))} para a meta`}
          </p>
        </motion.div>
      </div>


      {/* Charts Section */}
      <div className="grid grid-cols-1 gap-8">
        <MonthlyExpenseLineChart transactions={transactions} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-3 card p-8">
          <h3 className="text-xl font-bold text-slate-800 mb-8 flex items-center gap-2">
            <div className="w-2 h-6 bg-indigo-600 rounded-full"></div>
            Gastos por Categoria
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
            <div className="lg:col-span-3 h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={categoryData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                >
                  <defs>
                    <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={0.8}/>
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.3}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#64748b', fontSize: 12, fontWeight: 600 }}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#94a3b8', fontSize: 11 }}
                    tickFormatter={(value) => `R$ ${value}`}
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc', radius: 10 }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-4 shadow-2xl rounded-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
                            <p className="text-xs font-bold text-slate-400 uppercase mb-1">{payload[0].payload.name}</p>
                            <p className="text-lg font-bold text-indigo-600">{formatCurrency(payload[0].value as number)}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar 
                    dataKey="value" 
                    radius={[10, 10, 0, 0]} 
                    barSize={40}
                  >
                    {categoryData.map((entry: any, index: number) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={COLORS[index % COLORS.length]} 
                        fillOpacity={0.9}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="lg:col-span-2 flex flex-col justify-center">
              <div className="space-y-4 max-h-[350px] overflow-y-auto pr-4 custom-scrollbar">
                {categoryData.map((item: any, index: number) => {
                  const percentage = ((item.value / totalCategoryValue) * 100).toFixed(1);
                  return (
                    <div key={item.name} className="group flex flex-col gap-2 p-4 bg-slate-50 hover:bg-white hover:shadow-md transition-all rounded-2xl border border-transparent hover:border-slate-100">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-sm" style={{ backgroundColor: COLORS[index % COLORS.length] }}>
                            <span className="text-[10px] font-bold">{item.name.substring(0, 2).toUpperCase()}</span>
                          </div>
                          <span className="text-slate-700 font-bold">{item.name}</span>
                        </div>
                        <span className="font-bold text-slate-900">{formatCurrency(item.value)}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="flex-1 bg-slate-200 rounded-full h-1.5 overflow-hidden">
                          <div 
                            className="h-full rounded-full transition-all duration-1000" 
                            style={{ 
                              width: `${percentage}%`,
                              backgroundColor: COLORS[index % COLORS.length]
                            }}
                          ></div>
                        </div>
                        <span className="text-[10px] font-black text-slate-400 w-8">{percentage}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card overflow-hidden">
          <div className="p-6 border-b border-slate-100/60 flex justify-between items-center bg-slate-50/30">
            <h3 className="text-lg font-black text-slate-800 tracking-tight flex items-center gap-2">
              <Calendar size={20} className="text-indigo-600" />
              Próximas Contas
            </h3>
            <div className="flex items-center gap-3">
              <motion.button 
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }}
                onClick={onAddBill}
                className="p-2 bg-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-100 transition-all"
                title="Adicionar Conta"
              >
                <Plus size={18} />
              </motion.button>
              <button className="text-indigo-600 text-[10px] font-black uppercase tracking-widest hover:text-indigo-700 transition-colors">Ver Tudo</button>
            </div>
          </div>
          <div className="p-6 space-y-4">
            {pendingBills.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <Calendar size={32} className="mx-auto mb-2 opacity-20" />
                <p className="text-sm">Nenhuma conta pendente para este mês.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {pendingBills.map((bill: any) => (
                  <BillCard 
                    key={bill.id} 
                    bill={bill} 
                    onPay={onPayBill} 
                    onEdit={onEditBill} 
                    onDelete={onDeleteBill} 
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <SmartInsight 
            transactions={transactions} 
            budgets={budgets} 
            bills={bills} 
            savingsGoal={savingsGoal} 
            totalBalance={totalBalance} 
          />
        </div>
      </div>
    </div>
  );
}

function TransactionsView({ transactions, categories, initialType = 'all', onEdit, onDelete, onDeleteMultiple }: any) {
  const [pageSize, setPageSize] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState(initialType);
  const [openDropdownId, setOpenDropdownId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  useEffect(() => {
    setSelectedIds([]);
  }, [currentPage, searchTerm, categoryFilter, typeFilter]);

  const filteredTransactions = transactions.filter((t: any) => {
    const matchesSearch = t.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || t.category === categoryFilter;
    const matchesType = typeFilter === 'all' || t.type === typeFilter;
    return matchesSearch && matchesCategory && matchesType;
  });

  const totalPages = Math.ceil(filteredTransactions.length / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const currentTransactions = filteredTransactions.slice(startIndex, startIndex + pageSize);
  const endIndex = Math.min(startIndex + pageSize, filteredTransactions.length);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const formatDate = (dateStr: string) => {
    try {
      return format(parseISO(dateStr), 'dd/MM/yyyy');
    } catch (e) {
      return dateStr;
    }
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === currentTransactions.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(currentTransactions.map((t: any) => t.id));
    }
  };

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleBulkDelete = () => {
    onDeleteMultiple(selectedIds);
    setSelectedIds([]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Histórico de Transações</h1>
          <p className="text-slate-500 text-sm mt-1">Monitore e gerencie todas as suas entradas e saídas.</p>
        </div>
        
        <AnimatePresence>
          {selectedIds.length > 0 && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex items-center gap-3 bg-rose-50 border border-rose-100 px-4 py-2 rounded-xl shadow-sm"
            >
              <span className="text-sm font-bold text-rose-600">{selectedIds.length} selecionados</span>
              <button 
                onClick={handleBulkDelete}
                className="bg-rose-600 text-white px-4 py-1.5 rounded-lg text-xs font-bold hover:bg-rose-700 transition-colors flex items-center gap-2"
              >
                <Trash2 size={14} />
                Excluir Selecionados
              </button>
              <button 
                onClick={() => setSelectedIds([])}
                className="text-slate-400 hover:text-slate-600"
              >
                <X size={18} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="bg-white/60 backdrop-blur-md p-6 rounded-3xl border border-slate-200/60 shadow-sm">
        <div className="flex flex-col lg:flex-row gap-6">
          <div className="flex-1 relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por descrição ou estabelecimento..." 
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium"
            />
          </div>

          <div className="flex flex-wrap items-center gap-3 bg-slate-100/50 p-1.5 rounded-2xl border border-slate-200/40">
            {[
              { id: 'all', label: 'Todos' },
              { id: 'income', label: 'Receitas' },
              { id: 'expense', label: 'Despesas' }
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => {
                  setTypeFilter(type.id);
                  setCurrentPage(1);
                }}
                className={cn(
                  "relative px-6 py-2 text-xs font-black uppercase tracking-widest transition-all rounded-xl",
                  typeFilter === type.id ? "text-indigo-600" : "text-slate-500 hover:text-slate-800"
                )}
              >
                {typeFilter === type.id && (
                  <motion.div 
                    layoutId="filterTypePill"
                    className="absolute inset-0 bg-white shadow-sm rounded-xl border border-slate-200/60"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <span className="relative z-10">{type.label}</span>
              </button>
            ))}
          </div>

          <div className="w-full lg:w-64">
            <select 
              value={categoryFilter}
              onChange={(e) => {
                setCategoryFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full py-3 px-4 bg-white border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-sm font-medium appearance-none cursor-pointer"
              style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0\' stroke=\'%2364748b\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M19 9l-7 7-7-7\'/%3E%3C/svg%3E")', backgroundRepeat: 'no-repeat', backgroundPosition: 'right 1rem center', backgroundSize: '1em' }}
            >
              <option value="all">Todas as Categorias</option>
              {categories.map((c: string) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-6 py-4 w-10">
                  <input 
                    type="checkbox" 
                    checked={currentTransactions.length > 0 && selectedIds.length === currentTransactions.length}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500"
                  />
                </th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Origem</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Data</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Descrição</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Categoria</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Valor</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Status</th>
                <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center min-w-[80px]">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {currentTransactions.map((t: any, index: number) => (
                <tr 
                  key={t.id} 
                  className={cn(
                    "hover:bg-slate-50 transition-colors",
                    selectedIds.includes(t.id) && "bg-indigo-50/30"
                  )}
                >
                  <td className="px-6 py-4">
                    <input 
                      type="checkbox" 
                      checked={selectedIds.includes(t.id)}
                      onChange={() => toggleSelect(t.id)}
                      className="w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500"
                    />
                  </td>
                  <td className="px-6 py-4 text-center">
                    {t.origin === 'whatsapp' ? (
                      <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto" title="WhatsApp">
                        <MessageSquare size={14} />
                      </div>
                    ) : t.origin === 'audio' ? (
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mx-auto" title="Áudio">
                        <Mic size={14} />
                      </div>
                    ) : t.origin === 'simulator' ? (
                      <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto" title="Simulador">
                        <IterationCcw size={14} />
                      </div>
                    ) : (
                      <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto" title="Manual">
                        <Pencil size={14} />
                      </div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">{formatDate(t.date)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">
                    <div className="flex items-center gap-2">
                    {t.description}
                    {t.needsAI && <Sparkles size={12} className="text-amber-500 animate-pulse" title="Processando com IA..." />}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-xs font-medium",
                      t.category === 'Alimentação' ? "bg-orange-100 text-orange-700" :
                      t.category === 'Salário' ? "bg-emerald-100 text-emerald-700" :
                      t.category === 'Entretenimento' ? "bg-purple-100 text-purple-700" :
                      t.category === 'Transporte' ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-700"
                    )}>
                      {t.category}
                    </span>
                  </td>
                  <td className={cn(
                    "px-6 py-4 whitespace-nowrap text-sm text-right font-semibold",
                    t.type === 'income' ? "text-emerald-600" : "text-red-600"
                  )}>
                    {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <span className={cn(
                      "text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-md",
                      t.status === 'pending' ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"
                    )}>
                      {t.status === 'pending' ? 'Pendente' : 'OK'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center relative">
                    <button 
                      onClick={() => setOpenDropdownId(openDropdownId === t.id ? null : t.id)}
                      className="text-slate-400 hover:text-slate-600 p-2 rounded-full hover:bg-slate-100 transition-colors"
                    >
                      <MoreVertical size={20} />
                    </button>
                    
                    {openDropdownId === t.id && (
                      <>
                        <div 
                          className="fixed inset-0 z-10" 
                          onClick={() => setOpenDropdownId(null)}
                        ></div>
                        <div className={cn(
                          "absolute right-0 w-44 bg-white/90 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-200/60 py-2.5 z-20 animate-in fade-in zoom-in duration-200 ring-1 ring-black/5",
                          index >= currentTransactions.length - 2 && currentTransactions.length > 3 ? "bottom-full mb-2" : "mt-2"
                        )}>
                          <button 
                            onClick={() => {
                              onEdit(t);
                              setOpenDropdownId(null);
                            }}
                            className="w-full text-left px-4 py-2.5 text-xs font-black uppercase tracking-widest text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 flex items-center gap-3 transition-all"
                          >
                            <div className="p-1.5 bg-indigo-100 rounded-lg text-indigo-600">
                              <Pencil size={14} />
                            </div>
                            Editar
                          </button>
                          <div className="my-1 border-t border-slate-100"></div>
                          <button 
                            onClick={() => {
                              onDelete(t.id);
                              setOpenDropdownId(null);
                            }}
                            className="w-full text-left px-4 py-2.5 text-xs font-black uppercase tracking-widest text-rose-600 hover:bg-rose-50 flex items-center gap-3 transition-all"
                          >
                            <div className="p-1.5 bg-rose-100 rounded-lg text-rose-600">
                              <Trash2 size={14} />
                            </div>
                            Excluir
                          </button>
                        </div>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-6 py-5 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between bg-slate-50/80 backdrop-blur-sm gap-4">
          <div className="flex items-center gap-6">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">
              Mostrando <span className="text-slate-900">{filteredTransactions.length > 0 ? startIndex + 1 : 0}</span> — <span className="text-slate-900">{endIndex}</span> de <span className="text-slate-900">{filteredTransactions.length}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Página:</span>
              <select 
                value={pageSize} 
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="text-xs font-black bg-white border border-slate-200 rounded-xl focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 py-1.5 px-3 transition-all cursor-pointer outline-none"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={50}>50</option>
              </select>
            </div>
          </div>
          <div className="flex gap-3">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="px-5 py-2.5 text-xs font-black uppercase tracking-widest text-slate-600 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Anterior
            </motion.button>
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages || totalPages === 0}
              className="px-5 py-2.5 text-xs font-black uppercase tracking-widest text-white bg-gradient-to-r from-indigo-600 to-indigo-700 rounded-xl shadow-lg shadow-indigo-100 hover:shadow-xl hover:shadow-indigo-200 disabled:opacity-30 disabled:cursor-not-allowed transition-all"
            >
              Próximo
            </motion.button>
          </div>
        </div>
      </div>
    </div>
  );
}

function BudgetsView({ 
  budgets, 
  transactions, 
  revenueGoal,
  userProfile,
  onAddTransaction, 
  onOpenSettings, 
  onOpenRevenueGoalModal,
  onOpenSavingsGoalModal,
  onEditCategoryGoal,
  onRemoveCategory,
  onOpenReport, 
  onViewTransactions, 
  onFixCategories 
}: { 
  budgets: any[], 
  transactions: Transaction[], 
  revenueGoal: number,
  userProfile: any,
  onAddTransaction: () => void, 
  onOpenSettings: () => void,
  onOpenRevenueGoalModal: () => void,
  onOpenSavingsGoalModal: () => void,
  onEditCategoryGoal: (category: string) => void,
  onRemoveCategory: (category: string) => void,
  onOpenReport: () => void,
  onViewTransactions: (type: 'all' | 'income' | 'expense') => void,
  onFixCategories: () => void
}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [chartTimeframe, setChartTimeframe] = useState<'monthly' | 'weekly' | 'annual'>('monthly');
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };

  const now = new Date();
  const startOfCurrentMonth = startOfMonth(now);
  const endOfCurrentMonth = endOfMonth(now);

  // Calculate current month's income and expenses
  const currentMonthTransactions = transactions.filter(t => {
    const d = parseISO(t.date);
    return d >= startOfCurrentMonth && d <= endOfCurrentMonth;
  });

  const currentMonthIncome = currentMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((acc, t) => acc + t.amount, 0);

  const currentMonthExpenses = currentMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc, t) => acc + t.amount, 0);

  // Calculate accumulated savings from previous months
  const previousTransactions = transactions.filter(t => parseISO(t.date) < startOfCurrentMonth);
  const previousIncome = previousTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
  const previousExpenses = previousTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
  const accumulatedSavings = previousIncome - previousExpenses;

  const monthlyBalance = currentMonthIncome - currentMonthExpenses + accumulatedSavings;

  // Calculate current month's income per category for goals
  const currentMonthIncomeByCategory = currentMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});

  // Calculate current month's expenses per category for goals
  const currentMonthExpensesByCategory = currentMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});

  const totalReceived = revenueGoal > 0 
    ? currentMonthIncome 
    : budgets.reduce((acc, b) => {
        const inc = currentMonthIncomeByCategory[b.category] || 0;
        const exp = currentMonthExpensesByCategory[b.category] || 0;
        return acc + Math.abs(inc - exp);
      }, 0);

  const totalGoal = revenueGoal > 0 ? revenueGoal : budgets.reduce((acc: number, b: any) => acc + b.limit, 0);
  const progressPercent = totalGoal > 0 ? (totalReceived / totalGoal) * 100 : 0;
  const remaining = totalGoal - totalReceived;

  // Projection
  const daysInMonth = now.getDate();
  const totalDays = endOfCurrentMonth.getDate();
  const dailyAverage = totalReceived / daysInMonth;
  const projection = dailyAverage * totalDays;
  const projectionPercent = totalGoal > 0 ? (projection / totalGoal) * 100 : 0;

  // Goals analysis
  const goalsWithProgress = budgets.map(b => {
    const income = currentMonthIncomeByCategory[b.category] || 0;
    const expense = currentMonthExpensesByCategory[b.category] || 0;
    // Heurística: se a categoria tem mais gastos que ganhos, tratamos como orçamento de despesa.
    // Caso contrário, tratamos como meta de receita. O valor absoluto do saldo reflete o progresso.
    const achieved = Math.abs(income - expense);
    const percent = b.limit > 0 ? (achieved / b.limit) * 100 : 0;
    return { ...b, achieved, percent, income, expense };
  });

  const closestToCompletion = [...goalsWithProgress]
    .filter(g => g.percent < 100 && g.limit > 0)
    .sort((a, b) => b.percent - a.percent)[0];
  
  const mostDelayed = [...goalsWithProgress]
    .filter(g => g.percent < 100 && g.limit > 0)
    .sort((a, b) => a.percent - b.percent)[0];

  // History Chart Data
  const getIncomeHistory = () => {
    const incomeTransactions = transactions.filter((t: any) => t.type === 'income');
    
    if (chartTimeframe === 'monthly') {
      const months = Array.from({ length: 12 }, (_, i) => {
        const d = subMonths(now, 11 - i);
        return {
          name: format(d, 'MMM/yy', { locale: ptBR }).replace(/^\w/, (c) => c.toUpperCase()),
          monthKey: format(d, 'yyyy-MM'),
          value: 0
        };
      });

      incomeTransactions.forEach((t: any) => {
        const date = parseISO(t.date);
        const monthKey = format(date, 'yyyy-MM');
        const monthData = months.find(m => m.monthKey === monthKey);
        if (monthData) monthData.value += t.amount;
      });
      return months;
    } else if (chartTimeframe === 'weekly') {
      const weeks = Array.from({ length: 8 }, (_, i) => {
        const d = subWeeks(now, 7 - i);
        return {
          name: `Sem ${format(d, 'w')}`,
          weekKey: format(d, 'yyyy-ww'),
          value: 0
        };
      });

      incomeTransactions.forEach((t: any) => {
        const date = parseISO(t.date);
        const weekKey = format(date, 'yyyy-ww');
        const weekData = weeks.find(w => w.weekKey === weekKey);
        if (weekData) weekData.value += t.amount;
      });
      return weeks;
    } else {
      const years = Array.from({ length: 3 }, (_, i) => {
        const d = subYears(now, 2 - i);
        return {
          name: format(d, 'yyyy'),
          yearKey: format(d, 'yyyy'),
          value: 0
        };
      });

      incomeTransactions.forEach((t: any) => {
        const date = parseISO(t.date);
        const yearKey = format(date, 'yyyy');
        const yearData = years.find(y => y.yearKey === yearKey);
        if (yearData) yearData.value += t.amount;
      });
      return years;
    }
  };

  const historyData = getIncomeHistory();

  return (
    <div className="space-y-8 pb-12">
      {/* Glassmorphism Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-3xl bg-emerald-600 p-8 text-white shadow-2xl shadow-emerald-200/50"
      >
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-64 h-64 bg-emerald-400/20 rounded-full blur-3xl"></div>
        
        <div className="relative flex flex-col lg:flex-row justify-between gap-8">
          <div className="flex-1">
            <div className="flex items-center gap-2 text-emerald-100 mb-2 font-medium">
              <Target size={18} />
              <span>Progresso das Metas de Receita</span>
            </div>
            <h2 className="text-5xl font-black tracking-tight mb-4 flex items-baseline">
              {formatCurrency(totalReceived)}
              <div className="flex items-center gap-2 ml-3">
                <span className="text-xl font-medium opacity-60">/ {formatCurrency(totalGoal)}</span>
                <button 
                  onClick={onOpenRevenueGoalModal}
                  className="p-1.5 hover:bg-white/20 rounded-lg transition-all group"
                  title="Editar Meta de Receita"
                >
                  <Pencil size={16} className="opacity-60 group-hover:opacity-100" />
                </button>
              </div>
            </h2>
            
            <div className="space-y-4">
              <div className="w-full bg-white/20 rounded-full h-4 overflow-hidden backdrop-blur-sm">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(progressPercent, 100)}%` }}
                  transition={{ duration: 1.5, ease: "easeOut" }}
                  className="h-full bg-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.5)]"
                />
              </div>
              
              <div className="flex flex-wrap items-center gap-6 text-sm font-medium">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-white animate-pulse"></div>
                  <span>{progressPercent.toFixed(1)}% atingido</span>
                </div>
                {remaining > 0 ? (
                  <div className="flex items-center gap-2 text-emerald-50">
                    <TrendingUp size={16} />
                    <span>Faltam {formatCurrency(remaining)} para a meta</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-emerald-50">
                    <CheckCircle2 size={16} />
                    <span>Parabéns! Meta concluída 🎉</span>
                  </div>
                )}
              </div>
            </div>
          </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-end mt-4 lg:mt-0">
              <div className="flex flex-col sm:flex-row gap-3">
                <motion.button 
                  whileHover={{ scale: 1.02, y: -2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onAddTransaction}
                  className="bg-white text-emerald-600 px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-emerald-900/10 hover:shadow-emerald-900/20 transition-all flex items-center justify-center gap-3 border border-emerald-50"
                >
                  <div className="p-1 bg-emerald-100 rounded-lg group-hover:bg-emerald-200 transition-colors">
                    <Plus size={20} />
                  </div>
                  <span>Nova Receita</span>
                </motion.button>
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={onOpenReport}
                  className="bg-emerald-700/50 backdrop-blur-md text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-700/70 transition-all border border-white/20 whitespace-nowrap"
                >
                  Ver Relatório Completo
                </motion.button>
              </div>
            </div>
        </div>
      </motion.div>

      {/* Distribuição Inteligente da Receita */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="card p-8 bg-gradient-to-br from-white to-emerald-50/30 border-emerald-100/50 shadow-xl shadow-emerald-900/5"
      >
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-emerald-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-emerald-200">
              <PieChart size={28} />
            </div>
            <div>
              <h3 className="text-xl font-bold text-slate-800 tracking-tight">Distribuição Inteligente da Receita</h3>
              <p className="text-sm text-slate-500 font-medium">Planejamento automático baseado na regra 50-30-20</p>
            </div>
          </div>
          <div className="text-right bg-white px-6 py-3 rounded-2xl border border-emerald-100 shadow-sm">
            <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">Receita Total do Mês</p>
            <p className="text-2xl font-black text-slate-800">{formatCurrency(currentMonthIncome)}</p>
          </div>
        </div>

        {/* Lógica de Distribuição */}
        {(() => {
          let needsPct = 50;
          let leisurePct = 30;
          let investmentsPct = 20;

          if (userProfile?.distributionMode === 'accelerated') {
            needsPct = 50;
            leisurePct = 20;
            investmentsPct = 30;
          } else if (userProfile?.distributionMode === 'custom' && userProfile?.customDistribution) {
            needsPct = userProfile.customDistribution.needs || 50;
            leisurePct = userProfile.customDistribution.leisure || 30;
            investmentsPct = userProfile.customDistribution.investments || 20;
          }

          const needsValue = currentMonthIncome * (needsPct / 100);
          const leisureValue = currentMonthIncome * (leisurePct / 100);
          const investmentsValue = currentMonthIncome * (investmentsPct / 100);

          return (
            <div className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Necessidades */}
                <div className="space-y-4 group">
                  <div className="flex justify-between items-end">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-slate-100 text-slate-600 rounded-xl flex items-center justify-center">
                        <Layout size={16} />
                      </div>
                      <span className="text-sm font-bold text-slate-700">Necessidades</span>
                    </div>
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{needsPct}%</span>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 group-hover:border-indigo-200 transition-all">
                    <p className="text-lg font-black text-slate-800">{formatCurrency(needsValue)}</p>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${needsPct}%` }}
                      className="h-full bg-slate-400 rounded-full"
                    />
                  </div>
                </div>

                {/* Lazer */}
                <div className="space-y-4 group">
                  <div className="flex justify-between items-end">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center">
                        <Zap size={16} />
                      </div>
                      <span className="text-sm font-bold text-slate-700">Lazer</span>
                    </div>
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{leisurePct}%</span>
                  </div>
                  <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100 group-hover:border-amber-300 transition-all">
                    <p className="text-lg font-black text-slate-800">{formatCurrency(leisureValue)}</p>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${leisurePct}%` }}
                      className="h-full bg-amber-400 rounded-full"
                    />
                  </div>
                </div>

                {/* Investimentos */}
                <div className="space-y-4 group">
                  <div className="flex justify-between items-end">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
                        <TrendingUp size={16} />
                      </div>
                      <span className="text-sm font-bold text-slate-700">Investimentos</span>
                    </div>
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{investmentsPct}%</span>
                  </div>
                  <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100 group-hover:border-emerald-300 transition-all">
                    <p className="text-lg font-black text-slate-800">{formatCurrency(investmentsValue)}</p>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${investmentsPct}%` }}
                      className="h-full bg-emerald-500 rounded-full"
                    />
                  </div>
                </div>
              </div>

              {/* Indicador de Performance */}
              <div className="pt-6 border-t border-emerald-100">
                <div className={cn(
                  "flex items-center gap-3 p-4 rounded-2xl font-bold text-sm transition-all",
                  investmentsPct >= 20 
                    ? "bg-emerald-50 text-emerald-700 border border-emerald-100" 
                    : "bg-rose-50 text-rose-700 border border-rose-100"
                )}>
                  {investmentsPct >= 20 ? (
                    <CheckCircle2 size={20} className="shrink-0" />
                  ) : (
                    <AlertCircle size={20} className="shrink-0 animate-pulse" />
                  )}
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                    <span>Você está investindo <span className="underline decoration-2 underline-offset-4">{investmentsPct}%</span> da sua renda.</span>
                    {investmentsPct < 20 && (
                      <span className="text-xs font-black uppercase tracking-tighter opacity-80">
                        ⚠️ Atenção: investimento abaixo do ideal
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })()}
      </motion.div>

      {/* Indicators Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card p-6 flex items-center gap-4 bg-gradient-to-br from-white to-slate-50">
          <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center shadow-sm">
            <Activity size={24} />
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Ritmo Atual</p>
            <p className="text-lg font-bold text-slate-800">
              {progressPercent >= (daysInMonth / totalDays * 100) ? (
                <span className="text-emerald-600 flex items-center gap-1">
                  <TrendingUp size={16} /> Acima da meta
                </span>
              ) : (
                <span className="text-amber-600 flex items-center gap-1">
                  <TrendingDown size={16} /> Abaixo do ritmo
                </span>
              )}
            </p>
          </div>
        </div>

        {closestToCompletion && (
          <div className="card p-6 flex items-center gap-4 bg-gradient-to-br from-white to-slate-50">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center shadow-sm">
              <Zap size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Mais Próxima</p>
              <p className="text-lg font-bold text-slate-800 line-clamp-1">{closestToCompletion.category}</p>
              <p className="text-[10px] text-emerald-600 font-bold">{closestToCompletion.percent.toFixed(0)}% concluído</p>
            </div>
          </div>
        )}

        {mostDelayed && (
          <div className="card p-6 flex items-center gap-4 bg-gradient-to-br from-white to-slate-50">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center shadow-sm">
              <AlertCircle size={24} />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Mais Atrasada</p>
              <p className="text-lg font-bold text-slate-800 line-clamp-1">{mostDelayed.category}</p>
              <p className="text-[10px] text-rose-600 font-bold">{mostDelayed.percent.toFixed(0)}% concluído</p>
            </div>
          </div>
        )}
      </div>

      {/* Interactive History Chart */}
      <div className="card p-8">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Histórico de Receitas</h3>
            <p className="text-sm text-slate-500">Acompanhe a evolução dos seus ganhos</p>
          </div>
          
          <div className="flex bg-slate-100/50 p-1.5 rounded-2xl border border-slate-200/40">
            {(['monthly', 'weekly', 'annual'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setChartTimeframe(t)}
                className={cn(
                  "relative px-5 py-2 text-xs font-black uppercase tracking-widest transition-all rounded-xl",
                  chartTimeframe === t ? "text-emerald-700" : "text-slate-500 hover:text-slate-700"
                )}
              >
                {chartTimeframe === t && (
                  <motion.div 
                    layoutId="budgetChartPill"
                    className="absolute inset-0 bg-white shadow-sm rounded-xl border border-slate-200/60"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
                <span className="relative z-10">
                  {t === 'monthly' ? 'Mensal' : t === 'weekly' ? 'Semanal' : 'Anual'}
                </span>
              </button>
            ))}
          </div>
        </div>
        
        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={historyData as any[]}>
              <defs>
                <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#94a3b8', fontSize: 12 }}
                dy={10}
              />
              <YAxis 
                hide 
                domain={['auto', 'auto']}
              />
              <Tooltip 
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="bg-white p-4 rounded-2xl shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
                        <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">{payload[0].payload.name}</p>
                        <p className="text-lg font-black text-emerald-600">{formatCurrency(payload[0].value as number)}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke="#10b981" 
                strokeWidth={4}
                fillOpacity={1} 
                fill="url(#colorIncome)" 
                animationDuration={1500}
                activeDot={{ r: 8, strokeWidth: 0, fill: '#10b981' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Goal Cards Grid */}
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-xl font-bold text-slate-800">Metas por Categoria</h3>
          <p className="text-sm text-slate-500">{budgets.length} metas ativas</p>
        </div>

        {budgets.length === 0 ? (
          <div className="card p-12 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4">
              <Target className="text-slate-300" size={40} />
            </div>
            <h4 className="text-lg font-bold text-slate-800">Nenhuma meta definida</h4>
            <p className="text-slate-500 max-w-xs mt-2 mb-6">Comece definindo seus objetivos de receita para cada categoria.</p>
            <button 
              onClick={onOpenSettings}
              className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-100"
            >
              Criar Primeira Meta
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {goalsWithProgress.map((g, idx) => {
              const isIncomeGoal = g.income >= g.expense;
              
              let colorClass = "";
              let textClass = "";
              let bgClass = "";
              let statusLabel = "";
              let statusIcon = null;

              if (isIncomeGoal) {
                // Lógica para Metas de Receita
                if (g.percent >= 100) {
                  colorClass = "bg-emerald-500";
                  textClass = "text-emerald-600";
                  bgClass = "bg-emerald-50";
                  statusLabel = "Meta Atingida";
                  statusIcon = <CheckCircle2 size={12} />;
                } else if (g.percent >= 50) {
                  colorClass = "bg-amber-500";
                  textClass = "text-amber-600";
                  bgClass = "bg-amber-50";
                  statusLabel = "Em Progresso";
                  statusIcon = <Activity size={12} />;
                } else {
                  colorClass = "bg-rose-500";
                  textClass = "text-rose-600";
                  bgClass = "bg-rose-50";
                  statusLabel = "Abaixo da Meta";
                  statusIcon = <TrendingDown size={12} />;
                }
              } else {
                // Lógica para Limites de Despesa
                if (g.percent >= 100) {
                  colorClass = "bg-rose-500";
                  textClass = "text-rose-600";
                  bgClass = "bg-rose-50";
                  statusLabel = "Limite Excedido";
                  statusIcon = <AlertCircle size={12} />;
                } else if (g.percent >= 80) {
                  colorClass = "bg-amber-500";
                  textClass = "text-amber-600";
                  bgClass = "bg-amber-50";
                  statusLabel = "Atenção";
                  statusIcon = <Zap size={12} />;
                } else {
                  colorClass = "bg-emerald-500";
                  textClass = "text-emerald-600";
                  bgClass = "bg-emerald-50";
                  statusLabel = "Dentro do Limite";
                  statusIcon = <CheckCircle2 size={12} />;
                }
              }

              return (
                <motion.div 
                  key={g.category}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className={cn(
                    "card p-6 group hover:shadow-xl hover:-translate-y-1 transition-all cursor-pointer relative overflow-hidden border-2",
                    g.percent >= 100 && !isIncomeGoal ? "border-rose-100 bg-rose-50/10" : "border-transparent"
                  )}
                  onClick={() => onEditCategoryGoal(g.category)}
                >
                  <div className="absolute top-4 right-4 flex gap-1 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity z-20">
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onEditCategoryGoal(g.category);
                      }}
                      className="p-2 bg-white shadow-lg border border-slate-100 rounded-xl text-slate-400 hover:text-indigo-600 transition-colors"
                      title="Editar Meta"
                    >
                      <Pencil size={14} />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveCategory(g.category);
                      }}
                      className="p-2 bg-white shadow-lg border border-slate-100 rounded-xl text-slate-400 hover:text-rose-600 transition-colors"
                      title="Excluir Meta"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex items-center gap-3 mb-6">
                    <div className={cn("p-3 rounded-2xl", bgClass, textClass)}>
                      {isIncomeGoal ? <TrendingUp size={24} /> : <Wallet size={24} />}
                    </div>
                    <div className={cn("px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider", bgClass, textClass)}>
                      {g.percent.toFixed(0)}%
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="text-lg font-bold text-slate-800 group-hover:text-emerald-600 transition-colors">{g.category}</h4>
                    <div className={cn("flex items-center gap-1.5 mt-1 font-bold text-[10px] uppercase tracking-tighter", textClass)}>
                      {statusIcon}
                      <span>{statusLabel}</span>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-end">
                      <div>
                        <p className="text-2xl font-black text-slate-800">{formatCurrency(g.achieved)}</p>
                        <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">
                          {isIncomeGoal ? "Meta" : "Limite"}: {formatCurrency(g.limit)}
                        </p>
                      </div>
                    </div>

                    <div className="relative h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(g.percent, 100)}%` }}
                        transition={{ duration: 1, delay: 0.2 + idx * 0.1 }}
                        className={cn("h-full rounded-full", colorClass)}
                      />
                    </div>

                    {g.percent < 100 && isIncomeGoal && (
                      <p className="text-[10px] font-bold text-slate-500">
                        Faltam <span className={textClass}>{formatCurrency(g.limit - g.achieved)}</span> para o objetivo.
                      </p>
                    )}
                    
                    {g.percent >= 100 && !isIncomeGoal && (
                      <p className="text-[10px] font-bold text-rose-600 bg-rose-50 p-2 rounded-lg border border-rose-100">
                        Você ultrapassou o limite em {formatCurrency(g.achieved - g.limit)}!
                      </p>
                    )}
                  </div>
                </motion.div>
              );
            })}
            
            <button 
              onClick={onOpenSettings}
              className="border-2 border-dashed border-slate-200 rounded-3xl p-6 flex flex-col items-center justify-center text-slate-400 hover:border-emerald-500 hover:text-emerald-600 hover:bg-emerald-50/50 transition-all group min-h-[240px]"
            >
              <div className="bg-slate-50 group-hover:bg-emerald-100 p-4 rounded-2xl mb-3 transition-colors">
                <Plus size={32} />
              </div>
              <span className="font-black text-sm uppercase tracking-widest">Nova Meta</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function SettingsModal({ 
  onClose, 
  savingsGoal, 
  setSavingsGoal, 
  budgets, 
  setBudgets, 
  categories, 
  onAddCategory, 
  onRemoveCategory,
  userProfile,
  onUpdateProfile
}: any) {
  const [localSavingsGoal, setLocalSavingsGoal] = useState(savingsGoal);
  const [whatsappPhone, setWhatsappPhone] = useState(userProfile?.whatsappPhone || '');
  const [newCategoryName, setNewCategoryName] = useState('');
  const [distributionMode, setDistributionMode] = useState(userProfile?.distributionMode || 'default');
  const [customDistribution, setCustomDistribution] = useState(userProfile?.customDistribution || { needs: 50, leisure: 30, investments: 20 });
  
  // Create a map of existing budgets for easy lookup
  const initialBudgetMap = budgets.reduce((acc: any, b: any) => {
    acc[b.category] = b.limit;
    return acc;
  }, {});

  const [localLimits, setLocalLimits] = useState<{ [key: string]: number }>(() => {
    const limits: { [key: string]: number } = {};
    categories.forEach((cat: string) => {
      limits[cat] = initialBudgetMap[cat] || 0;
    });
    return limits;
  });

  const handleLimitChange = (category: string, limit: string) => {
    setLocalLimits(prev => ({
      ...prev,
      [category]: parseFloat(limit) || 0
    }));
  };

  const handleAddCategory = () => {
    if (newCategoryName.trim() && !categories.includes(newCategoryName.trim())) {
      const name = newCategoryName.trim();
      onAddCategory(name);
      setLocalLimits(prev => ({ ...prev, [name]: 0 }));
      setNewCategoryName('');
    }
  };

  const handleRemoveCategory = (category: string) => {
    onRemoveCategory(category);
    setLocalLimits(prev => {
      const newLimits = { ...prev };
      delete newLimits[category];
      return newLimits;
    });
  };

  const handleSave = () => {
    setSavingsGoal(localSavingsGoal);
    
    // Save distribution settings
    onUpdateProfile({
      distributionMode,
      customDistribution,
      whatsappPhone
    });
    
    // Convert limits back to Budget objects
    const newBudgets = Object.entries(localLimits).map(([category, limit]) => {
      const existingBudget = budgets.find((b: any) => b.category === category);
      return {
        category,
        limit,
        spent: existingBudget ? existingBudget.spent : 0
      };
    });
    
    setBudgets(newBudgets);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-[32px] shadow-2xl border border-slate-100 w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in duration-300">
        <header className="px-10 pt-10 pb-6 flex justify-between items-start shrink-0">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-800">Configurações</h1>
            <p className="text-slate-500 mt-1">Ajuste suas metas de economia e receita.</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition-all">
            <X size={24} />
          </button>
        </header>

        <div className="px-10 pb-6 space-y-8 overflow-y-auto custom-scrollbar flex-1">
          {/* Metas Gerais */}
          <div className="space-y-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.15em]">Metas Gerais</h3>
            <div className="space-y-3">
              <label className="block text-sm font-bold text-slate-700 ml-1">Meta de Economia</label>
              <div className="relative group">
                <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 font-medium">R$</span>
                <input 
                  type="number" 
                  value={localSavingsGoal}
                  onChange={(e) => setLocalSavingsGoal(parseFloat(e.target.value) || 0)}
                  className="block w-full pl-12 pr-6 py-4 border-transparent bg-slate-50 rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-lg font-semibold text-slate-800"
                  placeholder="0,00"
                />
              </div>
            </div>

            {/* WhatsApp Integration */}
            <div className="space-y-3 pt-4">
              <label className="flex items-center gap-2 text-sm font-bold text-slate-700 ml-1">
                <Hash size={16} className="text-indigo-500" />
                Vincular WhatsApp
              </label>
              <p className="text-[10px] text-slate-400 ml-1 mb-1 italic">
                Formato: +5511999999999 (DDI + DDD + Número)
              </p>
              <div className="relative group">
                <input 
                  type="text" 
                  value={whatsappPhone}
                  onChange={(e) => setWhatsappPhone(e.target.value)}
                  className="block w-full px-6 py-4 border-transparent bg-slate-50 rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-lg font-semibold text-slate-800"
                  placeholder="+5511999999999"
                />
                {whatsappPhone && !whatsappPhone.startsWith('+') && (
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-rose-500" title="Deve começar com +">
                    <AlertCircle size={20} />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Distribuição de Receita */}
          <div className="space-y-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.15em]">Distribuição de Receita (Regra 50-30-20)</h3>
            <div className="grid grid-cols-1 gap-3">
              <button
                onClick={() => setDistributionMode('default')}
                className={cn(
                  "flex items-center justify-between p-4 rounded-2xl border transition-all text-left",
                  distributionMode === 'default' 
                    ? "bg-emerald-50 border-emerald-200 shadow-sm" 
                    : "bg-slate-50 border-transparent hover:bg-slate-100"
                )}
              >
                <div>
                  <p className="text-sm font-bold text-slate-800">Modo Padrão</p>
                  <p className="text-xs text-slate-500">50% Necessidades / 30% Lazer / 20% Investimentos</p>
                </div>
                {distributionMode === 'default' && <CheckCircle2 size={20} className="text-emerald-600" />}
              </button>

              <button
                onClick={() => setDistributionMode('accelerated')}
                className={cn(
                  "flex items-center justify-between p-4 rounded-2xl border transition-all text-left",
                  distributionMode === 'accelerated' 
                    ? "bg-indigo-50 border-indigo-200 shadow-sm" 
                    : "bg-slate-50 border-transparent hover:bg-slate-100"
                )}
              >
                <div>
                  <p className="text-sm font-bold text-slate-800">Modo Acelerado</p>
                  <p className="text-xs text-slate-500">50% Necessidades / 20% Lazer / 30% Investimentos</p>
                </div>
                {distributionMode === 'accelerated' && <CheckCircle2 size={20} className="text-indigo-600" />}
              </button>

              <button
                onClick={() => setDistributionMode('custom')}
                className={cn(
                  "flex items-center justify-between p-4 rounded-2xl border transition-all text-left",
                  distributionMode === 'custom' 
                    ? "bg-amber-50 border-amber-200 shadow-sm" 
                    : "bg-slate-50 border-transparent hover:bg-slate-100"
                )}
              >
                <div>
                  <p className="text-sm font-bold text-slate-800">Personalizado</p>
                  <p className="text-xs text-slate-500">Defina seus próprios percentuais</p>
                </div>
                {distributionMode === 'custom' && <CheckCircle2 size={20} className="text-amber-600" />}
              </button>
            </div>

            {distributionMode === 'custom' && (
              <div className="p-6 bg-amber-50/30 rounded-[24px] border border-amber-100 space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Necessidades</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={customDistribution.needs}
                        onChange={(e) => setCustomDistribution(prev => ({ ...prev, needs: parseInt(e.target.value) || 0 }))}
                        className="w-full px-3 py-3 bg-white border-transparent rounded-xl focus:ring-2 focus:ring-amber-500 text-center font-bold text-slate-800"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Lazer</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={customDistribution.leisure}
                        onChange={(e) => setCustomDistribution(prev => ({ ...prev, leisure: parseInt(e.target.value) || 0 }))}
                        className="w-full px-3 py-3 bg-white border-transparent rounded-xl focus:ring-2 focus:ring-amber-500 text-center font-bold text-slate-800"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">%</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Investimentos</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={customDistribution.investments}
                        onChange={(e) => setCustomDistribution(prev => ({ ...prev, investments: parseInt(e.target.value) || 0 }))}
                        className="w-full px-3 py-3 bg-white border-transparent rounded-xl focus:ring-2 focus:ring-amber-500 text-center font-bold text-slate-800"
                      />
                      <span className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-xs">%</span>
                    </div>
                  </div>
                </div>
                {customDistribution.needs + customDistribution.leisure + customDistribution.investments !== 100 && (
                  <p className="text-[10px] font-bold text-rose-500 text-center">
                    A soma dos percentuais deve ser 100% (Atual: {customDistribution.needs + customDistribution.leisure + customDistribution.investments}%)
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Metas por Categoria */}
          <div className="space-y-5">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.15em]">Metas de Receita por Categoria</h3>
            
            <div className="flex gap-3">
              <input 
                type="text"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="Nova categoria..."
                className="flex-1 px-5 py-4 border-transparent bg-slate-50 rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm font-medium"
                onKeyDown={(e) => e.key === 'Enter' && handleAddCategory()}
              />
              <button 
                onClick={handleAddCategory}
                className="p-4 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm active:scale-95"
              >
                <Plus size={24} />
              </button>
            </div>

            <div className="space-y-4 pt-2">
              {Object.entries(localLimits).map(([category, limit]) => (
                <div key={category} className="space-y-3 group animate-in fade-in slide-in-from-top-2 duration-300">
                  <div className="flex justify-between items-center px-1">
                    <label className="block text-sm font-bold text-slate-700">{category}</label>
                    <button 
                      onClick={() => handleRemoveCategory(category)}
                      className="text-slate-300 hover:text-rose-500 p-1 hover:bg-rose-50 rounded-lg transition-all"
                      title="Excluir Categoria"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 font-medium text-sm">R$</span>
                    <input 
                      type="number" 
                      value={limit}
                      onChange={(e) => handleLimitChange(category, e.target.value)}
                      className="block w-full pl-12 pr-6 py-3 border-transparent bg-slate-50 rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-base font-semibold text-slate-800"
                      placeholder="0,00"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <footer className="px-10 py-8 border-t border-slate-50 bg-white shrink-0 flex gap-4">
          <button 
            onClick={onClose}
            className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 active:scale-95 transition-all"
          >
            Cancelar
          </button>
          <button 
            onClick={handleSave}
            className="flex-[2] px-6 py-4 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-700 shadow-xl shadow-indigo-100 active:scale-[0.98] transition-all"
          >
            Salvar Alterações
          </button>
        </footer>
      </div>
    </div>
  );
}

function BillModal({ onClose, onSubmit, categories, initialData }: { onClose: () => void, onSubmit: (data: any) => void, categories: string[], initialData?: Bill | null }) {
  const [name, setName] = useState(initialData?.name || '');
  const [amount, setAmount] = useState(initialData?.amount.toString() || '');
  const [dueDate, setDueDate] = useState(initialData?.dueDate || new Date().toISOString().split('T')[0]);
  const [currentInstallment, setCurrentInstallment] = useState(initialData?.currentInstallment?.toString() || '1');
  const [totalInstallments, setTotalInstallments] = useState(initialData?.totalInstallments?.toString() || '1');
  const [recurring, setRecurring] = useState(initialData?.recurring || false);
  const [category, setCategory] = useState(initialData?.category || categories[0] || 'Geral');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('O valor deve ser maior que zero.');
      return;
    }

    onSubmit({
      name: name.trim(),
      amount: parsedAmount,
      dueDate,
      currentInstallment: parseInt(currentInstallment) || 1,
      totalInstallments: parseInt(totalInstallments) || 1,
      status: initialData?.status || 'pending',
      category,
      recurring
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-200 custom-scrollbar">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800">{initialData ? 'Editar Conta' : 'Nova Conta'}</h1>
            <p className="text-sm text-slate-500 mt-1">
              {initialData ? 'Altere os detalhes da sua conta.' : 'Cadastre uma conta para não esquecer o vencimento.'}
            </p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 animate-in slide-in-from-top-2 duration-200">
              <AlertCircle size={20} />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Nome da Conta</label>
            <input 
              type="text" 
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
              placeholder="Ex: Aluguel, Internet..."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Valor</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
                <input 
                  type="number" 
                  required
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium"
                  placeholder="0,00"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Categoria</label>
              <select 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="block w-full px-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
              >
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Vencimento</label>
              <input 
                type="date" 
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Parcela</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  value={currentInstallment}
                  onChange={(e) => setCurrentInstallment(e.target.value)}
                  className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Total</label>
                <input 
                  type="number" 
                  required
                  min="1"
                  value={totalInstallments}
                  onChange={(e) => setTotalInstallments(e.target.value)}
                  className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
            <input 
              type="checkbox" 
              id="recurring"
              checked={recurring}
              onChange={(e) => setRecurring(e.target.checked)}
              className="w-5 h-5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500"
            />
            <label htmlFor="recurring" className="text-sm font-medium text-slate-700 cursor-pointer">
              Conta recorrente (repetir mensalmente)
            </label>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-medium rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-[2] px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-[0.98] transition-all"
            >
              {initialData ? 'Salvar Alterações' : 'Cadastrar Conta'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function IncomeModal({ onClose, onSubmit, categories, initialData }: any) {
  const [amount, setAmount] = useState(initialData?.amount?.toString() || '');
  const [category, setCategory] = useState<string>(initialData?.category || 'Receita');
  const [date, setDate] = useState(initialData?.date ? initialData.date.split('T')[0] : new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState(initialData?.description || '');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('O valor deve ser maior que zero.');
      return;
    }

    if (!category.trim()) {
      setError('A categoria é obrigatória.');
      return;
    }
    
    onSubmit({
      amount: parsedAmount,
      category: category.trim(),
      date,
      description: description.trim() || category.trim(),
      type: 'income'
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-lg animate-in fade-in zoom-in duration-200 overflow-hidden">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800">Nova Receita</h1>
            <p className="text-sm text-slate-500 mt-1">Preencha os detalhes para registrar sua receita.</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 animate-in slide-in-from-top-2 duration-200">
              <AlertCircle size={20} />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Valor</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
              <input 
                type="number" 
                required
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium bg-slate-50/50"
                placeholder="0,00"
                autoFocus
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Data</label>
              <input 
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
              />
            </div>
            <div className="space-y-2">
              <label className="block text-sm font-medium text-slate-700">Categoria</label>
              <input 
                type="text" 
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                placeholder="Ex: Salário, Vendas..."
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Descrição <span className="text-slate-400 font-normal">(Opcional)</span></label>
            <textarea 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50 resize-none"
              placeholder="Ex: Salário Mensal"
              rows={3}
            ></textarea>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-medium rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-[2] px-6 py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 shadow-lg shadow-emerald-100 active:scale-[0.98] transition-all"
            >
              Salvar Receita
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function SavingsGoalModal({ onClose, currentGoal, onSubmit }: any) {
  const [amount, setAmount] = useState(currentGoal.toString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(parseFloat(amount));
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md animate-in fade-in zoom-in duration-200">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800">Meta de Economia</h1>
            <p className="text-sm text-slate-500 mt-1">Defina quanto você deseja economizar este mês.</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Valor da Meta</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
              <input 
                type="number" 
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium bg-slate-50/50"
                placeholder="0,00"
                autoFocus
              />
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-medium rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-[2] px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-[0.98] transition-all"
            >
              Salvar Meta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function CategoryGoalModal({ onClose, category, currentLimit, onSubmit }: any) {
  const [amount, setAmount] = useState(currentLimit.toString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(parseFloat(amount));
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md animate-in fade-in zoom-in duration-200">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800">Meta: {category}</h1>
            <p className="text-sm text-slate-500 mt-1">Ajuste o limite de gastos para esta categoria.</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Limite Mensal</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
              <input 
                type="number" 
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium bg-slate-50/50"
                placeholder="0,00"
                autoFocus
              />
            </div>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-medium rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-[2] px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-[0.98] transition-all"
            >
              Salvar Limite
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function RevenueGoalModal({ onClose, currentGoal, onSubmit }: any) {
  const [amount, setAmount] = useState(currentGoal.toString());

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(amount);
    if (!isNaN(parsed) && parsed >= 0) {
      onSubmit(parsed);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h2 className="text-xl font-bold text-slate-800">Editar Meta de Receita</h2>
            <p className="text-sm text-slate-500 mt-1">Defina o valor total que deseja alcançar este mês.</p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Valor da Meta</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
              <input 
                type="number" 
                required
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium"
                placeholder="0,00"
                autoFocus
              />
            </div>
          </div>

          <div className="flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-1 px-6 py-3 bg-emerald-600 text-white font-bold rounded-xl shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all"
            >
              Salvar Meta
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ConfirmationModal({ title, message, onConfirm, onCancel, type = 'danger' }: any) {
  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="p-8">
          <div className={cn(
            "w-12 h-12 rounded-2xl flex items-center justify-center mb-6",
            type === 'danger' ? "bg-rose-100 text-rose-600" : 
            type === 'warning' ? "bg-amber-100 text-amber-600" : "bg-indigo-100 text-indigo-600"
          )}>
            <AlertCircle size={24} />
          </div>
          <h2 className="text-xl font-bold text-slate-800 mb-2">{title}</h2>
          <p className="text-slate-500 leading-relaxed">{message}</p>
        </div>
        <div className="px-8 pb-8 flex gap-3">
          <button 
            onClick={onCancel}
            className="flex-1 px-6 py-3 border border-slate-200 text-slate-600 font-semibold rounded-xl hover:bg-slate-50 transition-colors"
          >
            Cancelar
          </button>
          <button 
            onClick={onConfirm}
            className={cn(
              "flex-1 px-6 py-3 text-white font-bold rounded-xl shadow-lg transition-all active:scale-[0.98]",
              type === 'danger' ? "bg-rose-600 hover:bg-rose-700 shadow-rose-200" : 
              type === 'warning' ? "bg-amber-600 hover:bg-amber-700 shadow-amber-200" : "bg-indigo-600 hover:bg-indigo-700 shadow-indigo-200"
            )}
          >
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
}

function TransactionModal({ onClose, onSubmit, categories, onAddCategory, initialType = 'expense', mode = 'full', initialData }: any) {
  const [amount, setAmount] = useState(initialData?.amount?.toString() || '');
  const [type, setType] = useState<'income' | 'expense'>(
    initialData?.type || (
      mode === 'income-only' ? 'income' : 
      mode === 'expense-only' ? 'expense' : 
      initialType
    )
  );
  const [category, setCategory] = useState<string>(() => {
    if (initialData?.category) return initialData.category;
    return categories[0] || 'Geral';
  });
  const [date, setDate] = useState(initialData?.date ? initialData.date.split('T')[0] : new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState(initialData?.description || '');
  const [error, setError] = useState<string | null>(null);

  // Update category when type changes if it's still the default
  useEffect(() => {
    // Logic removed to respect user-defined categories exactly
  }, [type, categories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('O valor deve ser maior que zero.');
      return;
    }
    
    onSubmit({
      amount: parsedAmount,
      category: category.trim(),
      date,
      description: description.trim() || category.trim(),
      type
    });
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 w-full max-w-lg max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-200 custom-scrollbar">
        <header className="px-8 pt-8 pb-4 flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-slate-800">
              {initialData ? 'Editar Transação' : (mode === 'income-only' ? 'Nova Receita' : mode === 'expense-only' ? '+ Nova Despesa' : 'Nova Transação')}
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              {initialData 
                ? 'Atualize os detalhes da sua transação.'
                : (mode === 'income-only' 
                  ? 'Preencha os detalhes para registrar sua receita.' 
                  : mode === 'expense-only'
                    ? 'Preencha os detalhes para registrar sua despesa.'
                    : 'Preencha os detalhes para registrar sua despesa ou receita.')}
            </p>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 transition-colors">
            <X size={24} />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="px-8 pb-8 space-y-6">
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 animate-in slide-in-from-top-2 duration-200">
              <AlertCircle size={20} />
              <p className="text-sm font-bold">{error}</p>
            </div>
          )}
          {mode === 'full' && (
            <div className="flex p-1 bg-slate-100 rounded-xl">
              <button 
                type="button"
                onClick={() => setType('expense')}
                className={cn(
                  "flex-1 py-2 text-sm font-semibold rounded-lg transition-all",
                  type === 'expense' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Despesa
              </button>
              <button 
                type="button"
                onClick={() => setType('income')}
                className={cn(
                  "flex-1 py-2 text-sm font-semibold rounded-lg transition-all",
                  type === 'income' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Receita
              </button>
            </div>
          )}

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Valor</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 text-lg">R$</span>
              <input 
                type="number" 
                required
                step="0.01"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="block w-full pl-12 pr-4 py-4 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xl font-medium"
                placeholder="0,00"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Categoria</label>
                {type === 'income' ? (
                  <input 
                    type="text" 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                    placeholder="Ex: Salário, Vendas..."
                    required
                  />
                ) : (
                  <select 
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                  >
                    {categories.map((c: string) => <option key={c} value={c}>{c}</option>)}
                  </select>
                )}
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-medium text-slate-700">Data</label>
                <input 
                  type="date" 
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-700">Descrição <span className="text-slate-400 font-normal">(Opcional)</span></label>
            <textarea 
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="block w-full px-4 py-3 border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-slate-50/50 resize-none"
              placeholder={mode === 'income-only' ? "Ex: Salário Mensal" : "Adicione uma nota"}
              rows={3}
            ></textarea>
          </div>

          <div className="pt-4 flex gap-3">
            <button 
              type="button" 
              onClick={onClose}
              className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-medium rounded-2xl hover:bg-slate-50 transition-colors"
            >
              Cancelar
            </button>
            <button 
              type="submit"
              className="flex-[2] px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 shadow-lg shadow-indigo-200 active:scale-[0.98] transition-all"
            >
              {initialData ? 'Atualizar' : 'Salvar'} {mode === 'income-only' ? 'Receita' : mode === 'expense-only' ? 'Despesa' : 'Transação'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
