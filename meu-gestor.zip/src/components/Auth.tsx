import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { 
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  browserLocalPersistence,
  browserSessionPersistence,
  setPersistence
} from 'firebase/auth';
import { doc, setDoc, getDoc, serverTimestamp, updateDoc, collection, query, where, getDocs, deleteDoc, addDoc, increment } from 'firebase/firestore';
import { LogIn, UserPlus, LogOut, Shield, AlertCircle, ShieldAlert, CheckCircle2, Mail, Lock, User, Key, ArrowLeft, Eye, EyeOff, Smartphone, Globe, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string;
    email?: string | null;
    emailVerified?: boolean;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return new Error(errInfo.error);
}

export function AuthScreen({ onAuthSuccess }: { onAuthSuccess: (user: FirebaseUser) => void }) {
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // Form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Stats
  const [isRequesting, setIsRequesting] = useState(false);
  const [requestEmail, setRequestEmail] = useState('');
  const [requestName, setRequestName] = useState('');
  const [requestSent, setRequestSent] = useState(false);

  const logSecurityEvent = async (userId: string | null, email: string, event: string, success: boolean) => {
    try {
      await addDoc(collection(db, 'security_logs'), {
        userId,
        email,
        event,
        success,
        timestamp: serverTimestamp(),
        userAgent: navigator.userAgent
      });
    } catch (e) {
      console.error('Failed to log security event', e);
    }
  };

  const validatePassword = (pwd: string) => {
    if (pwd.length < 8) return "A senha deve ter pelo menos 8 caracteres.";
    if (!/[A-Z]/.test(pwd)) return "A senha deve conter pelo menos uma letra maiúscula.";
    if (!/[0-9]/.test(pwd)) return "A senha deve conter pelo menos um número.";
    return null;
  };

  const checkLoginAttempts = async (email: string) => {
    const attemptRef = doc(db, 'security_attempts', email.toLowerCase());
    const attemptDoc = await getDoc(attemptRef);
    if (attemptDoc.exists()) {
      const data = attemptDoc.data();
      if (data.count >= 5) {
        // Check if last attempt was less than 30 minutes ago
        const lastAttempt = data.lastAttempt?.toDate() || new Date(0);
        const diff = (new Date().getTime() - lastAttempt.getTime()) / (1000 * 60);
        if (diff < 30) {
          throw new Error("Muitas tentativas falhas. Conta temporariamente bloqueada (30 min).");
        } else {
          // Reset count after 30 mins
          await setDoc(attemptRef, { count: 0, lastAttempt: serverTimestamp() });
        }
      }
    }
    return true;
  };

  const recordFailedAttempt = async (email: string) => {
    const attemptRef = doc(db, 'security_attempts', email.toLowerCase());
    await setDoc(attemptRef, { 
      count: increment(1), 
      lastAttempt: serverTimestamp() 
    }, { merge: true });
  };

  const translateAuthError = (code: string) => {
    switch (code) {
      case 'auth/invalid-email': return 'E-mail inválido.';
      case 'auth/user-disabled': return 'Esta conta foi desativada.';
      case 'auth/user-not-found': return 'Usuário não encontrado.';
      case 'auth/wrong-password': return 'Senha incorreta.';
      case 'auth/email-already-in-use': return 'Este e-mail já está em uso (provavelmente via Google).';
      case 'auth/operation-not-allowed': return 'O login por senha não está ativado no Firebase. Vá em Auth > Sign-in method e ative "E-mail/Senha".';
      case 'auth/weak-password': return 'A senha deve ser mais forte.';
      case 'auth/too-many-requests': return 'Muitas tentativas. Tente novamente em alguns minutos.';
      case 'auth/popup-closed-by-user': return 'Janela de login fechada pelo usuário.';
      default: return null;
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await checkLoginAttempts(email);
      
      // Persistence
      await setPersistence(auth, rememberMe ? browserLocalPersistence : browserSessionPersistence);
      
      const result = await signInWithEmailAndPassword(auth, email, password);
      const user = result.user;

      // Check user status
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        const profile = userDoc.data();
        if (profile.status === 'blocked' && user.email?.toLowerCase() !== 'tiagonobre13@gmail.com') {
          await signOut(auth);
          throw new Error('Sua conta foi bloqueada pelo administrador.');
        }
        await updateDoc(doc(db, 'users', user.uid), { 
          lastLogin: serverTimestamp(),
          // Ensure admin is always active
          status: user.email?.toLowerCase() === 'tiagonobre13@gmail.com' ? 'active' : profile.status
        });
      }

      // Reset attempts
      await deleteDoc(doc(db, 'security_attempts', email.toLowerCase()));
      
      await logSecurityEvent(user.uid, email, 'Email Login', true);
      onAuthSuccess(user);
    } catch (err: any) {
      if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found') {
        await recordFailedAttempt(email);
        setError("E-mail ou senha incorretos.");
      } else {
        setError(translateAuthError(err.code) || err.message);
      }
      await logSecurityEvent(null, email, `Login Failed: ${err.message}`, false);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setEmailInUse(false);
    
    const pwdError = validatePassword(password);
    if (pwdError) {
      setError(pwdError);
      return;
    }

    setLoading(true);
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      const user = result.user;

      const emailLower = email.toLowerCase();
      const isAdmin = emailLower === "tiagonobre13@gmail.com";
      
      await setDoc(doc(db, 'users', user.uid), {
        email: emailLower,
        name: name,
        role: isAdmin ? 'admin' : 'user',
        savingsGoal: 8000,
        createdAt: serverTimestamp(),
        uid: user.uid,
        status: isAdmin ? 'active' : 'pending'
      });

      await logSecurityEvent(user.uid, email, 'Registration', true);
      onAuthSuccess(user);
    } catch (err: any) {
      if (err.code === 'auth/email-already-in-use') {
        setEmailInUse(true);
        setError("E-mail já vinculado. Se você usa o Google, crie uma senha para entrar diretamente.");
      } else if (err.code === 'auth/operation-not-allowed') {
        setError("AVISO: O método de login por e-mail/senha não está habilitado no Console do Firebase. Você precisa ativá-lo em Autenticação > Sign-in Method.");
      } else {
        setError(translateAuthError(err.code) || err.message);
      }
      await logSecurityEvent(null, email, `Reg Failed: ${err.message}`, false);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, email);
      setSuccessMessage("E-mail enviado! Verifique seu SPAM ou lixo eletrônico. Redefina a senha no link para ativar seu login direto.");
      setTimeout(() => setAuthMode('login'), 5000);
    } catch (err: any) {
      setError(translateAuthError(err.code) || err.message);
    } finally {
      setLoading(false);
    }
  };

  const [successMessage, setSuccessMessage] = useState('');
  const [emailInUse, setEmailInUse] = useState(false);

  // Handle Redirect Result
  useEffect(() => {
    const handleRedirect = async () => {
      try {
        const result = await getRedirectResult(auth);
        if (result) {
          setLoading(true);
          await processUser(result.user);
        }
      } catch (err: any) {
        // Silently handle common redirect errors or issues in iframe
        if (err.code !== 'auth/operation-not-supported-in-this-environment') {
          handleAuthError(err, 'Redirect Logic');
        }
      } finally {
        setLoading(false);
      }
    };
    handleRedirect();
  }, []);

  const handleAuthError = (err: any, context: string) => {
    if (err.code === 'auth/popup-closed-by-user' || err.code === 'auth/cancelled-by-user') {
      setError('Login cancelado ou janela fechada. Por favor, tente novamente e mantenha a janela aberta.');
      console.warn(`Usuário cancelou a autenticação (${context}).`);
    } else if (err.code === 'auth/popup-blocked') {
      setError('O navegador bloqueou a janela de login. Por favor, autorize popups para este site.');
    } else {
      setError(`Erro no login: ${err.message}`);
      console.error(`Erro de autenticação (${context}):`, err);
    }
  };

  const processUser = async (user: FirebaseUser) => {
    // Check if user profile exists
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    
    if (!userDoc.exists()) {
      const userEmail = user.email?.toLowerCase();
      const isAdmin = userEmail === "tiagonobre13@gmail.com";
      
      if (isAdmin) {
        // Main admin
        await setDoc(doc(db, 'users', user.uid), {
          email: user.email,
          name: user.displayName || '',
          role: 'admin',
          savingsGoal: 8000,
          createdAt: serverTimestamp(),
          uid: user.uid,
          status: 'active'
        });
      } else {
        // Check if there's an existing invite or request for this email
        const usersRef = collection(db, 'users');
        const q = query(usersRef, where('email', '==', userEmail));
        const snapshot = await getDocs(q);
        
        if (!snapshot.empty) {
          // User was invited or already has a profile
          const existingDoc = snapshot.docs[0];
          await updateDoc(doc(db, 'users', existingDoc.id), {
            uid: user.uid,
            name: user.displayName || existingDoc.data().name || '',
            lastLogin: serverTimestamp(),
            status: existingDoc.data().status === 'invited' ? 'active' : existingDoc.data().status
          });
        } else {
          // New user, create pending profile
          await setDoc(doc(db, 'users', user.uid), {
            email: user.email,
            name: user.displayName || '',
            role: 'user',
            savingsGoal: 8000,
            createdAt: serverTimestamp(),
            uid: user.uid,
            status: 'pending'
          });
        }
      }
    } else {
      // Profile exists, check status
      const profile = userDoc.data();
      if (profile.status === 'blocked' && user.email?.toLowerCase() !== 'tiagonobre13@gmail.com') {
        await signOut(auth);
        throw new Error('Sua conta foi bloqueada pelo administrador.');
      }
      // Update last login
      await updateDoc(doc(db, 'users', user.uid), { lastLogin: serverTimestamp() });
    }
    
    onAuthSuccess(user);
  };

  const handleGoogleSignIn = async () => {
    setError('');
    setLoading(true);
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account'
    });

    try {
      // Usar Popup em vez de Redirect para este ambiente
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        await processUser(result.user);
      }
    } catch (err: any) {
      handleAuthError(err, 'Google Sign In');
    } finally {
      setLoading(false);
    }
  };

  const handleRequestAccess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestEmail || !requestName) return;
    
    setLoading(true);
    try {
      await addDoc(collection(db, 'access_requests'), {
        email: requestEmail.toLowerCase(),
        name: requestName,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      setRequestSent(true);
      setIsRequesting(false);
    } catch (err: any) {
      setError('Erro ao enviar pedido de acesso.');
    } finally {
      setLoading(false);
    }
  };

  if (requestSent) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-4 selection:bg-indigo-500/30">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white/5 backdrop-blur-xl rounded-[2.5rem] border border-white/10 w-full max-w-md p-10 text-center shadow-2xl"
        >
          <div className="w-20 h-20 bg-emerald-500/10 text-emerald-400 rounded-3xl flex items-center justify-center mx-auto mb-8 border border-emerald-500/20">
            <CheckCircle2 size={40} strokeWidth={1.5} />
          </div>
          <h2 className="text-3xl font-bold text-white mb-3">Pedido Enviado!</h2>
          <p className="text-slate-400 mb-10 leading-relaxed">
            Seu pedido de acesso foi enviado ao administrador. Você receberá um aviso assim que for aprovado.
          </p>
          <button 
            onClick={() => setRequestSent(false)}
            className="w-full py-4.5 bg-white/5 text-white font-bold rounded-2xl hover:bg-white/10 transition-all border border-white/10 active:scale-[0.98]"
          >
            Voltar
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-4 relative overflow-hidden font-sans selection:bg-indigo-500/30">
      {/* Decorative Orbs */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />
      
      <motion.div 
        layout
        className="bg-white/5 backdrop-blur-2xl rounded-[2.5rem] border border-white/10 w-full max-w-lg overflow-hidden shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] z-10"
      >
        <div className="p-8 md:p-12">
          <div className="text-center mb-10">
            <motion.div 
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", damping: 15 }}
              className="w-16 h-16 bg-gradient-to-tr from-indigo-600 to-blue-500 rounded-2xl flex items-center justify-center text-white font-black text-3xl mx-auto mb-6 shadow-xl shadow-indigo-500/20 relative group"
            >
              <span className="relative z-10">$</span>
              <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
            </motion.div>
            <h1 className="text-2xl font-black text-white tracking-tight uppercase">Meu Gestor</h1>
            <p className="text-slate-400 text-sm mt-2 font-medium">Finanças que trabalham para você</p>
          </div>

          <AnimatePresence mode="wait">
            {isRequesting ? (
              <motion.div
                key="request"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center gap-3 mb-6">
                  <Globe className="text-indigo-400" size={20} />
                  <h2 className="text-xl font-bold text-white">Solicitar Acesso</h2>
                </div>
                <form onSubmit={handleRequestAccess} className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">Nome Completo</label>
                    <div className="relative group">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="text" 
                        required
                        value={requestName}
                        onChange={(e) => setRequestName(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="Ex: João Silva"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">E-mail</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="email" 
                        required
                        value={requestEmail}
                        onChange={(e) => setRequestEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>
                  <div className="pt-2 flex gap-4">
                    <button 
                      type="button"
                      onClick={() => setIsRequesting(false)}
                      className="flex-1 py-4 bg-white/5 text-slate-300 font-bold rounded-2xl hover:bg-white/10 transition-all active:scale-[0.98] border border-white/5"
                    >
                      Cancelar
                    </button>
                    <button 
                      type="submit"
                      disabled={loading}
                      className="flex-[2] py-4 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all disabled:opacity-50 active:scale-[0.98] shadow-lg shadow-indigo-500/20"
                    >
                      {loading ? 'Enviando...' : 'Enviar Pedido'}
                    </button>
                  </div>
                </form>
              </motion.div>
            ) : authMode === 'login' ? (
              <motion.div
                key="login"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <form onSubmit={handleEmailLogin} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">E-mail</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-sm font-semibold text-slate-300">Senha</label>
                      <button 
                        type="button" 
                        onClick={() => setAuthMode('forgot')}
                        className="text-xs text-indigo-400 font-bold hover:text-indigo-300 transition-colors"
                      >
                        Esqueceu?
                      </button>
                    </div>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type={showPassword ? "text" : "password"} 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-12 pr-14 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="••••••••"
                      />
                      <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 px-1">
                    <div className="relative flex items-center h-5">
                      <input 
                        type="checkbox" 
                        id="remember" 
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="w-5 h-5 rounded-lg border-white/10 bg-white/5 text-indigo-600 focus:ring-indigo-500/50 cursor-pointer"
                      />
                    </div>
                    <label htmlFor="remember" className="text-xs text-slate-400 font-medium cursor-pointer select-none">
                      Lembrar acesso neste dispositivo
                    </label>
                  </div>

                  {error && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm rounded-2xl flex items-start gap-3"
                    >
                      <AlertCircle size={20} className="shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </motion.div>
                  )}

                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full py-4.5 bg-gradient-to-r from-indigo-600 to-blue-600 text-white font-bold rounded-2xl hover:from-indigo-500 hover:to-blue-500 transition-all active:scale-[0.98] shadow-lg shadow-indigo-500/20 disabled:opacity-50"
                  >
                    {loading ? 'Entrando...' : 'Acessar Conta'}
                  </button>
                </form>

                <div className="relative py-2">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/5"></div>
                  </div>
                  <div className="relative flex justify-center text-xs uppercase tracking-widest font-bold">
                    <span className="bg-[#0f172a] px-4 text-slate-500">ou entre com</span>
                  </div>
                </div>

                <button 
                  onClick={handleGoogleSignIn}
                  disabled={loading}
                  className="w-full py-4.5 bg-white/5 border border-white/10 text-white font-bold rounded-2xl hover:bg-white/10 active:scale-[0.98] transition-all flex items-center justify-center gap-3 shadow-sm group"
                >
                  <svg className="group-hover:scale-110 transition-transform" width="22" height="22" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  </svg>
                  Google Account
                </button>

                <div className="text-center space-y-4 pt-4">
                  <p className="text-sm text-slate-400">
                    Ainda não possui uma conta? {' '}
                    <button 
                      onClick={() => setAuthMode('register')}
                      className="text-indigo-400 font-bold hover:text-indigo-300 underline underline-offset-4 decoration-indigo-500/30"
                    >
                      Cadastre-se grátis
                    </button>
                  </p>
                  <button 
                    onClick={() => setIsRequesting(true)}
                    className="text-xs text-slate-500 font-semibold hover:text-white transition-colors flex items-center justify-center gap-2 mx-auto"
                  >
                    <ShieldAlert size={14} /> Solicitar autorização de acesso
                  </button>
                </div>
              </motion.div>
            ) : authMode === 'register' ? (
              <motion.div
                key="register"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between mb-2">
                  <button 
                    onClick={() => setAuthMode('login')}
                    className="flex items-center gap-2 text-slate-400 hover:text-white transition-all text-sm font-semibold"
                  >
                    <ArrowLeft size={16} /> Voltar ao Login
                  </button>
                  <div className="px-3 py-1 bg-indigo-500/10 text-indigo-400 rounded-full text-[10px] uppercase font-black tracking-widest border border-indigo-500/20">
                    Novo Usuário
                  </div>
                </div>
                
                <form onSubmit={handleEmailRegister} className="space-y-5">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">Nome Completo</label>
                    <div className="relative group">
                      <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="text" 
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="Nome e Sobrenome"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">E-mail Corporativo ou Pessoal</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">Defina sua Senha</label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type={showPassword ? "text" : "password"} 
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-12 pr-14 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="••••••••"
                      />
                      <button 
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 px-1">
                      <div className={cn(
                        "flex items-center gap-1.5 text-[10px] font-bold py-1 px-2 rounded-lg border transition-all",
                        password.length >= 8 ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/5 border-white/5 text-slate-500"
                      )}>
                        <div className={cn("w-1.5 h-1.5 rounded-full", password.length >= 8 ? "bg-emerald-400" : "bg-slate-700")} />
                        8+ Caracteres
                      </div>
                      <div className={cn(
                        "flex items-center gap-1.5 text-[10px] font-bold py-1 px-2 rounded-lg border transition-all",
                        /[A-Z]/.test(password) ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/5 border-white/5 text-slate-500"
                      )}>
                        <div className={cn("w-1.5 h-1.5 rounded-full", /[A-Z]/.test(password) ? "bg-emerald-400" : "bg-slate-700")} />
                        Maiúscula
                      </div>
                      <div className={cn(
                        "flex items-center gap-1.5 text-[10px] font-bold py-1 px-2 rounded-lg border transition-all",
                        /[0-9]/.test(password) ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-white/5 border-white/5 text-slate-500"
                      )}>
                        <div className={cn("w-1.5 h-1.5 rounded-full", /[0-9]/.test(password) ? "bg-emerald-400" : "bg-slate-700")} />
                        Número
                      </div>
                    </div>
                  </div>

                  {error && (
                    <motion.div 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="p-5 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm rounded-2xl flex flex-col gap-4"
                    >
                      <div className="flex items-start gap-3">
                        <AlertCircle size={20} className="shrink-0 mt-0.5" />
                        <span className="font-medium leading-tight">{error}</span>
                      </div>
      {emailInUse && (
        <div className="flex gap-3">
          <button 
            type="button"
            onClick={() => { setAuthMode('login'); setError(''); setEmailInUse(false); }}
            className="flex-1 py-2.5 bg-white/5 border border-white/10 text-white font-bold rounded-xl hover:bg-white/10 transition-all text-xs flex items-center justify-center gap-2"
          >
            <LogIn size={14} /> Entrar
          </button>
          <button 
            type="button"
            onClick={() => { setAuthMode('forgot'); setError(''); setEmailInUse(false); }}
            className="flex-1 py-2.5 bg-indigo-600 border border-white/10 text-white font-bold rounded-xl hover:bg-indigo-700 transition-all text-xs flex items-center justify-center gap-2"
          >
            <Key size={14} /> Ativar Senha
          </button>
        </div>
      )}
                    </motion.div>
                  )}

                  <button 
                    type="submit"
                    disabled={loading}
                    className="w-full py-4.5 bg-white text-[#0f172a] font-black rounded-2xl hover:bg-slate-100 transition-all active:scale-[0.98] shadow-xl shadow-white/10 disabled:opacity-50 mt-4"
                  >
                    {loading ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-5 h-5 border-3 border-indigo-600/30 border-t-indigo-600 rounded-full animate-spin" />
                        <span>Processando...</span>
                      </div>
                    ) : 'Finalizar Cadastro'}
                  </button>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="forgot"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="space-y-8"
              >
                <div className="text-center">
                  <div className="w-20 h-20 bg-indigo-500/10 text-indigo-400 rounded-[2rem] flex items-center justify-center mx-auto mb-6 border border-indigo-500/20">
                    <Key size={40} strokeWidth={1.5} />
                  </div>
                  <h2 className="text-2xl font-bold text-white tracking-tight">Recuperar Acesso</h2>
                  <p className="text-slate-400 text-sm mt-3 leading-relaxed max-w-[280px] mx-auto font-medium">
                    Enviaremos um link para redefinir sua senha ou criar uma para sua conta Google.
                  </p>
                </div>

                <form onSubmit={handleForgotPassword} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-300 ml-1">E-mail cadastrado</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-indigo-400 transition-colors" size={20} />
                      <input 
                        type="email" 
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-12 pr-4 py-4 bg-white/5 border border-white/10 rounded-2xl focus:ring-2 focus:ring-indigo-500/50 outline-none text-white placeholder-slate-600 transition-all"
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  {error && (
                    <div className="p-4 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm rounded-2xl flex items-start gap-3">
                      <AlertCircle size={20} className="shrink-0 mt-0.5" />
                      <span>{error}</span>
                    </div>
                  )}

                  {successMessage && (
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm rounded-2xl flex items-start gap-3">
                      <CheckCircle2 size={20} className="shrink-0 mt-0.5" />
                      <span>{successMessage}</span>
                    </div>
                  )}

                  <div className="flex flex-col gap-3">
                    <button 
                      type="submit"
                      disabled={loading}
                      className="w-full py-4.5 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all disabled:opacity-50 active:scale-[0.98] shadow-lg shadow-indigo-500/20"
                    >
                      {loading ? 'Enviando...' : 'Enviar Link de Recuperação'}
                    </button>
                    <button 
                      type="button"
                      onClick={() => { setAuthMode('login'); setError(''); setSuccessMessage(''); }}
                      className="w-full py-4 bg-white/5 text-slate-400 font-bold rounded-2xl hover:bg-white/10 transition-all border border-white/5 active:scale-[0.98]"
                    >
                      Voltar ao Login
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-8 border-t border-white/5 bg-white/[0.02] flex flex-col items-center gap-4">
          <div className="flex items-center gap-6 opacity-40 hover:opacity-80 transition-opacity">
            <Smartphone size={16} className="text-slate-400" />
            <Shield size={16} className="text-slate-400" />
            <Sparkles size={16} className="text-slate-400" />
          </div>
          <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] text-center">
            &copy; 2026 Meu Gestor • Encriptação de Ponta a Ponta
          </p>
        </div>
      </motion.div>
    </div>
  );
}
