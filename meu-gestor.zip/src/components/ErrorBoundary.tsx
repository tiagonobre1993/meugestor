import React, { Component, ReactNode } from 'react';
import { Shield } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends (Component as any) {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let displayError = this.state.error?.message || 'Erro desconhecido';
      let errorDetails = null;

      try {
        const parsed = JSON.parse(displayError);
        if (parsed.error) {
          displayError = parsed.error;
          errorDetails = parsed;
        }
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
          <div className="bg-white p-8 rounded-3xl shadow-xl max-w-md w-full text-center">
            <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Shield size={32} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Ops! Algo deu errado.</h2>
            <p className="text-slate-500 mb-6">Ocorreu um erro inesperado no aplicativo.</p>
            <div className="bg-slate-50 p-4 rounded-xl text-left mb-6 overflow-auto max-h-40">
              <code className="text-xs text-rose-600 block mb-1 font-bold">
                {displayError.includes('Missing or insufficient permissions') ? 'Acesso Negado: Você não tem permissão para esta ação.' : displayError}
              </code>
              {errorDetails && (
                <div className="mt-2 pt-2 border-t border-rose-100 text-[10px] text-slate-400 font-mono">
                  Path: {errorDetails.path}<br/>
                  Op: {errorDetails.operationType}
                </div>
              )}
            </div>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
            >
              Recarregar Aplicativo
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
