import React, { useState, useEffect, useMemo } from 'react';
import { db, auth } from '../firebase';
import { 
  collection, 
  onSnapshot, 
  deleteDoc, 
  doc, 
  query, 
  orderBy, 
  updateDoc, 
  addDoc, 
  serverTimestamp, 
  where, 
  getDocs,
  limit
} from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';
import { 
  Trash2, 
  Users,
  Search, 
  X, 
  ShieldAlert, 
  Edit2, 
  Check, 
  AlertCircle, 
  UserPlus, 
  Copy, 
  CheckCircle2, 
  Clock, 
  CheckCircle, 
  Ban,
  Filter,
  ArrowUpDown,
  MoreHorizontal,
  Mail,
  RefreshCw,
  UserCheck,
  UserX,
  ChevronRight,
  History,
  Terminal,
  Activity,
  UserCircle,
  Key
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { motion, AnimatePresence } from 'motion/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  return errInfo.error;
}

export function AdminPanel({ onClose }: { onClose: () => void }) {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [isInviting, setIsInviting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'active' | 'blocked'>('all');
  const [sortBy, setSortBy] = useState<'recent' | 'email'>('recent');
  
  const [confirmConfig, setConfirmConfig] = useState<{
    isOpen: boolean;
    userId: string;
    email: string;
  }>({
    isOpen: false,
    userId: '',
    email: ''
  });

  const [requests, setRequests] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'users' | 'requests' | 'logs'>('users');
  const [editingUser, setEditingUser] = useState<any>(null);

  useEffect(() => {
    setLoading(true);
    // Real-time Users
    const qUsers = query(collection(db, 'users'));
    const unsubUsers = onSnapshot(qUsers, (snapshot) => {
      const usersList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setUsers(usersList);
      setLoading(false);
    }, (err) => {
      setError("Erro ao carregar lista de usuários.");
      setLoading(false);
    });

    // Real-time Requests
    const qReqs = query(collection(db, 'access_requests'), orderBy('createdAt', 'desc'));
    const unsubReqs = onSnapshot(qReqs, (snapshot) => {
      setRequests(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Real-time Logs
    const qLogs = query(collection(db, 'security_logs'), orderBy('timestamp', 'desc'), limit(50));
    const unsubLogs = onSnapshot(qLogs, (snapshot) => {
      setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => {
      unsubUsers();
      unsubReqs();
      unsubLogs();
    };
  }, []);

  // Auto-hide success/error messages
  useEffect(() => {
    if (success || error) {
      const timer = setTimeout(() => {
        setSuccess(null);
        setError(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [success, error]);

  const handleApproveRequest = async (request: any) => {
    try {
      const usersRef = collection(db, 'users');
      const q = query(usersRef, where('email', '==', request.email));
      const snapshot = await getDocs(q);
      
      if (!snapshot.empty) {
        const userDoc = snapshot.docs[0];
        await updateDoc(doc(db, 'users', userDoc.id), {
          status: 'active',
          name: request.name || userDoc.data().name
        });
      } else {
        await addDoc(collection(db, 'users'), {
          email: request.email,
          name: request.name,
          role: 'user',
          status: 'active',
          createdAt: serverTimestamp(),
          savingsGoal: 8000
        });
      }
      await deleteDoc(doc(db, 'access_requests', request.id));
      setSuccess(`Pedido de ${request.email} aprovado com sucesso!`);
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.WRITE, 'users'));
    }
  };

  const handleRejectRequest = async (requestId: string) => {
    try {
      await deleteDoc(doc(db, 'access_requests', requestId));
      setSuccess("Pedido recusado.");
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.DELETE, `access_requests/${requestId}`));
    }
  };

  const handleToggleUserStatus = async (user: any) => {
    const newStatus = user.status === 'blocked' ? 'active' : 'blocked';
    try {
      const updateData: any = { status: newStatus };
      if (newStatus === 'blocked') {
        updateData.blockedAt = serverTimestamp();
        updateData.blockedBy = auth.currentUser?.email;
      } else {
        updateData.unblockedAt = serverTimestamp();
        updateData.unblockedBy = auth.currentUser?.email;
      }
      await updateDoc(doc(db, 'users', user.id), updateData);
      setSuccess(`Status de ${user.email} atualizado para ${newStatus === 'active' ? 'Ativo' : 'Bloqueado'}.`);
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.UPDATE, `users/${user.id}`));
    }
  };

  const handleDeleteUser = async (userId: string, email: string) => {
    setConfirmConfig({ isOpen: true, userId, email });
  };

  const confirmDeleteUser = async () => {
    const { userId } = confirmConfig;
    try {
      await deleteDoc(doc(db, 'users', userId));
      setConfirmConfig({ isOpen: false, userId: '', email: '' });
      setSuccess("Usuário removido com sucesso.");
    } catch (err) {
      setConfirmConfig({ isOpen: false, userId: '', email: '' });
      setError(handleFirestoreError(err, OperationType.DELETE, `users/${userId}`));
    }
  };

  const handleUpdateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    try {
      await updateDoc(doc(db, 'users', editingUser.id), {
        name: editingUser.name,
        role: editingUser.role
      });
      setEditingUser(null);
      setSuccess("Dados do usuário atualizados.");
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.UPDATE, `users/${editingUser.id}`));
    }
  };

  const handleInviteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    const email = inviteEmail.trim().toLowerCase();
    if (!email) return;
    
    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("Por favor, insira um e-mail válido.");
      return;
    }

    setIsInviting(true);
    try {
      const exists = users.some(u => u.email?.toLowerCase() === email);
      if (exists) {
        setError("Este usuário já está na lista.");
        return;
      }

      await addDoc(collection(db, 'users'), {
        email,
        role: 'user',
        createdAt: serverTimestamp(),
        savingsGoal: 8000,
        status: 'invited'
      });
      
      setInviteEmail('');
      setSuccess(`Convite enviado para ${email}!`);
      
      // Log event
      await addDoc(collection(db, 'security_logs'), {
        event: 'User Invited',
        email,
        admin: auth.currentUser?.email,
        timestamp: serverTimestamp(),
        success: true
      });
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.CREATE, 'users'));
    } finally {
      setIsInviting(false);
    }
  };

  const handleResetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email);
      setSuccess(`Link de redefinição de senha enviado para ${email}.`);
      
      await addDoc(collection(db, 'security_logs'), {
        event: 'Password Reset Triggered',
        email,
        admin: auth.currentUser?.email,
        timestamp: serverTimestamp(),
        success: true
      });
    } catch (err: any) {
      setError("Erro ao enviar link de redefinição: " + err.message);
    }
  };

  const handleResendInvite = async (user: any) => {
    try {
      await updateDoc(doc(db, 'users', user.id), {
        createdAt: serverTimestamp()
      });
      setSuccess(`Convite para ${user.email} reenviado!`);
    } catch (err) {
      setError(handleFirestoreError(err, OperationType.UPDATE, `users/${user.id}`));
    }
  };

  const copyInviteLink = () => {
    let url = window.location.origin;
    if (url.includes('-dev-')) url = url.replace('-dev-', '-pre-');
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const processedUsers = useMemo(() => {
    let result = [...users];
    
    // Search
    if (searchTerm) {
      result = result.filter(u => 
        (u.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (u.name || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter
    if (filterStatus !== 'all') {
      if (filterStatus === 'pending') {
        result = result.filter(u => u.status === 'invited' || u.status === 'pending');
      } else {
        result = result.filter(u => u.status === filterStatus);
      }
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === 'recent') {
        const dateA = a.createdAt?.toDate?.() || new Date(0);
        const dateB = b.createdAt?.toDate?.() || new Date(0);
        return dateB.getTime() - dateA.getTime();
      }
      return (a.email || '').localeCompare(b.email || '');
    });

    return result;
  }, [users, searchTerm, filterStatus, sortBy]);

  const activeCount = users.filter(u => u.status === 'active').length;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[110] flex items-center justify-center p-0 sm:p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full h-full sm:h-[90vh] sm:max-h-[850px] sm:max-w-5xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden"
      >
        {/* Header */}
        <header className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-white sticky top-0 z-20">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200">
              <ShieldAlert size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                Gestão de Usuários
                <span className="bg-indigo-100 text-indigo-600 text-[10px] px-2 py-0.5 rounded-full font-bold">
                  {activeCount} Ativos
                </span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">Controle de acessos e convites</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-600 transition-all"
          >
            <X size={24} />
          </button>
        </header>

        {/* Success/Error Toasts */}
        <AnimatePresence>
          {(success || error) && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={cn(
                "absolute top-20 left-1/2 -translate-x-1/2 z-50 px-6 py-3 rounded-2xl shadow-xl flex items-center gap-3 border",
                success ? "bg-emerald-50 border-emerald-100 text-emerald-700" : "bg-rose-50 border-rose-100 text-rose-700"
              )}
            >
              {success ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
              <span className="text-sm font-bold">{success || error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          <div className="p-6 space-y-8">
            {/* Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-2xl w-fit overflow-x-auto no-scrollbar">
              <button 
                onClick={() => setActiveTab('users')}
                className={cn(
                  "px-6 py-2.5 text-sm font-bold rounded-xl transition-all whitespace-nowrap",
                  activeTab === 'users' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Usuários & Convites
              </button>
              <button 
                onClick={() => setActiveTab('requests')}
                className={cn(
                  "px-6 py-2.5 text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap",
                  activeTab === 'requests' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Solicitações
                {requests.length > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.5 rounded-full">
                    {requests.length}
                  </span>
                )}
              </button>
              <button 
                onClick={() => setActiveTab('logs')}
                className={cn(
                  "px-6 py-2.5 text-sm font-bold rounded-xl transition-all flex items-center gap-2 whitespace-nowrap",
                  activeTab === 'logs' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                Logs de Segurança
              </button>
            </div>

            {activeTab === 'users' ? (
              <div className="space-y-6">
                {/* Invite Section */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 bg-slate-50 p-6 rounded-3xl border border-slate-100">
                    <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center gap-2">
                      <Mail size={18} className="text-indigo-600" />
                      Convidar Novo Usuário
                    </h3>
                    <form onSubmit={handleInviteUser} className="flex flex-col sm:flex-row gap-3">
                      <div className="flex-1 relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                        <input 
                          type="email" 
                          placeholder="Digite o e-mail do convidado..." 
                          value={inviteEmail}
                          onChange={(e) => setInviteEmail(e.target.value)}
                          className="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-sm transition-all"
                        />
                      </div>
                      <button 
                        type="submit"
                        disabled={isInviting || !inviteEmail}
                        className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-indigo-100"
                      >
                        {isInviting ? <RefreshCw className="animate-spin" size={18} /> : <UserPlus size={18} />}
                        Convidar
                      </button>
                    </form>
                  </div>

                  <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100 flex flex-col justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-indigo-900 mb-1">Link de Convite</h3>
                      <p className="text-[11px] text-indigo-700 opacity-80 mb-4">Compartilhe o link direto para acesso</p>
                    </div>
                    <button 
                      onClick={copyInviteLink}
                      className="w-full py-3 bg-white text-indigo-600 font-bold rounded-2xl hover:bg-indigo-100 transition-all border border-indigo-200 flex items-center justify-center gap-2 text-sm"
                    >
                      {copied ? <CheckCircle2 size={18} /> : <Copy size={18} />}
                      {copied ? 'Copiado!' : 'Copiar Link'}
                    </button>
                  </div>
                </div>

                {/* Filters & Search */}
                <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="relative w-full md:max-w-xs">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      placeholder="Buscar usuário..." 
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-11 pr-4 py-2.5 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 text-sm"
                    />
                  </div>
                  
                  <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0 no-scrollbar">
                    <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                      {(['all', 'pending', 'active', 'blocked'] as const).map((status) => (
                        <button
                          key={status}
                          onClick={() => setFilterStatus(status)}
                          className={cn(
                            "px-3 py-1.5 text-[10px] font-bold rounded-lg transition-all uppercase tracking-wider",
                            filterStatus === status ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700"
                          )}
                        >
                          {status === 'all' ? 'Todos' : 
                           status === 'pending' ? 'Pendentes' : 
                           status === 'active' ? 'Ativos' : 'Bloqueados'}
                        </button>
                      ))}
                    </div>
                    <button 
                      onClick={() => setSortBy(sortBy === 'recent' ? 'email' : 'recent')}
                      className="p-2.5 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-all flex items-center gap-2 text-[10px] font-bold uppercase"
                    >
                      <ArrowUpDown size={14} />
                      {sortBy === 'recent' ? 'Recentes' : 'A-Z'}
                    </button>
                  </div>
                </div>

                {/* Users List */}
                <div className="space-y-4">
                  {loading ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="h-20 bg-slate-50 rounded-3xl animate-pulse" />
                      ))}
                    </div>
                  ) : processedUsers.length === 0 ? (
                    <div className="text-center py-20 bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-200">
                      <Users size={48} className="mx-auto text-slate-300 mb-4" />
                      <p className="text-slate-500 font-medium">Nenhum usuário encontrado</p>
                      <p className="text-xs text-slate-400 mt-1">Tente ajustar seus filtros ou busca</p>
                    </div>
                  ) : (
                    <>
                      {/* Desktop Table View */}
                      <div className="hidden md:block overflow-hidden border border-slate-100 rounded-3xl bg-white shadow-sm">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100">
                              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Usuário</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Data Convite</th>
                              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Ações</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {processedUsers.map((user) => (
                              <tr key={user.id} className="hover:bg-slate-50/30 transition-colors group">
                                <td className="px-6 py-4">
                                  <div className="flex items-center gap-3">
                                    <div className={cn(
                                      "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm",
                                      user.status === 'active' ? "bg-emerald-100 text-emerald-600" : "bg-slate-100 text-slate-500"
                                    )}>
                                      {(user.name || user.email || '?')[0].toUpperCase()}
                                    </div>
                                    <div className="flex flex-col">
                                      <span className="text-sm font-bold text-slate-800">{user.name || 'Sem nome'}</span>
                                      <span className="text-xs text-slate-500">{user.email}</span>
                                    </div>
                                  </div>
                                </td>
                                <td className="px-6 py-4">
                                  <span className={cn(
                                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase flex items-center gap-1.5 w-fit",
                                    user.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 
                                    (user.status === 'invited' || user.status === 'pending') ? 'bg-amber-50 text-amber-600' :
                                    'bg-rose-50 text-rose-600'
                                  )}>
                                    <div className={cn(
                                      "w-1.5 h-1.5 rounded-full",
                                      user.status === 'active' ? 'bg-emerald-600' : 
                                      (user.status === 'invited' || user.status === 'pending') ? 'bg-amber-600' :
                                      'bg-rose-600'
                                    )} />
                                    {user.status === 'active' ? 'Aceito' : 
                                     (user.status === 'invited' || user.status === 'pending') ? 'Pendente' : 
                                     'Bloqueado'}
                                  </span>
                                </td>
                                <td className="px-6 py-4 text-xs text-slate-400 font-medium">
                                  {user.createdAt?.toDate ? format(user.createdAt.toDate(), 'dd MMM yyyy', { locale: ptBR }) : '-'}
                                </td>
                                <td className="px-6 py-4">
                                  <div className="flex justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                    {(user.status === 'invited' || user.status === 'pending') && (
                                      <button 
                                        onClick={() => handleResendInvite(user)}
                                        className="p-2 text-indigo-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                        title="Reenviar Convite"
                                      >
                                        <RefreshCw size={18} />
                                      </button>
                                    )}
                                    <button 
                                      onClick={() => handleResetPassword(user.email)}
                                      className="p-2 text-amber-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                                      title="Redefinir Senha"
                                    >
                                      <Key size={18} />
                                    </button>
                                    <button 
                                      onClick={() => setEditingUser(user)}
                                      className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                                      title="Editar"
                                    >
                                      <Edit2 size={18} />
                                    </button>
                                    <button 
                                      onClick={() => handleToggleUserStatus(user)}
                                      className={cn(
                                        "p-2 rounded-lg transition-all",
                                        user.status === 'active' ? "text-amber-400 hover:text-amber-600 hover:bg-amber-50" : "text-emerald-400 hover:text-emerald-600 hover:bg-emerald-50"
                                      )}
                                      title={user.status === 'active' ? "Bloquear" : "Ativar"}
                                    >
                                      {user.status === 'active' ? <UserX size={18} /> : <UserCheck size={18} />}
                                    </button>
                                    <button 
                                      onClick={() => handleDeleteUser(user.id, user.email)}
                                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                                      title="Remover"
                                    >
                                      <Trash2 size={18} />
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>

                      {/* Mobile Card View */}
                      <div className="md:hidden space-y-4">
                        {processedUsers.map((user) => (
                          <div key={user.id} className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm space-y-4">
                            <div className="flex justify-between items-start">
                              <div className="flex items-center gap-3">
                                <div className={cn(
                                  "w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm",
                                  user.status === 'active' ? "bg-emerald-100 text-emerald-600" : "bg-slate-100 text-slate-500"
                                )}>
                                  {(user.name || user.email || '?')[0].toUpperCase()}
                                </div>
                                <div className="flex flex-col">
                                  <span className="text-sm font-bold text-slate-800">{user.name || 'Sem nome'}</span>
                                  <span className="text-[10px] text-slate-500">{user.email}</span>
                                </div>
                              </div>
                              <span className={cn(
                                "px-2 py-0.5 rounded-full text-[9px] font-bold uppercase",
                                user.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 
                                (user.status === 'invited' || user.status === 'pending') ? 'bg-amber-50 text-amber-600' :
                                'bg-rose-50 text-rose-600'
                              )}>
                                {user.status === 'active' ? 'Aceito' : 
                                 (user.status === 'invited' || user.status === 'pending') ? 'Pendente' : 
                                 'Bloqueado'}
                              </span>
                            </div>
                            
                            <div className="flex items-center justify-between pt-2 border-t border-slate-50">
                              <span className="text-[10px] text-slate-400 font-medium">
                                {user.createdAt?.toDate ? format(user.createdAt.toDate(), 'dd/MM/yyyy') : '-'}
                              </span>
                              <div className="flex gap-1">
                                {(user.status === 'invited' || user.status === 'pending') && (
                                  <button onClick={() => handleResendInvite(user)} className="p-2 text-indigo-600 bg-indigo-50 rounded-lg"><RefreshCw size={16} /></button>
                                )}
                                <button onClick={() => setEditingUser(user)} className="p-2 text-slate-600 bg-slate-50 rounded-lg"><Edit2 size={16} /></button>
                                <button onClick={() => handleToggleUserStatus(user)} className="p-2 text-amber-600 bg-amber-50 rounded-lg"><UserX size={16} /></button>
                                <button onClick={() => handleDeleteUser(user.id, user.email)} className="p-2 text-rose-600 bg-rose-50 rounded-lg"><Trash2 size={16} /></button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              </div>
            ) : activeTab === 'requests' ? (
              /* Requests Tab */
              <div className="space-y-4">
                {requests.length === 0 ? (
                  <div className="text-center py-20 bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-200">
                    <Clock size={48} className="mx-auto text-slate-300 mb-4 opacity-20" />
                    <p className="text-slate-500 font-medium">Nenhum pedido pendente</p>
                    <p className="text-xs text-slate-400 mt-1">Novas solicitações aparecerão aqui</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {requests.map((req) => (
                      <div key={req.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between group hover:border-indigo-200 transition-all">
                        <div className="flex justify-between items-start mb-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-800">{req.name}</span>
                            <span className="text-xs text-slate-500">{req.email}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 font-bold bg-slate-50 px-2 py-1 rounded-lg">
                            {req.createdAt?.toDate ? format(req.createdAt.toDate(), 'dd/MM HH:mm') : 'Recent'}
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => handleApproveRequest(req)}
                            className="flex-1 py-2.5 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                          >
                            <Check size={14} /> Aceitar
                          </button>
                          <button 
                            onClick={() => handleRejectRequest(req.id)}
                            className="flex-1 py-2.5 bg-rose-50 text-rose-600 text-xs font-bold rounded-xl hover:bg-rose-100 transition-all flex items-center justify-center gap-2"
                          >
                            <X size={14} /> Recusar
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              /* Logs Tab */
              <div className="space-y-4">
                <div className="bg-slate-900 rounded-3xl text-slate-300 p-6 font-mono text-xs overflow-hidden shadow-2xl">
                  <div className="flex items-center gap-2 mb-4 text-slate-500 border-b border-white/5 pb-4">
                    <Terminal size={14} />
                    <span>DIRETÓRIO DE SEGURANÇA - EVENTOS RECENTES</span>
                  </div>
                  <div className="space-y-2 max-h-[500px] overflow-y-auto custom-scrollbar pr-2">
                    {logs.map((log) => (
                      <div key={log.id} className="flex gap-4 items-start py-1 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                        <span className="text-slate-500 shrink-0">
                          [{log.timestamp?.toDate ? format(log.timestamp.toDate(), 'HH:mm:ss') : '...'}]
                        </span>
                        <div className="flex-1">
                          <span className={cn(
                            "font-bold mr-2",
                            log.success ? "text-emerald-400" : "text-rose-400"
                          )}>
                            {log.event.toUpperCase()}
                          </span>
                          <span className="text-slate-400 break-all">
                            {log.email || log.userId || 'Guest'} - {log.admin ? `by ${log.admin}` : ''}
                          </span>
                        </div>
                      </div>
                    ))}
                    {logs.length === 0 && (
                      <div className="text-center py-10 text-slate-600">
                        Nenhum log registrado até o momento.
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex justify-end gap-3">
          <button 
            onClick={onClose}
            className="px-8 py-2.5 bg-white border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-100 transition-all text-sm"
          >
            Fechar
          </button>
        </footer>
      </motion.div>

      {/* Confirmation Modal */}
      <AnimatePresence>
        {confirmConfig.isOpen && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-[40px] shadow-2xl border border-slate-100 w-full max-w-md overflow-hidden"
            >
              <div className="p-10 text-center">
                <div className="w-20 h-20 bg-rose-100 text-rose-600 rounded-[32px] flex items-center justify-center mb-6 mx-auto">
                  <AlertCircle size={40} />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 mb-2">Remover Usuário?</h2>
                <p className="text-sm text-slate-500 leading-relaxed">
                  Tem certeza que deseja remover <strong>{confirmConfig.email}</strong>? 
                  Esta ação é irreversível e o acesso será revogado imediatamente.
                </p>
              </div>
              <div className="px-10 pb-10 flex gap-3">
                <button 
                  onClick={() => setConfirmConfig({ isOpen: false, userId: '', email: '' })}
                  className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 transition-all"
                >
                  Cancelar
                </button>
                <button 
                  onClick={confirmDeleteUser}
                  className="flex-1 px-6 py-4 bg-rose-600 text-white font-bold rounded-2xl shadow-lg shadow-rose-200 hover:bg-rose-700 transition-all active:scale-[0.98]"
                >
                  Confirmar
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit User Modal */}
      <AnimatePresence>
        {editingUser && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-[40px] shadow-2xl border border-slate-100 w-full max-w-md overflow-hidden"
            >
              <form onSubmit={handleUpdateUser}>
                <div className="p-10">
                  <div className="w-16 h-16 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mb-6">
                    <Edit2 size={32} />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-6">Editar Usuário</h2>
                  
                  <div className="space-y-5">
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Nome Completo</label>
                      <input 
                        type="text" 
                        value={editingUser.name || ''}
                        onChange={(e) => setEditingUser({ ...editingUser, name: e.target.value })}
                        className="w-full px-5 py-3.5 bg-slate-50 border border-slate-100 rounded-2xl focus:ring-2 focus:ring-indigo-500 transition-all text-sm font-medium"
                        placeholder="Nome do usuário"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Nível de Acesso</label>
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          type="button"
                          onClick={() => setEditingUser({ ...editingUser, role: 'user' })}
                          className={cn(
                            "py-3 rounded-2xl text-xs font-bold border transition-all",
                            editingUser.role === 'user' ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100" : "bg-white text-slate-500 border-slate-200 hover:border-indigo-200"
                          )}
                        >
                          Usuário Comum
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingUser({ ...editingUser, role: 'admin' })}
                          className={cn(
                            "py-3 rounded-2xl text-xs font-bold border transition-all",
                            editingUser.role === 'admin' ? "bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100" : "bg-white text-slate-500 border-slate-200 hover:border-indigo-200"
                          )}
                        >
                          Administrador
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="px-10 pb-10 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setEditingUser(null)}
                    className="flex-1 px-6 py-4 border border-slate-200 text-slate-600 font-bold rounded-2xl hover:bg-slate-50 transition-all"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-6 py-4 bg-indigo-600 text-white font-bold rounded-2xl shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-[0.98]"
                  >
                    Salvar
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
