import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Plus, 
  History, 
  Target, 
  Calendar,
  Wallet,
  ArrowRight,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  ChevronRight,
  Trophy,
  Activity,
  Check,
  X,
  CheckCircle2
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area
} from 'recharts';
import { format, parseISO, startOfMonth, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion, AnimatePresence } from 'motion/react';
import { Saving, UserProfile } from '../types';
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';

interface SavingsTabProps {
  savings: Saving[];
  userProfile: UserProfile;
  userId: string;
}

export function SavingsTab({ savings, userProfile, userId }: SavingsTabProps) {
  const [isAddingMode, setIsAddingMode] = useState(false);
  const [newAmount, setNewAmount] = useState('');
  const [newMonth, setNewMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [isDeductingFromRevenue, setIsDeductingFromRevenue] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditingInitial, setIsEditingInitial] = useState(false);
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempInitial, setTempInitial] = useState(userProfile.initialSavings?.toString() || '0');
  const [tempGoal, setTempGoal] = useState(userProfile.annualSavingsGoal?.toString() || '0');

  const stats = useMemo(() => {
    const initialBalance = userProfile.initialSavings || 0;
    const depositsTotal = savings.reduce((acc, s) => acc + s.amount, 0);
    const totalAccumulated = initialBalance + depositsTotal;
    
    const currentMonthStr = format(new Date(), 'yyyy-MM');
    const prevMonthStr = format(subMonths(new Date(), 1), 'yyyy-MM');
    
    const currentMonthDeposit = savings.find(s => s.monthYear === currentMonthStr)?.amount || 0;
    const prevMonthDeposit = savings.find(s => s.monthYear === prevMonthStr)?.amount || 0;
    
    const diff = currentMonthDeposit - prevMonthDeposit;
    const percentDiff = prevMonthDeposit !== 0 
      ? (diff / prevMonthDeposit) * 100 
      : (currentMonthDeposit !== 0 ? 100 : 0);

    const averageDeposit = savings.length > 0 ? depositsTotal / savings.length : 0;
    
    // Projection until end of year
    const currentMonthIndex = new Date().getMonth() + 1; // 1-12
    const monthsRemaining = 12 - currentMonthIndex;
    const projectedEndYear = totalAccumulated + (averageDeposit * monthsRemaining);

    // Annual Goal Logic
    const annualGoal = userProfile.annualSavingsGoal || 0;
    const remainingForGoal = Math.max(0, annualGoal - totalAccumulated);
    const monthlyNeeded = monthsRemaining > 0 ? remainingForGoal / monthsRemaining : 0;
    const goalProgress = annualGoal > 0 ? (totalAccumulated / annualGoal) * 100 : 0;
    
    return {
      totalAccumulated,
      currentMonthDeposit,
      prevMonthDeposit,
      diff,
      percentDiff,
      average: averageDeposit,
      projectedEndYear,
      monthsRemaining,
      annualGoal,
      remainingForGoal,
      monthlyNeeded,
      goalProgress: Math.min(goalProgress, 100)
    };
  }, [savings, userProfile.initialSavings, userProfile.annualSavingsGoal]);

  const chartData = useMemo(() => {
    return [...savings]
      .reverse()
      .map(s => ({
        name: format(parseISO(`${s.monthYear}-01`), 'MMM/yy', { locale: ptBR }),
        valor: s.amount
      }));
  }, [savings]);

  const handleUpdateInitialSavings = async () => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        initialSavings: parseFloat(tempInitial) || 0
      });
      setIsEditingInitial(false);
    } catch (error) {
      console.error("Error updating initial savings:", error);
    }
  };

  const handleUpdateAnnualGoal = async () => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        annualSavingsGoal: parseFloat(tempGoal) || 0
      });
      setIsEditingGoal(false);
    } catch (error) {
      console.error("Error updating annual goal:", error);
    }
  };

  const handleAddDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAmount || isSubmitting) return;

    setIsSubmitting(true);
    const amount = parseFloat(newAmount);
    try {
      // 1. Add saving record
      await addDoc(collection(db, 'users', userId, 'savings'), {
        amount,
        monthYear: newMonth,
        createdAt: new Date().toISOString()
      });

      // 2. If requested, deduct from revenue (as a transaction expense)
      if (isDeductingFromRevenue) {
        await addDoc(collection(db, 'users', userId, 'transactions'), {
          amount,
          category: 'Depósito',
          date: new Date().toISOString().split('T')[0],
          description: `Depósito mensal para economias (${newMonth})`,
          type: 'expense'
        });
      }

      setIsAddingMode(false);
      setNewAmount('');
    } catch (error) {
      console.error("Error adding saving:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const getInsight = () => {
    if (savings.length === 0) return "Registre seu primeiro depósito para que eu possa começar a analisar seu perfil poupador.";
    if (savings.length === 1) return "Ótimo começo! Manter a frequência é o segredo para construir um patrimônio sólido.";
    
    // Sort by monthYear ascending for trend analysis
    const sortedSavings = [...savings].sort((a, b) => a.monthYear.localeCompare(b.monthYear)).reverse();
    const last3 = sortedSavings.slice(0, 3);
    const isGrowing = last3.length >= 2 && last3[0].amount > last3[last3.length - 1].amount;
    
    // Consistency: small variation (under 20%) between months in the last 4 records
    const isConsistent = savings.length >= 4 && savings.slice(0, 4).every((s, i, arr) => {
      if (i === arr.length - 1) return true;
      const variation = Math.abs(s.amount - arr[i+1].amount) / (arr[i+1].amount || 1);
      return variation < 0.25;
    });

    if (stats.annualGoal > 0 && stats.remainingForGoal > 0) {
      const monthGoalDesc = stats.monthsRemaining > 0 
        ? ` Faltam R$ ${stats.remainingForGoal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} para sua meta de ano. Você precisa economizar R$ ${stats.monthlyNeeded.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} por mês.`
        : " Este é o último mês para bater sua meta anual!";
      
      if (isGrowing && stats.diff > 0) {
        return `Seu padrão indica crescimento real! +${stats.percentDiff.toFixed(0)}% este mês.${monthGoalDesc}`;
      }
      
      if (stats.diff > 0) {
        return `Sensacional! Você economizou R$ ${stats.diff.toFixed(2)} a mais que no mês passado.${monthGoalDesc}`;
      }
    }

    if (isGrowing && stats.diff > 0) {
      return `Seu padrão indica crescimento real! Você está economizando R$ ${stats.diff.toFixed(2)} a mais (+${stats.percentDiff.toFixed(0)}%) e mantém uma tendência de alta nos últimos meses.`;
    }
    
    if (isConsistent) {
      return "Consistência impecável! Você está mantendo seus depósitos estáveis nos últimos meses, o que é fundamental para o sucesso financeiro.";
    }

    if (stats.diff > 0) {
      return `Sensacional! Você economizou R$ ${stats.diff.toFixed(2)} a mais que no mês passado (+${stats.percentDiff.toFixed(0)}%). Cada centavo a mais conta!`;
    } else if (stats.diff < 0) {
      return `Seu depósito este mês foi R$ ${Math.abs(stats.diff).toFixed(2)} menor (-${Math.abs(stats.percentDiff).toFixed(0)}%). Tente retomar o ritmo no próximo ciclo.`;
    }
    
    return "Você manteve exatamente o mesmo valor de depósito. Estabilidade é um ótimo sinal de organização!";
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Header with Title and Main Action */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">Suas Economias</h2>
          <p className="text-slate-500 font-medium">Acompanhe seu progresso e planeje seu futuro financeiro.</p>
        </div>
        <motion.button 
          whileHover={{ scale: 1.02, y: -2 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => setIsAddingMode(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:shadow-xl hover:shadow-indigo-200 transition-all group"
        >
          <div className="p-1 bg-white/20 rounded-lg group-hover:bg-white/30 transition-colors">
            <Plus size={20} />
          </div>
          <span>Novo Depósito</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Total Acumulado Card */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="bg-indigo-600 rounded-[32px] p-6 text-white shadow-xl shadow-indigo-200/50 flex flex-col relative overflow-hidden h-full"
        >
          <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 rounded-full blur-2xl" />
          
          <div className="flex justify-between items-center mb-auto relative z-10">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-white/20 rounded-xl">
                <Trophy size={18} />
              </div>
              <span className="text-[10px] font-bold uppercase tracking-widest opacity-80">Total Acumulado</span>
            </div>
            <button 
              onClick={() => setIsEditingInitial(!isEditingInitial)}
              className="text-[10px] bg-white/20 px-3 py-1 rounded-full hover:bg-white/40 transition-all uppercase font-black"
            >
              {isEditingInitial ? <X size={12} /> : 'Editar'}
            </button>
          </div>

          <div className="mt-8 space-y-4">
            <div>
              <div className="text-4xl font-black leading-none mb-1 tabular-nums">
                R$ {stats.totalAccumulated.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Patrimônio Total Estruturado</div>
            </div>

            <div className="flex items-center gap-3 bg-white/10 p-2.5 rounded-2xl border border-white/10 group-hover:bg-white/20 transition-colors">
              <div className="p-2 bg-white/20 rounded-lg text-white">
                <CheckCircle2 size={14} />
              </div>
              <div>
                <div className="text-[10px] font-bold text-indigo-100 uppercase tracking-widest">Status Inicial</div>
                <p className="text-[11px] font-bold text-white leading-tight">
                  {userProfile.initialSavings ? `R$ ${userProfile.initialSavings.toLocaleString('pt-BR')} iniciais` : "Nenhum aporte inicial"}
                </p>
              </div>
            </div>
          </div>
            
          <AnimatePresence>
            {isEditingInitial && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 10 }}
                className="mt-4 p-4 bg-white/10 rounded-2xl border border-white/20 relative z-20"
              >
                <label className="block text-[10px] font-bold uppercase tracking-wider mb-2 text-indigo-200">Saldo Inicial</label>
                <div className="flex gap-2">
                  <input 
                    type="number"
                    value={tempInitial}
                    onChange={(e) => setTempInitial(e.target.value)}
                    className="bg-white/10 border-none rounded-xl px-3 py-2 text-sm w-full outline-none focus:bg-white/20 transition-all text-white placeholder:text-white/40 font-bold"
                    placeholder="R$ 0,00"
                  />
                  <button 
                    onClick={handleUpdateInitialSavings}
                    className="bg-white text-indigo-600 p-2 rounded-xl hover:bg-indigo-50 transition-colors shadow-sm shrink-0"
                  >
                    <Check size={20} />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Mês Atual Card */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="group bg-white rounded-[32px] p-6 border border-slate-100 shadow-sm flex flex-col h-full transition-all"
        >
          <div className="flex justify-between items-center mb-auto">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl group-hover:scale-110 transition-transform">
                <TrendingUp size={18} />
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mês Atual</span>
            </div>
            <div className={cn(
              "px-2 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter flex items-center gap-1",
              stats.diff >= 0 ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
            )}>
              {stats.diff >= 0 ? <Plus size={10} /> : <div className="w-1.5 h-0.5 bg-current" />}
              {Math.abs(stats.percentDiff).toFixed(0)}%
            </div>
          </div>

          <div className="mt-8 space-y-4">
            <div>
              <div className="text-4xl font-black text-slate-900 leading-none mb-1 tabular-nums">
                R$ {stats.currentMonthDeposit.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Depósito registrado este mês</div>
            </div>
            
            <div className={cn(
              "flex items-center gap-3 p-2.5 rounded-2xl border transition-colors",
              stats.diff >= 0 ? "bg-emerald-50 border-emerald-100/50" : "bg-rose-50 border-rose-100/50"
            )}>
              <div className={cn(
                "p-2 bg-white rounded-lg shadow-sm",
                stats.diff >= 0 ? "text-emerald-500" : "text-rose-500"
              )}>
                {stats.diff >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
              </div>
              <div>
                <div className={cn(
                  "text-[10px] font-black uppercase tracking-widest",
                  stats.diff >= 0 ? "text-emerald-700" : "text-rose-700"
                )}>
                  {stats.diff >= 0 ? 'Crescimento' : 'Retração'}
                </div>
                <p className={cn(
                  "text-[11px] font-bold leading-tight",
                  stats.diff >= 0 ? "text-emerald-800" : "text-rose-800"
                )}>
                  R$ {Math.abs(stats.diff).toLocaleString('pt-BR')} vs mês anterior
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Meta Anual Card */}
        <motion.div 
          whileHover={{ y: -4 }}
          className="group bg-white rounded-[32px] p-6 border border-slate-100 shadow-sm flex flex-col h-full transition-all"
        >
          <div className="flex justify-between items-center mb-auto">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-xl group-hover:scale-110 transition-transform">
                <Target size={18} />
              </div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Meta {new Date().getFullYear()}</span>
            </div>
            <span className="text-[10px] font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full uppercase">
              {stats.goalProgress.toFixed(0)}% Concluído
            </span>
          </div>

          <div className="mt-8 space-y-4">
            <div className="flex items-end justify-between">
              <div>
                <div className="text-4xl font-black text-slate-900 mb-1 leading-none tabular-nums">
                  R$ {stats.annualGoal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Faltam R$ {stats.remainingForGoal.toLocaleString('pt-BR')}</div>
              </div>
              <button 
                onClick={() => setIsEditingGoal(!isEditingGoal)}
                className="text-[10px] bg-slate-50 text-slate-500 px-3 py-1.5 rounded-full hover:bg-indigo-50 hover:text-indigo-600 transition-all uppercase font-black tracking-widest"
              >
                {isEditingGoal ? 'Fechar' : 'Ajustar'}
              </button>
            </div>

            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden shadow-inner">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${stats.goalProgress}%` }}
                className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full shadow-[0_0_8px_rgba(245,158,11,0.3)]"
              />
            </div>

            <AnimatePresence>
              {isEditingGoal && (
                <motion.div 
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <div className="flex gap-2 p-2 bg-slate-50 rounded-2xl border border-slate-100 mb-2">
                    <input 
                      type="number"
                      value={tempGoal}
                      onChange={(e) => setTempGoal(e.target.value)}
                      className="bg-transparent border-none rounded-xl px-2 py-1 text-sm w-full outline-none text-slate-800 font-bold placeholder:text-slate-300"
                      placeholder="Valor Final"
                    />
                    <button 
                      onClick={handleUpdateAnnualGoal}
                      className="bg-amber-500 text-white p-1.5 rounded-lg hover:bg-amber-600 transition-colors shadow-sm shrink-0"
                    >
                      <Check size={16} />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Compact Insight Tooltip */}
            <div className="flex items-center gap-3 bg-slate-50/80 p-2.5 rounded-2xl border border-slate-100 group-hover:bg-amber-50 transition-colors">
              <div className="p-2 bg-white text-amber-500 rounded-lg shadow-sm">
                <Sparkles size={14} />
              </div>
              <p className="text-[11px] font-bold text-slate-500 leading-tight">
                {stats.annualGoal > 0 
                  ? stats.remainingForGoal > 0 
                    ? `Poupe R$ ${Math.ceil(stats.monthlyNeeded)}/mês`
                    : "Objetivo anual batido! 🥳"
                  : "Defina sua meta anual."}
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Evolution Chart & Insight */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-100 p-8 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Evolução de Economias</h3>
              <p className="text-sm text-slate-500">Histórico de depósitos mensais</p>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-slate-50 rounded-xl text-slate-400 transition-colors">
                <Calendar size={20} />
              </button>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 500 }}
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 500 }}
                  tickFormatter={(val) => `R$${val}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    borderRadius: '16px', 
                    border: 'none', 
                    boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                    padding: '12px'
                  }}
                  formatter={(val: number) => [`R$ ${val.toLocaleString('pt-BR')}`, 'Depósito']}
                />
                <Area 
                  type="monotone" 
                  dataKey="valor" 
                  stroke="#4f46e5" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorVal)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-900 rounded-3xl p-6 text-white relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-10">
              <Sparkles size={120} />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-2 text-indigo-400 mb-4">
                <Sparkles size={20} />
                <span className="text-xs font-bold uppercase tracking-wider">Guru de Economias</span>
              </div>
              <p className="text-lg font-medium leading-relaxed mb-6">
                "{getInsight()}"
              </p>
              <div className="flex items-center justify-between p-4 bg-white/10 rounded-2xl border border-white/10">
                <div>
                  <div className="text-[10px] uppercase font-bold text-indigo-300 tracking-widest mb-1">
                    Projeção Dez/{new Date().getFullYear()}
                  </div>
                  <div className="text-xl font-black">
                    R$ {stats.projectedEndYear.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] uppercase font-bold text-indigo-300 tracking-widest mb-1">
                    Meses Restantes
                  </div>
                  <div className="text-sm font-bold">{stats.monthsRemaining} meses</div>
                </div>
              </div>
              <div className="mt-4 text-[10px] text-indigo-300 italic text-center">
                * Baseado no seu saldo acumulado + média de depósitos
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* History Table */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-50 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-slate-100 rounded-xl">
              <History size={20} className="text-slate-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-800">Histórico de Depósitos</h3>
          </div>
          <div className="text-sm font-medium text-slate-400">
            {savings.length} depósitos registrados
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Mês / Ano</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest">Valor</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-center">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-400 uppercase tracking-widest text-right">Comparação</th>
              </tr>
            </thead>
            <tbody>
              {savings.map((s, idx) => {
                const prev = savings[idx + 1];
                const diff = prev ? s.amount - prev.amount : 0;
                const pDiff = prev ? (diff / prev.amount) * 100 : 0;

                return (
                  <tr key={s.id} className="border-t border-slate-50 hover:bg-slate-50/30 transition-colors group">
                    <td className="px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-bold text-xs uppercase">
                          {format(parseISO(`${s.monthYear}-01`), 'MMM', { locale: ptBR })}
                        </div>
                        <div>
                          <div className="font-bold text-slate-800">{format(parseISO(`${s.monthYear}-01`), 'MMMM yyyy', { locale: ptBR })}</div>
                          <div className="text-xs text-slate-400 font-medium">Registrado em {format(parseISO(s.createdAt), 'dd/MM/yy')}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <div className="text-lg font-black text-slate-800">
                        R$ {s.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </div>
                    </td>
                    <td className="px-6 py-5 text-center">
                      <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                        Processado
                      </span>
                    </td>
                    <td className="px-6 py-5 text-right">
                      {prev ? (
                        <div className={cn(
                          "flex items-center justify-end gap-1 font-bold",
                          diff >= 0 ? "text-emerald-500" : "text-rose-500"
                        )}>
                          {diff >= 0 ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                          <span>{pDiff.toFixed(0)}%</span>
                          <span className="text-xs opacity-50 ml-1">({diff >= 0 ? '+' : ''}R$ {Math.abs(diff).toFixed(0)})</span>
                        </div>
                      ) : (
                        <span className="text-slate-300 text-xs font-bold uppercase tracking-widest">Saldo Inicial</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {savings.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-slate-400 font-medium italic">
                    Nenhum depósito registrado ainda. Comece hoje mesmo!
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for adding deposit */}
      <AnimatePresence>
        {isAddingMode && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAddingMode(false)}
              className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="bg-white rounded-[32px] shadow-2xl w-full max-w-md overflow-hidden relative z-10"
            >
              <div className="p-8 pb-0 flex justify-between items-start">
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
                  <Plus size={24} />
                </div>
                <button 
                  onClick={() => setIsAddingMode(false)}
                  className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition-colors"
                >
                  <ArrowRight className="rotate-45" />
                </button>
              </div>
              
              <div className="p-8">
                <h3 className="text-2xl font-black text-slate-800 mb-2 tracking-tight">Economia Mensal</h3>
                <p className="text-slate-500 text-sm font-medium mb-8">Registre quanto você separou para o futuro este mês.</p>
                
                <form onSubmit={handleAddDeposit} className="space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Valor do Depósito</label>
                    <div className="relative">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">R$</div>
                      <input 
                        type="number"
                        step="0.01"
                        autoFocus
                        required
                        value={newAmount}
                        onChange={(e) => setNewAmount(e.target.value)}
                        placeholder="0,00"
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl font-black text-2xl text-slate-800 transition-all outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Mês de Referência</label>
                    <input 
                      type="month"
                      required
                      value={newMonth}
                      onChange={(e) => setNewMonth(e.target.value)}
                      className="w-full px-4 py-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 focus:bg-white rounded-2xl font-bold text-slate-800 transition-all outline-none"
                    />
                  </div>

                  <div 
                    onClick={() => setIsDeductingFromRevenue(!isDeductingFromRevenue)}
                    className={cn(
                      "flex items-center gap-4 p-4 rounded-2xl border-2 transition-all cursor-pointer",
                      isDeductingFromRevenue ? "bg-indigo-50 border-indigo-200" : "bg-slate-50 border-transparent"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center transition-colors shadow-sm",
                      isDeductingFromRevenue ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-400"
                    )}>
                      {isDeductingFromRevenue ? <Check size={20} /> : <X size={20} />}
                    </div>
                    <div>
                      <div className={cn(
                        "font-bold text-sm",
                        isDeductingFromRevenue ? "text-indigo-900" : "text-slate-600"
                      )}>
                        Descontar da Receita?
                      </div>
                      <div className="text-[10px] font-medium text-slate-400 leading-tight">
                        Se sim, criará uma transação de "Depósito" para manter seu saldo real.
                      </div>
                    </div>
                  </div>

                  <motion.button 
                    whileHover={{ scale: 1.02, y: -1 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4.5 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:shadow-xl hover:shadow-indigo-100 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <div className="bg-white/20 p-1 rounded-lg">
                          <CheckCircle2 size={18} />
                        </div>
                        Confirmar Depósito
                      </>
                    )}
                  </motion.button>
                </form>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Helper for conditional classes
function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
