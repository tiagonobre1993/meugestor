import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  X, 
  Printer, 
  Calendar, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  PieChart, 
  ArrowUpRight, 
  ArrowDownRight, 
  FileText, 
  ChevronLeft, 
  ChevronRight, 
  AlertCircle,
  Filter,
  ArrowRight,
  Zap,
  Target,
  ShoppingBag,
  Home,
  Car,
  Utensils,
  Heart,
  Coffee,
  Briefcase,
  Layers
} from 'lucide-react';
import { format, startOfMonth, endOfMonth, isWithinInterval, subMonths, addMonths, parseISO, eachDayOfInterval, isSameDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { 
  PieChart as RePieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer, 
  Tooltip, 
  Legend, 
  Sector,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: any[];
  budgets: any[];
  categories: any[];
}

const COLORS = [
  '#6366f1', // Indigo
  '#10b981', // Emerald
  '#f43f5e', // Rose
  '#f59e0b', // Amber
  '#8b5cf6', // Violet
  '#06b6d4', // Cyan
  '#ec4899', // Pink
  '#3b82f6', // Blue
  '#f97316', // Orange
  '#14b8a6', // Teal
];

const renderActiveShape = (props: any) => {
  const { cx, cy, innerRadius, outerRadius, startAngle, endAngle, fill, payload, percent, value } = props;

  return (
    <g>
      <text x={cx} y={cy - 10} dy={8} textAnchor="middle" fill="#1e293b" className="text-sm font-bold">
        {payload.name}
      </text>
      <text x={cx} y={cy + 15} dy={8} textAnchor="middle" fill="#64748b" className="text-[10px] font-medium">
        {formatCurrency(value)} ({Math.round(percent * 100)}%)
      </text>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius + 8}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
        style={{ filter: 'drop-shadow(0 10px 15px rgba(0,0,0,0.1))' }}
      />
    </g>
  );
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-white p-4 rounded-2xl shadow-2xl border border-slate-100 animate-in fade-in zoom-in duration-200">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{data.name}</p>
        <p className="text-lg font-black text-slate-800">{formatCurrency(data.value)}</p>
        <p className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full w-fit mt-2">
          {data.percent}% do total
        </p>
      </div>
    );
  }
  return null;
};

const Sparkline = ({ data, color }: { data: any[], color: string }) => (
  <div className="h-10 w-24">
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data}>
        <Area 
          type="monotone" 
          dataKey="value" 
          stroke={color} 
          fill={`${color}20`} 
          strokeWidth={2} 
          isAnimationActive={true}
        />
      </AreaChart>
    </ResponsiveContainer>
  </div>
);

export function ReportModal({ isOpen, onClose, transactions, budgets, categories }: ReportModalProps) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [filterType, setFilterType] = useState<'all' | 'income' | 'expense'>('all');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    if (!printRef.current) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Por favor, permita pop-ups para imprimir o relatório.');
      return;
    }

    const content = printRef.current.innerHTML;
    const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
      .map(style => style.outerHTML)
      .join('\n');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Relatório Financeiro - Meu Gestor</title>
          ${styles}
          <style>
            @media print {
              body { margin: 0; padding: 20px; }
              .print-hidden { display: none !important; }
            }
            body { 
              font-family: sans-serif; 
              background: white !important;
            }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
          </style>
        </head>
        <body>
          <div class="print-container">
            ${content}
          </div>
          <script>
            window.onload = () => {
              setTimeout(() => {
                window.focus();
                window.print();
              }, 1000);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const reportData = useMemo(() => {
    const start = startOfMonth(selectedDate);
    const end = endOfMonth(selectedDate);
    const prevStart = startOfMonth(subMonths(selectedDate, 1));
    const prevEnd = endOfMonth(subMonths(selectedDate, 1));

    const getMonthData = (startDate: Date, endDate: Date) => {
      const monthTransactions = transactions.filter(t => {
        const date = typeof t.date === 'string' ? parseISO(t.date) : t.date.toDate();
        return isWithinInterval(date, { start: startDate, end: endDate });
      });

      const income = monthTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);

      const expenses = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);

      const categoryTotals = monthTransactions
        .filter(t => t.type === 'expense')
        .reduce((acc: any, t) => {
          acc[t.category] = (acc[t.category] || 0) + t.amount;
          return acc;
        }, {});

      // Daily data for sparklines
      const days = eachDayOfInterval({ start: startDate, end: endDate });
      
      const incomeDaily = days.map(day => {
        const dayTotal = monthTransactions
          .filter(t => {
            const tDate = typeof t.date === 'string' ? parseISO(t.date) : t.date.toDate();
            return t.type === 'income' && isSameDay(tDate, day);
          })
          .reduce((sum, t) => sum + t.amount, 0);
        return { day: format(day, 'dd'), value: dayTotal };
      });

      const expenseDaily = days.map(day => {
        const dayTotal = monthTransactions
          .filter(t => {
            const tDate = typeof t.date === 'string' ? parseISO(t.date) : t.date.toDate();
            return t.type === 'expense' && isSameDay(tDate, day);
          })
          .reduce((sum, t) => sum + t.amount, 0);
        return { day: format(day, 'dd'), value: dayTotal };
      });

      const dailyData = days.map(day => {
        const dayTotal = monthTransactions
          .filter(t => {
            const tDate = typeof t.date === 'string' ? parseISO(t.date) : t.date.toDate();
            return isSameDay(tDate, day);
          })
          .reduce((sum, t) => sum + (t.type === 'income' ? t.amount : -t.amount), 0);
        return { day: format(day, 'dd'), value: dayTotal };
      });

      return { income, expenses, categoryTotals, monthTransactions, dailyData, incomeDaily, expenseDaily };
    };

    const current = getMonthData(start, end);
    const previous = getMonthData(prevStart, prevEnd);

    // Calculate variations
    const calcVar = (curr: number, prev: number) => {
      if (prev === 0) return curr > 0 ? 100 : 0;
      return ((curr - prev) / prev) * 100;
    };

    const incomeVar = calcVar(current.income, previous.income);
    const expenseVar = calcVar(current.expenses, previous.expenses);
    const balanceVar = calcVar(current.income - current.expenses, previous.income - previous.expenses);

    // Chart data with percentages
    const totalExpenses = current.expenses || 1;
    const chartData = Object.entries(current.categoryTotals).map(([name, value]: [string, any]) => ({
      name,
      value,
      percent: Math.round((value / totalExpenses) * 100)
    })).sort((a: any, b: any) => b.value - a.value);

    // Filtered transactions for the list
    let filteredTransactions = [...current.monthTransactions];
    if (filterType !== 'all') {
      filteredTransactions = filteredTransactions.filter(t => t.type === filterType);
    }
    if (filterCategory !== 'all') {
      filteredTransactions = filteredTransactions.filter(t => t.category === filterCategory);
    }

    const topTransactions = filteredTransactions
      .sort((a, b) => b.amount - a.amount)
      .slice(0, 8);

    // Insights
    const insights = [];
    if (chartData.length > 0) {
      const topCat = chartData[0];
      insights.push({
        type: 'warning',
        text: `Seu maior gasto foi em ${topCat.name}, representando ${topCat.percent}% do total.`,
        icon: <AlertCircle size={16} />
      });
    }
    if (Math.abs(expenseVar) > 5) {
      insights.push({
        type: expenseVar > 0 ? 'danger' : 'success',
        text: `Seus gastos ${expenseVar > 0 ? 'aumentaram' : 'diminuíram'} ${Math.abs(Math.round(expenseVar))}% em relação ao mês passado.`,
        icon: expenseVar > 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />
      });
    }
    if (current.income > current.expenses) {
      insights.push({
        type: 'success',
        text: `Parabéns! Você economizou ${formatCurrency(current.income - current.expenses)} este mês.`,
        icon: <Zap size={16} />
      });
    }

    return {
      ...current,
      incomeVar,
      expenseVar,
      balanceVar,
      chartData,
      topTransactions,
      insights,
      balance: current.income - current.expenses
    };
  }, [selectedDate, transactions, filterType, filterCategory]);

  if (!isOpen) return null;

  const onPieEnter = (_: any, index: number) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(null);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[150] flex items-center justify-center p-0 sm:p-4 print:p-0 print:bg-white print:static print:inset-auto">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        ref={printRef} 
        className="bg-white sm:rounded-[40px] shadow-2xl w-full max-w-6xl h-full sm:h-[90vh] overflow-hidden flex flex-col print:shadow-none print:h-auto print:rounded-none print:w-full"
      >
        
        {/* Header */}
        <header className="px-8 py-6 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4 bg-white sticky top-0 z-30 print:border-b-2 print:border-slate-900">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 print:bg-black">
              <FileText size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900 print:text-3xl">Relatório Financeiro</h1>
              <p className="text-xs text-slate-500 font-medium print:text-slate-700">Análise inteligente de Meu Gestor</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3 print:hidden">
            <div className="flex items-center bg-slate-100 rounded-2xl p-1">
              <button 
                onClick={() => setSelectedDate(subMonths(selectedDate, 1))}
                className="p-2 hover:bg-white rounded-xl transition-all text-slate-600 shadow-none hover:shadow-sm"
              >
                <ChevronLeft size={20} />
              </button>
              <div className="px-4 font-bold text-slate-800 min-w-[140px] text-center capitalize text-sm">
                {format(selectedDate, 'MMMM yyyy', { locale: ptBR })}
              </div>
              <button 
                onClick={() => setSelectedDate(addMonths(selectedDate, 1))}
                className="p-2 hover:bg-white rounded-xl transition-all text-slate-600 shadow-none hover:shadow-sm"
              >
                <ChevronRight size={20} />
              </button>
            </div>
            
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white text-sm font-bold rounded-2xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
            >
              <Printer size={18} />
              <span className="hidden sm:inline">Imprimir</span>
            </button>
            
            <button 
              onClick={onClose}
              className="p-2.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-2xl transition-all"
            >
              <X size={24} />
            </button>
          </div>

          <div className="hidden print:block text-right">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Período de Análise</p>
            <p className="text-xl font-black text-slate-900 capitalize">{format(selectedDate, 'MMMM yyyy', { locale: ptBR })}</p>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-8 space-y-8 custom-scrollbar print:overflow-visible print:p-0 print:mt-8">
          
          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm flex flex-col justify-between relative overflow-hidden group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl">
                  <TrendingUp size={20} />
                </div>
                <Sparkline data={reportData.incomeDaily} color="#10b981" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Total Recebido</p>
                <h3 className="text-2xl font-black text-slate-900">{formatCurrency(reportData.income)}</h3>
                <div className={cn(
                  "flex items-center gap-1 text-[10px] font-bold mt-2",
                  reportData.incomeVar >= 0 ? "text-emerald-600" : "text-rose-600"
                )}>
                  {reportData.incomeVar >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {Math.abs(Math.round(reportData.incomeVar))}% em relação ao mês anterior
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className="bg-white border border-slate-100 p-6 rounded-[32px] shadow-sm flex flex-col justify-between relative overflow-hidden group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl">
                  <TrendingDown size={20} />
                </div>
                <Sparkline data={reportData.expenseDaily} color="#f43f5e" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Total Gasto</p>
                <h3 className="text-2xl font-black text-slate-900">{formatCurrency(reportData.expenses)}</h3>
                <div className={cn(
                  "flex items-center gap-1 text-[10px] font-bold mt-2",
                  reportData.expenseVar <= 0 ? "text-emerald-600" : "text-rose-600"
                )}>
                  {reportData.expenseVar <= 0 ? <ArrowDownRight size={12} /> : <ArrowUpRight size={12} />}
                  {Math.abs(Math.round(reportData.expenseVar))}% em relação ao mês anterior
                </div>
              </div>
            </motion.div>

            <motion.div 
              whileHover={{ y: -5 }}
              className={cn(
                "p-6 rounded-[32px] shadow-sm border flex flex-col justify-between relative overflow-hidden group transition-colors",
                reportData.balance >= 0 ? "bg-indigo-600 text-white border-indigo-600" : "bg-amber-500 text-white border-amber-500"
              )}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="p-3 bg-white/20 text-white rounded-2xl">
                  <DollarSign size={20} />
                </div>
                <Sparkline data={reportData.dailyData} color="#ffffff" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-white/60 uppercase tracking-widest mb-1">Saldo Líquido</p>
                <h3 className="text-2xl font-black">{formatCurrency(reportData.balance)}</h3>
                <div className="flex items-center gap-1 text-[10px] font-bold mt-2 text-white/80">
                  {reportData.balanceVar >= 0 ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
                  {Math.abs(Math.round(reportData.balanceVar))}% de variação no saldo
                </div>
              </div>
            </motion.div>
          </div>

          {/* Main Analysis Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Column: Chart & Insights */}
            <div className="lg:col-span-7 space-y-8">
              
              {/* Interactive Donut Chart */}
              <div className="bg-white border border-slate-100 p-8 rounded-[40px] shadow-sm relative">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                      <PieChart size={20} />
                    </div>
                    <h4 className="font-bold text-slate-800">Gastos por Categoria</h4>
                  </div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    {reportData.chartData.length} Categorias
                  </div>
                </div>
                
                <div className="flex flex-col md:flex-row items-center gap-8">
                  <div className="h-[320px] w-full md:w-1/2 relative">
                    {reportData.chartData.length > 0 ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <RePieChart onMouseLeave={onPieLeave}>
                          <Pie
                            activeIndex={activeIndex ?? undefined}
                            activeShape={renderActiveShape}
                            data={reportData.chartData}
                            cx="50%"
                            cy="50%"
                            innerRadius={70}
                            outerRadius={100}
                            paddingAngle={8}
                            dataKey="value"
                            onMouseEnter={onPieEnter}
                            stroke="none"
                          >
                            {reportData.chartData.map((entry, index) => (
                              <Cell 
                                key={`cell-${index}`} 
                                fill={COLORS[index % COLORS.length]} 
                                opacity={activeIndex === null || activeIndex === index ? 1 : 0.3}
                                className="transition-all duration-300 cursor-pointer outline-none"
                              />
                            ))}
                          </Pie>
                          <Tooltip content={<CustomTooltip />} />
                        </RePieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center text-slate-300">
                        <PieChart size={48} className="mb-4 opacity-10" />
                        <p className="text-xs font-medium">Sem dados para exibir</p>
                      </div>
                    )}
                    {/* Center Info when not hovering */}
                    {activeIndex === null && reportData.chartData.length > 0 && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none animate-in fade-in duration-500">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Gasto</p>
                        <p className="text-xl font-black text-slate-800">{formatCurrency(reportData.expenses)}</p>
                      </div>
                    )}
                  </div>

                  {/* Custom Legend */}
                  <div className="w-full md:w-1/2 space-y-3">
                    {reportData.chartData.map((entry, index) => (
                      <button
                        key={entry.name}
                        onMouseEnter={() => setActiveIndex(index)}
                        onMouseLeave={() => setActiveIndex(null)}
                        className={cn(
                          "w-full flex items-center justify-between p-3 rounded-2xl transition-all border",
                          activeIndex === index 
                            ? "bg-slate-50 border-slate-200 scale-[1.02] shadow-sm" 
                            : "bg-white border-transparent hover:bg-slate-50/50"
                        )}
                      >
                        <div className="flex items-center gap-3">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: COLORS[index % COLORS.length] }} 
                          />
                          <span className="text-xs font-bold text-slate-700">{entry.name}</span>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-black text-slate-800">{formatCurrency(entry.value)}</p>
                          <p className="text-[10px] font-bold text-slate-400">{entry.percent}%</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Smart Insights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {reportData.insights.map((insight, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    key={idx}
                    className={cn(
                      "p-5 rounded-3xl border flex gap-4 items-start",
                      insight.type === 'success' ? "bg-emerald-50 border-emerald-100 text-emerald-800" :
                      insight.type === 'warning' ? "bg-amber-50 border-amber-100 text-amber-800" :
                      "bg-rose-50 border-rose-100 text-rose-800"
                    )}
                  >
                    <div className={cn(
                      "p-2 rounded-xl shrink-0",
                      insight.type === 'success' ? "bg-emerald-500 text-white" :
                      insight.type === 'warning' ? "bg-amber-500 text-white" :
                      "bg-rose-500 text-white"
                    )}>
                      {insight.icon}
                    </div>
                    <p className="text-xs font-bold leading-relaxed">{insight.text}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Right Column: Transactions & Filters */}
            <div className="lg:col-span-5 space-y-8">
              
              <div className="bg-white border border-slate-100 p-8 rounded-[40px] shadow-sm flex flex-col h-full">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 bg-slate-50 text-slate-600 rounded-xl">
                      <Layers size={20} />
                    </div>
                    <h4 className="font-bold text-slate-800">Maiores Movimentações</h4>
                  </div>
                  
                  {/* Mini Filters */}
                  <div className="flex gap-1 bg-slate-100 p-1 rounded-xl print:hidden">
                    {(['all', 'income', 'expense'] as const).map((type) => (
                      <button
                        key={type}
                        onClick={() => setFilterType(type)}
                        className={cn(
                          "px-2 py-1 text-[9px] font-bold rounded-lg transition-all uppercase tracking-tighter",
                          filterType === type ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500"
                        )}
                      >
                        {type === 'all' ? 'Tudo' : type === 'income' ? 'Entradas' : 'Saídas'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-3 flex-1">
                  {reportData.topTransactions.length > 0 ? (
                    reportData.topTransactions.map((t, i) => (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        key={t.id} 
                        className="flex items-center justify-between p-4 bg-slate-50/50 border border-transparent hover:border-slate-200 hover:bg-white rounded-2xl transition-all group cursor-default"
                      >
                        <div className="flex items-center gap-4">
                          <div className={cn(
                            "w-10 h-10 rounded-xl flex items-center justify-center shadow-sm",
                            t.type === 'income' ? "bg-emerald-100 text-emerald-600" : "bg-rose-100 text-rose-600"
                          )}>
                            {t.type === 'income' ? <ArrowUpRight size={18} /> : <ArrowDownRight size={18} />}
                          </div>
                          <div>
                            <p className="text-xs font-bold text-slate-800 line-clamp-1">{t.description}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{t.category}</span>
                              <span className="w-1 h-1 bg-slate-300 rounded-full" />
                              <span className="text-[9px] text-slate-400 font-bold">{format(typeof t.date === 'string' ? parseISO(t.date) : t.date.toDate(), 'dd MMM')}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={cn(
                            "text-sm font-black",
                            t.type === 'income' ? "text-emerald-600" : "text-rose-600"
                          )}>
                            {t.type === 'income' ? '+' : '-'}{formatCurrency(t.amount)}
                          </p>
                        </div>
                      </motion.div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center py-20 text-slate-300">
                      <Filter size={40} className="mb-4 opacity-10" />
                      <p className="text-xs font-medium">Nenhuma transação encontrada</p>
                    </div>
                  )}
                </div>

                <button className="w-full mt-6 py-3 text-xs font-bold text-indigo-600 bg-indigo-50 rounded-2xl hover:bg-indigo-100 transition-all flex items-center justify-center gap-2 print:hidden">
                  Ver Todas as Transações
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </div>

          {/* Budget Performance */}
          <div className="bg-slate-900 text-white p-8 sm:p-10 rounded-[40px] shadow-2xl relative overflow-hidden print:bg-white print:text-slate-900 print:border-2 print:border-slate-900 print:shadow-none">
            {/* Background Decoration */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none print:hidden" />
            
            <div className="flex items-center justify-between mb-10 relative z-10">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/10 text-indigo-400 rounded-2xl print:bg-slate-100 print:text-indigo-600">
                  <Target size={24} />
                </div>
                <div>
                  <h4 className="text-lg font-bold">Monitor de Orçamentos</h4>
                  <p className="text-xs text-white/50 font-medium print:text-slate-500">Acompanhamento de metas por categoria</p>
                </div>
              </div>
              <div className="hidden sm:block text-right">
                <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Status Geral</p>
                <p className="text-sm font-bold text-emerald-400">Em conformidade</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-10 relative z-10">
              {budgets.length > 0 ? (
                budgets.map((b) => {
                  const spent = reportData.categoryTotals[b.category] || 0;
                  const percent = (spent / b.limit) * 100;
                  return (
                    <div key={b.id} className="space-y-4 group">
                      <div className="flex justify-between items-end">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-white/60 group-hover:bg-white/10 transition-colors print:bg-slate-50 print:text-slate-400">
                            <ShoppingBag size={18} />
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors print:text-slate-800">{b.category}</p>
                            <p className="text-[10px] text-white/40 font-bold uppercase tracking-tighter print:text-slate-400">Limite: {formatCurrency(b.limit)}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={cn(
                            "text-base font-black",
                            percent > 100 ? "text-rose-400 print:text-rose-600" : "text-emerald-400 print:text-emerald-600"
                          )}>
                            {formatCurrency(spent)}
                          </p>
                          <p className="text-[10px] font-bold text-white/40 print:text-slate-500">{Math.round(percent)}% utilizado</p>
                        </div>
                      </div>
                      <div className="h-2.5 bg-white/10 rounded-full overflow-hidden print:bg-slate-100">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${Math.min(100, percent)}%` }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                          className={cn(
                            "h-full rounded-full shadow-sm",
                            percent > 100 ? "bg-gradient-to-r from-rose-500 to-rose-400" : 
                            percent > 80 ? "bg-gradient-to-r from-amber-500 to-amber-400" :
                            "bg-gradient-to-r from-emerald-500 to-emerald-400"
                          )}
                        />
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="col-span-2 py-12 text-center bg-white/5 rounded-[32px] border border-white/10">
                  <Target size={40} className="mx-auto text-white/10 mb-4" />
                  <p className="text-sm font-medium text-white/40">Nenhum orçamento configurado para monitoramento.</p>
                </div>
              )}
            </div>
          </div>

          {/* Footer / Print Info */}
          <div className="hidden print:block border-t-2 border-slate-900 pt-8 mt-12">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Documento Gerado em</p>
                <p className="text-sm font-bold text-slate-900">{format(new Date(), "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: ptBR })}</p>
              </div>
              <div className="text-right">
                <p className="text-xl font-black text-slate-900">Meu Gestor</p>
                <p className="text-xs text-slate-500 font-bold tracking-tighter uppercase">Gestão Financeira de Elite</p>
              </div>
            </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
}
