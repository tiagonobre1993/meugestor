import React, { useState } from 'react';
import { Send, Smartphone, MessageSquare, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WhatsAppSimulatorProps {
  onClose: () => void;
  phone: string;
}

export function WhatsAppSimulator({ onClose, phone }: WhatsAppSimulatorProps) {
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState<{ text: string, type: 'user' | 'bot', time: string }[]>([
    { text: "Bem-vindo ao Simulador do Meu Gestor! 📈", type: 'bot', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
  ]);
  const [loading, setLoading] = useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const isPhoneMissing = !phone;
  const activePhone = phone || 'SIMULADOR-TESTE';

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chat, loading]);

  const handleSend = async () => {
    if (!message.trim()) return;

    if (isPhoneMissing && chat.length === 1) {
       setChat(prev => [...prev, { 
         text: "⚠️ Notei que você não configurou seu número de WhatsApp nas 'Configurações'. \n\nPara que as mensagens do simulador apareçam no seu Dashboard, você precisa cadastrar esse número ('SIMULADOR-TESTE') lá ou cadastrar seu número real.", 
         type: 'bot', 
         time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
       }]);
    }

    const userMessage = { text: message, type: 'user' as const, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) };
    setChat(prev => [...prev, userMessage]);
    setLoading(true);
    
    const textToSend = message;
    setMessage('');

    try {
      const response = await fetch('/api/whatsapp/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Body: textToSend, From: `whatsapp:${activePhone}` })
      });

      const responseText = await response.text();

      if (!response.ok) {
        let errorMsg = responseText;
        try {
          const errorData = JSON.parse(responseText);
          errorMsg = errorData?.message || errorData?.error || responseText;
        } catch (e) {
          // Not JSON
        }
        throw new Error(`Erro ${response.status}: ${errorMsg || 'Servidor não respondeu corretamente.'}`);
      }

      // Parse Twilio XML response to get message text
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(responseText, "text/xml");
      
      // Verifica se houve erro de parse
      const parseError = xmlDoc.getElementsByTagName("parsererror")[0];
      if (parseError) {
        throw new Error("Resposta do servidor não está no formato esperado (XML)");
      }

      const botText = xmlDoc.getElementsByTagName("Message")[0]?.textContent || "Recebi sua mensagem, mas não consegui formatar a resposta.";

      setChat(prev => [...prev, { text: botText, type: 'bot', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    } catch (error: any) {
      setChat(prev => [...prev, { text: `❌ ${error.message || "Erro ao conectar com o servidor."}`, type: 'bot', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      className="fixed bottom-6 right-6 w-80 h-[500px] bg-white rounded-[32px] shadow-2xl border border-slate-100 flex flex-col overflow-hidden z-[1000] font-sans"
    >
      {/* Header */}
      <header className="bg-[#075E54] text-white p-4 flex items-center gap-3">
        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded-full transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
          <Smartphone size={20} />
        </div>
        <div>
          <h3 className="font-bold text-sm">WhatsApp (Simulador)</h3>
          <p className="text-[10px] text-white/70">Online agora</p>
        </div>
      </header>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#E5DDD5] scroll-smooth"
      >
        {chat.map((msg, index) => (
          <div key={index} className={`flex ${msg.type === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-2xl shadow-sm text-sm relative ${
              msg.type === 'user' 
                ? 'bg-[#DCF8C6] rounded-tr-none' 
                : 'bg-white rounded-tl-none'
            }`}>
              <p className="text-slate-800 whitespace-pre-wrap">{msg.text}</p>
              <span className="text-[9px] text-slate-400 block text-right mt-1">{msg.time}</span>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white p-3 rounded-2xl rounded-tl-none shadow-sm flex gap-1">
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <footer className="p-3 bg-[#F0F2F5] flex gap-2">
        <input 
          type="text" 
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Digite uma mensagem..."
          className="flex-1 bg-white border-transparent focus:ring-0 rounded-full px-4 py-2 text-sm"
        />
        <button 
          onClick={handleSend}
          disabled={!message.trim() || loading}
          className="w-10 h-10 bg-[#128C7E] text-white rounded-full flex items-center justify-center active:scale-95 transition-all shadow-md disabled:opacity-50"
        >
          <Send size={18} fill="currentColor" />
        </button>
      </footer>
    </motion.div>
  );
}
