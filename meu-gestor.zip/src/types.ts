export type Category = string;
export type TransactionOrigin = 'manual' | 'whatsapp' | 'audio' | 'ai' | 'simulator';
export type TransactionStatus = 'confirmed' | 'pending';

export interface Transaction {
  id: string;
  date: string;
  description: string;
  category: Category;
  amount: number;
  type: 'income' | 'expense';
  origin?: TransactionOrigin;
  status?: TransactionStatus;
  originalMessage?: string;
  installments?: {
    current: number;
    total: number;
  };
}

export interface Saving {
  id: string;
  amount: number;
  monthYear: string; // "YYYY-MM"
  createdAt: string;
  notes?: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  name?: string;
  photoURL?: string;
  role: 'admin' | 'user';
  savingsGoal: number;
  annualSavingsGoal?: number;
  whatsappPhone?: string;
  distributionMode: 'default' | 'accelerated' | 'custom';
  customDistribution: {
    needs: number;
    leisure: number;
    investments: number;
  };
  initialSavings?: number;
}

export interface Budget {
  category: Category;
  limit: number;
  spent: number;
  description?: string;
}

export interface Bill {
  id: string;
  name: string;
  dueDate: string;
  amount: number;
  status: 'pending' | 'scheduled' | 'paid';
  category: string;
  currentInstallment?: number;
  totalInstallments?: number;
  recurring?: boolean;
}
