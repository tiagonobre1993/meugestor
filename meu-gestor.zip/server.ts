import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, serverTimestamp, query, where, getDocs, updateDoc, doc } from "firebase/firestore";
import twilio from "twilio";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read Firebase config
const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));

// Initialize Firebase Client SDK (Works better in dev environment without service account)
const appFirebase = initializeApp(firebaseConfig);
const db = getFirestore(appFirebase, firebaseConfig.firestoreDatabaseId || "(default)");

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Twilio uses urlencoded for webhook bodies
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // --- WHATSAPP LOGGING & DEBUG ---
  app.use((req, res, next) => {
    if (req.path.includes("whatsapp")) {
      logWebhook(`[Request Incoming] ${req.method} ${req.path} - Type: ${req.get('Content-Type')}`);
    }
    next();
  });

  /**
   * Logs persistentes para debug
   */
  async function logWebhook(msg: string) {
    const logPath = path.join(process.cwd(), "webhook-debug.log");
    const timestamp = new Date().toISOString();
    try {
      fs.appendFileSync(logPath, `[${timestamp}] ${msg}\n`);
    } catch(e) {}
    console.log(`[WhatsApp Log] ${msg}`);
  };

  /**
   * Lógica Central de Processamento
   */
  async function handleWhatsAppMessage(Body: string, From: string, MediaUrl0?: string) {
    const phone = (From || "").replace("whatsapp:", "").trim();
    const messageText = (Body || "").trim();
    const twiml = new twilio.twiml.MessagingResponse();

    try {
      if (!messageText && !MediaUrl0) {
        return { status: 400, response: "Missing Body or Media" };
      }

      const usersRef = collection(db, "users");
      const userQuery = query(usersRef, where("whatsappPhone", "==", phone));
      const userSnap = await getDocs(userQuery);
      
      let userId: string | null = null;
      let userFound = false;
      let userData: any = null;

      if (!userSnap.empty) {
        userId = userSnap.docs[0].id;
        userFound = true;
        userData = userSnap.docs[0].data();
      }

      if (userFound && !userData.whatsappTutorialSeen) {
        const tutorial = `👋 *Bem-vindo ao Meu Gestor!*\n\nUse "gastei 50 no mercado", "30 uber", "recebi 2000" ou "paguei o aluguel".\n\n🚀 Seus registros aparecem na hora no seu Dashboard!`;
        await updateDoc(doc(db, "users", userId!), { whatsappTutorialSeen: true });
        twiml.message(tutorial);
      }

      const sessionsRef = collection(db, "whatsapp_sessions");
      const sessionQuery = query(sessionsRef, where("phone", "==", phone));
      const sessionSnap = await getDocs(sessionQuery);
      
      if (!sessionSnap.empty) {
        const sessionDoc = sessionSnap.docs[0];
        const sessionData = sessionDoc.data();

        if (sessionData.state === "AWAITING_CATEGORY") {
          const pendingTransaction = sessionData.pendingTransaction;
          pendingTransaction.category = messageText;
          
          const targetPath = userId ? `users/${userId}/transactions` : `usuarios/${phone}/transacoes`;
          const parts = targetPath.split('/');
          const transactionsCollection = collection(db, parts[0], parts[1], parts[2]);
          await addDoc(transactionsCollection, { ...pendingTransaction, criadoEm: serverTimestamp() });
          await updateDoc(doc(db, "whatsapp_sessions", sessionDoc.id), { state: "IDLE", pendingTransaction: null, updatedAt: serverTimestamp() });

          const valFmt = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(pendingTransaction.amount);
          twiml.message(`✅ Registrado em *${messageText}*.\n💰 ${valFmt}`);
          return { status: 200, response: twiml.toString() };
        }
      }

      const parsed = parseMessage(messageText);
      if (parsed.intent === "pay_bill" && userFound && userId) {
        const billsRef = collection(db, `users/${userId}/bills`);
        const billsSnap = await getDocs(billsRef);
        let targetBill: any = null;
        billsSnap.forEach(d => {
          const bill = d.data();
          if (bill.status !== "paid") {
            const name = (bill.name || "").toLowerCase();
            if (name.includes(parsed.billName.toLowerCase()) || parsed.billName.toLowerCase().includes(name)) {
              targetBill = { id: d.id, ...bill };
            }
          }
        });

        if (targetBill) {
          await updateDoc(doc(db, `users/${userId}/bills`, targetBill.id), { status: "paid", updatedAt: serverTimestamp() });
          await addDoc(collection(db, `users/${userId}/transactions`), {
            type: "expense", amount: targetBill.amount, description: `Pagamento: ${targetBill.name}`,
            category: targetBill.category || "Utilidades", date: new Date().toISOString(),
            status: "pago", origin: "whatsapp", originalMessage: Body, criadoEm: serverTimestamp()
          });
          twiml.message(`✅ Conta "${targetBill.name}" PAGA!\n💰 R$ ${targetBill.amount.toFixed(2)}`);
          return { status: 200, response: twiml.toString() };
        }
      }

      if (parsed.value <= 0 && !MediaUrl0) {
        twiml.message("❌ Não entendi o valor. Tente algo como: 'gastei 50 mercado'");
        return { status: 200, response: twiml.toString() };
      }

      if (!parsed.isConfident && parsed.type === "expense") {
        const pendingTransaction = {
          type: parsed.type, amount: Number(parsed.value), description: parsed.description,
          date: new Date().toISOString(), status: parsed.status, origin: "whatsapp",
          originalMessage: Body, needsAI: false
        };
        const sessionData = { phone, state: "AWAITING_CATEGORY", pendingTransaction, updatedAt: serverTimestamp() };
        if (sessionSnap.empty) await addDoc(sessionsRef, sessionData);
        else await updateDoc(doc(db, "whatsapp_sessions", sessionSnap.docs[0].id), sessionData);

        const valFmt = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(parsed.value);
        twiml.message(`💰 Gasto de *${valFmt}*.\n❓ Qual a *categoria*?`);
        return { status: 200, response: twiml.toString() };
      }

      const tp = userId ? `users/${userId}/transactions` : `usuarios/${phone}/transacoes`;
      const pts = tp.split('/');
      await addDoc(collection(db, pts[0], pts[1], pts[2]), {
        type: parsed.type, amount: Number(parsed.value), category: parsed.category,
        description: parsed.description, date: new Date().toISOString(), status: parsed.status,
        origin: "whatsapp", originalMessage: Body, needsAI: true, criadoEm: serverTimestamp()
      });

      const valFmt = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(parsed.value);
      let reply = `✅ ${parsed.type === "income" ? "Receita" : "Despesa"} salva!\n💰 ${valFmt}\n📂 ${parsed.category}`;
      if (!userFound) reply += "\n⚠️ Telefone não vinculado!";
      twiml.message(reply);
      return { status: 200, response: twiml.toString() };

    } catch (e: any) {
      logWebhook(`ERROR: ${e.message}`);
      twiml.message("❌ Ocorreu um erro. Tente novamente.");
      return { status: 500, response: twiml.toString() };
    }
  };

  // --- ROTAS DE API (PRIORIDADE MÁXIMA) ---
  
  app.post("/api/whatsapp/simulate", async (req, res) => {
    const { Body, From } = req.body;
    logWebhook(`[Sim] Manual simulation processing: ${Body} from ${From} (Method: ${req.method})`);
    const { status, response } = await handleWhatsAppMessage(Body, From);
    res.status(status).type("text/xml").send(response);
  });

  app.post("/api/whatsapp/webhook", async (req, res) => {
    const { Body, From, MediaUrl0 } = req.body;
    logWebhook(`[Webhook] Incoming from Twilio: ${Body} (Method: ${req.method})`);
    const { status, response } = await handleWhatsAppMessage(Body, From, MediaUrl0);
    res.status(status).type("text/xml").send(response);
  });

  // Fallback para qualquer outro método nas rotas de API para debug
  app.all(["/api/whatsapp/simulate", "/api/whatsapp/webhook"], (req, res) => {
    logWebhook(`[API Error] Invalid method ${req.method} on ${req.path}`);
    res.status(405).json({ 
      error: "Method Not Allowed", 
      message: `As APIs de WhatsApp aceitam apenas POST. Você tentou ${req.method}.`,
      path: req.path
    });
  });

  // Rota para testar conexão com o Banco
  app.get("/api/whatsapp/test-db", async (req, res) => {
    try {
      logWebhook("Testing DB connection manually...");
      const testRef = collection(db, "test_connection");
      const docRef = await addDoc(testRef, { 
        timestamp: serverTimestamp(),
        message: "Server test" 
      });
      logWebhook(`DB Test Success: ${docRef.id}`);
      res.json({ status: "ok", docId: docRef.id });
    } catch (error: any) {
      logWebhook(`DB Test Error: ${error.message}`);
      res.status(500).json({ status: "error", message: error.message });
    }
  });

  // Rota para ver os logs (Debug)
  app.get("/api/whatsapp/logs", (req, res) => {
    const logPath = path.join(process.cwd(), "webhook-debug.log");
    if (fs.existsSync(logPath)) {
      const logs = fs.readFileSync(logPath, "utf-8");
      res.type("text/plain").send(logs);
    } else {
      res.send("No logs found yet. Use /api/whatsapp/ping to generate a log entry.");
    }
  });

  // Rota de teste simples
  app.get("/api/whatsapp/ping", (req, res) => {
    logWebhook("Ping received manually via GET /ping");
    res.json({ status: "ok", message: "Webhook endpoint is active" });
  });

  /**
   * Parser Inteligente para mensagens do WhatsApp
   */
  const parseMessage = (text: string) => {
    const originalText = text.trim();
    const lowerText = originalText.toLowerCase();
    
    let type: "income" | "expense" = "expense";
    let status: "pago" | "pendente" = "pago";
    
    if (originalText.startsWith("+") || lowerText.includes("recebi") || lowerText.includes("receita") || lowerText.includes("ganhei")) {
      type = "income";
    } else if (originalText.startsWith("-") || lowerText.includes("despesa") || lowerText.includes("gastei") || lowerText.includes("pagamento")) {
      type = "expense";
    }

    const valMatch = originalText.replace("R$", "").match(/(\d+(?:[.,]\d+)?)/);
    const value = valMatch ? parseFloat(valMatch[0].replace(",", ".")) : 0;

    let intent: "transaction" | "pay_bill" = "transaction";
    let billName = "";

    const payKeywords = ["paguei a conta de", "paguei o", "paguei a", "baixa na conta", "baixa no"];
    if (payKeywords.some(pk => lowerText.includes(pk))) {
      intent = "pay_bill";
      billName = lowerText;
      payKeywords.forEach(pk => { billName = billName.replace(pk, ""); });
      billName = billName.replace("paguei", "").replace("conta", "").trim();
    } else if (lowerText.includes("paga") && !valMatch) {
       intent = "pay_bill";
       billName = lowerText.replace("paga", "").trim();
    }

    if (lowerText.includes("paguei") || lowerText.includes("pago")) {
      type = "expense";
      status = "pago";
    } else if (lowerText.includes("vou pagar") || lowerText.includes("pagar depois") || lowerText.includes("agendei")) {
      type = "expense";
      status = "pendente";
    }

    let category = "Outros";
    let isConfident = false;
    const keywords: Record<string, string[]> = {
      "Alimentação": ["mercado", "supermercado", "comida", "restaurante", "ifood", "jantar", "almoço", "padaria", "lanche", "pizza", "café"],
      "Transporte": ["gasolina", "combustível", "posto", "gas", "uber", "ônibus", "carro", "estacionamento", "pedágio", "ipva"],
      "Saúde": ["farmácia", "médico", "dentista", "hospital", "remédio", "drogaria", "clínica"],
      "Beleza": ["cabelo", "cabeleireiro", "barbeiro", "barba", "manicure", "estética", "salão", "perfume", "cosmético"],
      "Moradia": ["aluguel", "condomínio", "iptu", "reforma", "móvel", "decoração"],
      "Utilidades": ["internet", "wifi", "claro", "vivo", "tim", "luz", "energia", "eletricidade", "água", "sabesp", "gás de cozinha"],
      "Entretenimento": ["netflix", "spotify", "cinema", "show", "jogo", "balada", "cerveja", "bar"],
      "Educação": ["curso", "escola", "faculdade", "livro", "mensalidade"],
      "Pets": ["pet", "cachorro", "gato", "veterinário", "ração", "banho", "tosa"],
      "Salário": ["salário", "pagamento", "receita", "proventos", "bônus", "comissão"],
      "Investimentos": ["investimento", "ação", "fundo", "tesouro", "cripto"]
    };

    const wordsInText = lowerText.split(/[\s,.;:!?]+/).filter(w => w.length > 0);
    
    for (const [cat, words] of Object.entries(keywords)) {
      if (words.some(word => {
        if (word.includes(" ")) return lowerText.includes(word);
        return wordsInText.includes(word);
      })) {
        category = cat;
        isConfident = true;
        break;
      }
    }

    return { type, value, category, description: originalText, status, intent, billName, isConfident };
  };

  // Middleware do Vite para desenvolvimento
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        host: "0.0.0.0",
        port: 3000 
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Rodando em http://localhost:${PORT}`);
    console.log(`[WhatsApp] Webhook pronto em /api/whatsapp/webhook`);
  });
}

startServer();
